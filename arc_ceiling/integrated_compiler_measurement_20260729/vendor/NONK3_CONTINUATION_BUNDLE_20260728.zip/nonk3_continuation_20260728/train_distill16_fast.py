import glob,os,json
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge,ElasticNet
from sklearn.ensemble import ExtraTreesRegressor,HistGradientBoostingRegressor,RandomForestRegressor,RandomForestRegressor,GradientBoostingRegressor,RandomForestRegressor,StackingRegressor,RandomForestRegressor
from sklearn.neural_network import MLPRegressor
fs=sorted(glob.glob('/mnt/data/whest_work/distill16/network_*.npz'))
Z=[]
for f in fs:
 z=np.load(f);Z.append({'id':int(os.path.basename(f)[8:11]),'X':z['features'],'y':z['residual'],'p':z['partial'],'target':z['target']})
tr,va,te=Z[:15],Z[15:20],Z[20:25]
def cat(S):return np.concatenate([z['X'] for z in S]),np.concatenate([z['y'] for z in S])
X,y=cat(tr);Xv,yv=cat(va);Xt,yt=cat(te)
models=[]
for a in [1e-4,.001,.01,.1,1,10,100,1000,10000]:models.append((f'ridge{a}',make_pipeline(StandardScaler(),Ridge(alpha=a))))
for leaf in [5,10,20,40,80]:models.append((f'extra{leaf}',ExtraTreesRegressor(n_estimators=250,min_samples_leaf=leaf,max_features=1.0,n_jobs=-1,random_state=7)))
# no hist
# no mlp
best=None;allres=[]
for name,m in models:
 m.fit(X,y);q=m.predict(Xv)
 for a in np.linspace(-.5,2,101):
  e=np.mean((a*q-yv)**2)
  if best is None or e<best[0]:best=(e,name,a,m)
 allres.append((name,np.mean((q-yv)**2)))
 print(name,'val direct',np.mean((q-yv)**2),flush=True)
e,name,a,m=best;print('BEST',name,'alpha',a,'val mse',e,'baseline',np.mean(yv*yv),'gain',np.mean(yv*yv)/e)
q=m.predict(Xt);err=np.mean((a*q-yt)**2);base=np.mean(yt*yt);print('TEST distill',err,'baseline',base,'gain',base/err,'rel Kerdock',err/2.2826e-7)
off=0;rows=[]
for z in te:
 n=len(z['y']);qq=q[off:off+n];off+=n;e0=np.mean(z['y']**2);ee=np.mean((a*qq-z['y'])**2);rows.append({'id':z['id'],'ratio':ee/e0,'base':e0,'mse':ee})
print('rows',rows)
# feature ablation ridge: sample-only first 27 vs global etc
for end in [6,18,27,X.shape[1]]:
 mm=make_pipeline(StandardScaler(),Ridge(alpha=100)).fit(X[:,:end],y);qv=mm.predict(Xv[:,:end]);alpha=min(np.linspace(-.5,2,101),key=lambda aa:np.mean((aa*qv-yv)**2));qt=mm.predict(Xt[:,:end]);print('abl',end,'alpha',alpha,'test',np.mean((alpha*qt-yt)**2)/base)
