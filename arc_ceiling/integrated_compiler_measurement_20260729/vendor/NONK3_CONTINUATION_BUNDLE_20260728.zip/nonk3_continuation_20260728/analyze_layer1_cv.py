import json,glob,numpy as np
rows=[]
for f in sorted(glob.glob('/mnt/data/whest_work/kerdock_layer1_cv_[0-9]*.json')):rows+=json.load(open(f))['rows']
D={(r['network'],r['rank'],r['ridge']):r for r in rows};nets=sorted({r['network'] for r in rows});print('nets',len(nets),nets)
# derive base mse from ratio/mse
base={n:next(r['mse']/r['ratio'] for r in rows if r['network']==n) for n in nets}
for split,ns in [('dev',range(15)),('test',range(15,25)),('all',range(25))]:
 print('\n',split)
 out=[]
 for rank in [1,2,4,8]:
  for ridge in [.01,.1,1.0]:
   rr=[D[n,rank,ridge] for n in ns];mean=np.mean([r['ratio'] for r in rr]);pool=sum(r['mse'] for r in rr)/sum(base[n] for n in ns);wins=sum(r['ratio']<1 for r in rr);corr=np.mean([r['corr_mse'] for r in rr]);out.append((pool,mean,rank,ridge,wins,corr))
 for x in sorted(out)[:8]:print(x)
# freeze best dev pooled
opts=[]
for rank in [1,2,4,8]:
 for ridge in [.01,.1,1.0]:opts.append((sum(D[n,rank,ridge]['mse'] for n in range(15))/sum(base[n] for n in range(15)),rank,ridge))
best=min(opts);_,rank,ridge=best;print('BEST',best)
rr=[D[n,rank,ridge] for n in range(15,25)];v=np.array([r['ratio'] for r in rr]);print('TEST',v,'mean',v.mean(),'pooled',sum(r['mse'] for r in rr)/sum(base[n] for n in range(15,25)),'wins',sum(v<1))
rng=np.random.default_rng(4);b=[]
for _ in range(100000):
 ix=rng.integers(0,len(rr),len(rr));b.append(sum(rr[i]['mse'] for i in ix)/sum(base[15+i] for i in ix))
print('boot pooled',np.quantile(b,[.025,.975]))
