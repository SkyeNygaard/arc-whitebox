import glob,json,numpy as np
R=[]
for f in glob.glob('/mnt/data/whest_work/basis_cv_*.json'):R+=json.load(open(f))['rows']
R=sorted(R,key=lambda x:x['network']);rng=np.random.default_rng(2)
for nsname,ns in [('dev',R[:15]),('test',R[15:]),('all',R)]:
 v=np.array([r['ratio'] for r in ns]);num=np.array([r['mse'] for r in ns]);den=np.array([r['base_mse'] for r in ns]);b=[]
 for _ in range(100000):
  ix=rng.integers(0,len(ns),len(ns));b.append(num[ix].sum()/den[ix].sum())
 print(nsname,'mean',v.mean(),'pooled',num.sum()/den.sum(),'CI',np.quantile(b,[.025,.975]),'wins',sum(v<1),'max',v.max(),'alpha mean',np.mean([r['alpha'] for r in ns]))
print('corr varratio vs ratio',np.corrcoef([r['var_ratio'] for r in R],[r['ratio'] for r in R])[0,1])
