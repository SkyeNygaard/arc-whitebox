import glob,json
import numpy as np
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
files=sorted(glob.glob('/mnt/data/whest_work/ref_features/network_[0-9][0-9][0-9].npz'))
Ns=[8,16,24,32,48,64,96,129]; full_mult=.6453
records=[]
for f in files:
 z=np.load(f);bm=z['basis_means'];truth=z['truth'];base=z['base'];be=np.mean((base-truth)**2)
 cand={}
 for n in Ns:
  p=bm[:n].mean(0);me=np.mean((p-truth)**2);relcost=max(.1,full_mult*n/129)/full_mult
  cand[n]={'mse':me,'rawratio':me/be,'score':me/be*relcost}
 # cheap diagnostics available at n: discrepancy, basis variance, output stats
 feats={}
 for n in Ns[:-1]:
  p=bm[:n].mean(0);p2=bm[:max(1,n//2)].mean(0);v=bm[:n].var(0)
  feats[n]=np.array([np.mean((p-p2)**2),np.mean(v)/n,np.mean(v),np.mean(np.abs(p-p2)),np.max(np.abs(p-p2)),np.mean(p),np.std(p),np.mean(np.abs(p)),np.std(bm[:n].mean(1)),n],float)
 records.append((f,cand,feats,be))
print('networks',len(records))
for n in Ns:
 a=np.array([r[1][n]['score'] for r in records]);print('fixed',n,'mean',a.mean(),'median',np.median(a),'wins',sum(a<1),'max',a.max())
orc=np.array([min(r[1][n]['score'] for n in Ns) for r in records]);print('oracle',orc.mean(),np.median(orc),sum(orc<1),orc.max())
print('oracle choices',{n:sum(n==min(Ns,key=lambda q:r[1][q]['score']) for r in records) for n in Ns})
# strict split train 0:15 val? use leave-network group. Train model to predict log score per candidate using all candidate rows, test last 10.
tr=records[:15];te=records[15:]
X=[];y=[]
for _,c,ft,_ in tr:
 for n in Ns[:-1]:X.append(np.r_[ft[n],n/129]);y.append(np.log(c[n]['score']))
# include full n=129 deterministic predicted score 1, no features
model=make_pipeline(StandardScaler(),Ridge(alpha=10.0)).fit(np.array(X),np.array(y))
sel=[]
for _,c,ft,_ in te:
 pred={n:float(np.exp(model.predict(np.r_[ft[n],n/129][None,:])[0])) for n in Ns[:-1]};pred[129]=1.0
 ch=min(pred,key=pred.get);sel.append((ch,c[ch]['score'],pred[ch]))
print('ridge selections',sel,'mean',np.mean([x[1] for x in sel]),'wins',sum(x[1]<1 for x in sel))
# conservative rules: stop at smallest n if internal estimated variance below threshold chosen train
for n in [32,48,64,96]:
 vals=[]
 for q in np.logspace(-10,-4,81):
  scores=[]
  for _,c,ft,_ in tr:
   ch=n if ft[n][0]<q else 129;scores.append(c[ch]['score'])
  vals.append((np.mean(scores),q))
 best=min(vals);scores=[];chs=[]
 for _,c,ft,_ in te:
  ch=n if ft[n][0]<best[1] else 129;chs.append(ch);scores.append(c[ch]['score'])
 print('rule',n,'thr',best[1],'train',best[0],'test',np.mean(scores),'wins',sum(np.array(scores)<1),'choices',chs)
