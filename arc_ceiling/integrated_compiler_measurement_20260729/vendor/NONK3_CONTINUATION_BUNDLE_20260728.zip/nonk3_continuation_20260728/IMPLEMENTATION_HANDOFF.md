# Adaptive suffix compiler — implementation handoff

## Frozen configuration

```python
MAX_SUFFIX_DEPTH = 6
MIN_SUFFIX_DEPTH = 2
PILOT_COLUMNS_PER_BASIS = 8
PILOT_ROWS = 2064
MINORITY_EVENT_LIMIT = 1
```

No target-dependent fitting or error-based selection is permitted.

## Runtime workflow

1. Propagate the complete Kerdock cloud through layer `depth - MAX_SUFFIX_DEPTH`.
2. Extract the frozen basis-balanced pilot rows.
3. Propagate the pilot exactly through the final six layers and retain every preactivation.
4. For each suffix depth `k=2..6`:
   - use the last `k` pilot preactivation matrices;
   - classify each coordinate as stable-on, stable-off, or kink;
   - compute the analytical cost proxy.
5. Select the `k` with minimum cost proxy. Resolve exact ties toward smaller `k`.
6. Compile only the selected suffix:
   - stable-off paths are dropped;
   - stable-on paths are composed into anchor and prior-kink coefficient matrices;
   - full-row ReLU is evaluated only for kink coordinates;
   - final stable-on means are accumulated analytically;
   - exact pilot residuals are added to the compiled mean.
7. Return output in the same scale/order as the protected estimator.

## Classification

For a pilot preactivation matrix `H` with `P` rows:

```python
positive = (H > 0).sum(axis=0)
negative = P - positive
stable = minimum(positive, negative) <= 1
stable_on = stable & (positive >= negative)
stable_off = stable & ~stable_on
kink = ~stable
```

## Cost selector

For suffix depth `k`, kink counts `z[0:k]`, width `D`, pilot rows `P`, and full rows `N`:

```python
suffix = k * P / N
for l in range(k):
    suffix += z[l] / D
    for j in range(l):
        suffix += z[j] * z[l] / D**2

ratio = (depth - k + suffix) / depth
```

This is a selector, not a final FlopScope claim. The implementation must replace it with exact counted operations if blocked-kernel padding changes the ordering.

## Required invariants

- Pilot indices are identical across candidate depths.
- The pilot is basis-balanced and contains antipodal partners.
- Candidate selection uses only kink counts and known dimensions.
- The residual correction uses the exact same pilot rows.
- No reference targets, official means, or full-cloud prediction differences enter the selector.
- Use float64 for accumulated means and correction terms.
- Keep the protected full estimator available for a per-package fallback, not a network-adaptive error fallback.

## Integration strategy

The simplest safe implementation is:

- keep the persistent blocked representation through the anchor layer;
- decode or expose rectangular views only once;
- run the pilot with ordinary dense kernels;
- choose the suffix depth;
- use rectangular blocked kernels for kink-coordinate products;
- analytically fuse stable-on coefficient paths.

A slower reference implementation is included in `adaptive_suffix_compiler_core.py`. It is for correctness, not submission performance.

## Validation gates

1. Bit/float agreement with the reference compiler on small networks.
2. Full-width synthetic perturbation MSE below `1e-9` on nearly all networks.
3. Paired Mini-100 raw-MSE ratio near 1.
4. Exact FlopScope improvement after packing/padding.
5. No failures, NaNs, or excessive residual wall time.
6. Generalized candidate beats the original frozen two-layer package on the same Mini-100 run.

