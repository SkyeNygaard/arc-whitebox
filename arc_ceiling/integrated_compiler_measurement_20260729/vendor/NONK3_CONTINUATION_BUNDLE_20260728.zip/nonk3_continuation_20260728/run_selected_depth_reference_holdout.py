#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time,gc,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,'/mnt/data/whest_work')
import nonk3_suffix_compiler_fast as sc
import nonk3_generic_suffix as gs
import nonk3_reference_features as rf
D=sc.D;DEP=sc.DEP;R1=sc.R1

def prepare(W,X,I,maxk,rare):
    a=X
    for w in W[:DEP-maxk]:
        a=a@w; np.maximum(a,0,out=a)
    acts=[a]; pres=[]
    for w in W[DEP-maxk:]:
        h=a@w; pres.append(h); a=np.maximum(h,0); acts.append(a)
    Y=acts[-1]; base=R1*Y.mean(0,dtype=np.float64)
    metas={}; classes={}
    for k in range(2,maxk+1):
        o=maxk-k
        C=[gs.classify_layer(h[I],rare) for h in pres[o:]]
        classes[k]=C
        metas[k]={'cost_ratio':gs.cost_proxy(k,C,len(I),len(X)),
                  'kinks':[len(c[2]) for c in C]}
    return acts,pres,Y,base,classes,metas

def compile_k(W,acts,Y,I,maxk,k,C):
    o=maxk-k
    return gs.compile_predict(acts[o],W[DEP-k:],C,I,Y)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--asset',type=Path,required=True);ap.add_argument('--start',type=int,required=True);ap.add_argument('--networks',type=int,required=True);ap.add_argument('--seed',type=int,default=2026091501);ap.add_argument('--refs',type=int,default=2);ap.add_argument('--cols',type=int,default=8);ap.add_argument('--rare',type=int,default=1);ap.add_argument('--max-k',type=int,default=8);ap.add_argument('--compare-max-k',type=int,default=6);ap.add_argument('--outdir',type=Path,required=True);a=ap.parse_args();a.outdir.mkdir(parents=True,exist_ok=True)
    X=sc.points(a.asset); I=sc.pidx(a.cols)
    for n in range(a.start,a.start+a.networks):
        out=a.outdir/f'network_{n:03d}.json'
        if out.exists(): print('skip',n,flush=True); continue
        t=time.time(); print('network',n,flush=True); W=sc.net(a.seed+n*1009)
        acts,pres,Y,base,C,meta=prepare(W,X,I,a.max_k,a.rare)
        ch8=min(meta,key=lambda k:meta[k]['cost_ratio'])
        eligible6=[k for k in meta if k<=a.compare_max_k]
        ch6=min(eligible6,key=lambda k:meta[k]['cost_ratio'])
        needed=sorted({ch6,ch8})
        preds={k:compile_k(W,acts,Y,I,a.max_k,k,C[k]) for k in needed}
        refs=[]
        for r in range(a.refs):
            Q=rf.haar(a.seed+n*1009+100000+r); YY=rf.exact_forward(W,X@Q); refs.append(R1*YY.mean(0,dtype=np.float64)); del Q,YY
        refs=np.stack(refs); truth=refs.mean(0); be=float(np.mean((base-truth)**2))
        methods={}
        for k,p in preds.items():
            me=float(np.mean((p-truth)**2)); raw=me/be; cost=meta[k]['cost_ratio']
            methods[str(k)]={'mse_obs':me,'raw_mse_ratio':raw,'score_ratio_obs':raw*cost,'add_mse':float(np.mean((p-base)**2))}
        rec={'network':n,'base_mse_obs':be,'reference_noise':float(np.mean((refs-truth)**2)),'meta':meta,
             'chosen_max6':ch6,'chosen_max8':ch8,'methods':methods,'runtime':time.time()-t}
        out.write_text(json.dumps(rec,indent=2)); print(json.dumps({'n':n,'ch6':ch6,'ch8':ch8,'m6':methods[str(ch6)],'m8':methods[str(ch8)]}),flush=True)
        del W,acts,pres,Y,base,C,meta,preds,refs,truth; gc.collect()
if __name__=='__main__':main()
