# Non-K3 continuation bundle

This bundle contains the continuation work requested on 2026-07-28 after excluding all K3 / transported-third-cumulant directions.

Start with:

- `NONK3_CONTINUATION_REPORT.md`
- `IMPLEMENTATION_HANDOFF.md`
- `NONK3_RESULTS_SUMMARY.json`
- `adaptive_suffix_holdouts_60.csv`

The reference compiler is intentionally slow and uses dense NumPy operations. It is a correctness aid. The submission implementation must be integrated into the protected persistent blocked layout and measured under exact FlopScope/grader conditions.

Raw holdout files are separated by suite:

- `raw_holdouts/` — first 20-network reference suite
- `raw_holdouts_B/` — second 20-network threshold-1 suite
- `raw_holdouts_C/` — third 20-network depth-6/8 suite

No K3 work is included.
