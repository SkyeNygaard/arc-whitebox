import json,glob,sys
import numpy as np
sys.path.insert(0,'/mnt/data/whest_continue')
import sparse_cubic_pilot_cv as s
seeds=list(s.SPLITS['screen']);disc=seeds[:4];val=seeds[4:]
# load MSE curves for fixed feature config
cfgbase=('gaussian_gap_sens',32,'h3',8,1.0)
curves={}
base={}
for seed in seeds:
 d=json.load(open(f'/mnt/data/whest_continue/sparse_cubic_records/{seed}.json'));base[seed]=d['baseline_mse'];q={}
 for x in d['rows']:
  if (x['selector'],x['k'],x['feature'],x['B'],x['ridge'])==cfgbase:q[x['alpha']]=x['mse']
 # M(alpha)=b + l*a + q*a^2; least-squares all points
 A=np.array([[a,a*a] for a in sorted(q)]);y=np.array([q[a]-base[seed] for a in sorted(q)]);coef=np.linalg.lstsq(A,y,rcond=None)[0]
 curves[seed]=coef
metrics={json.load(open(p))['seed']:json.load(open(p)) for p in glob.glob('/mnt/data/whest_continue/gate_rows/*.json')}
def mse(seed,a):l,q=curves[seed];return base[seed]+l*a+q*a*a
def agg(ss, rule):
 c=[];aa=[]
 for seed in ss:
  a=rule(metrics[seed]);aa.append(a);c.append(mse(seed,a))
 b=np.array([base[z] for z in ss]);c=np.array(c);raw=b.sum()/c.sum();cost=0.06447205062984496
 return {'raw':raw,'adj':raw/(1+cost),'wins':int((c<b).sum()),'worst':float((c/b).max()),'alphas':aa,'ratios':(c/b).tolist()}
# grids selected on discovery only
rules=[]
# z caps: alpha=min(.5, cap/z) and hard thresholds
for cap in np.linspace(.005,.12,116):rules.append((f'zcap_{cap:.4f}',lambda m,c=cap:min(.5,c/max(m['correction_z_rms'],1e-12))))
for t in np.linspace(.04,.18,141):rules.append((f'zhard_{t:.4f}',lambda m,t=t:.5 if m['correction_z_rms']<=t else 0.0))
# norm relative baseline caps
for cap in np.geomspace(2e-5,2e-4,100):rules.append((f'relcap_{cap:.7f}',lambda m,c=cap:min(.5,c/max(m['correction_norm']/m['baseline_norm'],1e-15))))
# independent/nested cosine gates
for t in np.linspace(-.8,.9,86):rules.append((f'nested_{t:.3f}',lambda m,t=t:.5 if m['nested_cos_8_16']>=t else 0.0))
for t in np.linspace(-.8,.9,86):rules.append((f'indcos_{t:.3f}',lambda m,t=t:.5 if m['independent_cos_8_alt8']>=t else 0.0))
scored=[]
for name,r in rules:
 d=agg(disc,r);scored.append((d['adj'],name,r,d))
scored.sort(reverse=True,key=lambda x:x[0]);
for _,name,r,d in scored[:20]:print(name,'DISC',d,'VAL',agg(val,r),'ALL',agg(seeds,r))
best=scored[0];payload={'selected_rule':best[1],'discovery':best[3],'validation':agg(val,best[2]),'all':agg(seeds,best[2]),'top':[{'rule':n,'discovery':d,'validation':agg(val,r)} for _,n,r,d in scored[:50]]}
open('/mnt/data/whest_continue/adaptive_shrink_summary.json','w').write(json.dumps(payload,indent=2))
