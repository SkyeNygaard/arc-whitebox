import json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,'/mnt/data/whest_continue')
import sparse_pilot_cv_layer31 as s

seeds=list(s.SPLITS['screen']);disc=seeds[:4];val=seeds[4:]
records=[]
for seed in seeds:
 d=json.load(open(f'/mnt/data/whest_continue/sparse_pilot_cv_records/{seed}.json'))
 d['_map']={tuple(x[k] for k in ('variant','rank','selector','k','B','kind','param')):x for x in d['rows']}
 records.append(d)
keys=list(records[0]['_map'])

def summarize(ss):
 rr=[r for r in records if r['seed'] in ss];out=[]
 for key in keys:
  xs=[r['_map'][key] for r in rr]
  b=np.array([r['baseline_mse'] for r in rr]);c=np.array([x['linear_mse'] for x in xs])
  gain=float(b.sum()/c.sum());cr=xs[0]['added_cost_ratio']
  out.append({'variant':key[0],'rank':key[1],'selector':key[2],'k':key[3],'B':key[4],'kind':key[5],'param':key[6],
   'aggregate_linear_gain':gain,'aggregate_adjusted_gain':gain/(1+cr),'wins':int(np.sum(c<b)),
   'worst_candidate_over_baseline':float(np.max(c/b)),'mean_cosine':float(np.mean([x['correction_cosine'] for x in xs])),
   'mean_variance_ratio':float(np.mean([x['variance_ratio'] for x in xs])),'added_cost_ratio':cr})
 return sorted(out,key=lambda x:x['aggregate_adjusted_gain'],reverse=True)

ds=summarize(disc);vs=summarize(val);alls=summarize(seeds)
dnon=[x for x in ds if not (x['B']==1 and x['kind'] in ('zgate','js'))]
selected=dnon[0];key=tuple(selected[k] for k in ('variant','rank','selector','k','B','kind','param'))
frozen=next(x for x in vs if tuple(x[k] for k in ('variant','rank','selector','k','B','kind','param'))==key)
print('SELECTED',json.dumps(selected,indent=2));print('FROZEN',json.dumps(frozen,indent=2))
print('TOP RAW DISC')
for x in sorted(dnon,key=lambda z:z['aggregate_linear_gain'],reverse=True)[:10]:print(x)
print('TOP RAW VAL')
for x in sorted(vs,key=lambda z:z['aggregate_linear_gain'],reverse=True)[:10]:print(x)
Path('/mnt/data/whest_continue/sparse_pilot_cv_preexact.json').write_text(json.dumps({'seeds':seeds,'discovery':disc,'validation':val,'selected':selected,'frozen':frozen,'discovery_top':ds[:50],'validation_top':vs[:50],'all_top':alls[:50]},indent=2))
