from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/whest_mlmc');sys.path[:0]=['/mnt/data/whest_continue',str(ROOT/'latest/agent1/agent1_residual_spectrum_final'),str(ROOT/'agent9_10_oracle_bundle/agent9_10_oracle_bundle')]
from agent1_residual_spectrum_screen import make_weights
from sparse_pilot_layer31 import capture_baseline
import sparse_cubic_pilot_cv as feat
K=8;RIDGE=1.;ALPHA=.25

def run(seed):
 w=make_weights(seed);H31,A31,H32,base=capture_baseline(w);Y=np.maximum(H32,0).astype(float);yb=Y.reshape(129,512,256).mean(1);m=A31.mean(0,dtype=float);sd=np.maximum(A31.std(0,dtype=float),1e-8);idx=feat.all_orders(H31,A31,H32,w[31])['gaussian_gap_sens'][:K];Z=feat.feature_values(A31,m,sd,idx,'h3');zb=feat.feature_block_means(Z.astype(np.float32));anchor=zb.mean(0);fold=np.arange(129)%6;corrected=np.empty_like(yb)
 for f in range(6):
  te=fold==f;tr=~te;z=zb[tr];y=yb[tr];mz=z.mean(0);my=y.mean(0);Czz=(z-mz).T@(z-mz);Czy=(z-mz).T@(y-my);coef=np.linalg.solve(Czz+RIDGE*np.diag(np.maximum(np.diag(Czz),1e-12)),Czy);corrected[te]=yb[te]-ALPHA*(zb[te]-anchor)@coef
 basevar=float(np.mean(yb.var(0,ddof=1)));candvar=float(np.mean(corrected.var(0,ddof=1)));U,S,Vt=np.linalg.svd(yb-yb.mean(0),full_matrices=False);v=Vt[0]
 return {'seed':seed,'baseline_only_block_variance_ratio':candvar/basevar,'baseline_only_pca1_variance_ratio':float(np.var((corrected-corrected.mean(0))@v,ddof=1)/np.var((yb-yb.mean(0))@v,ddof=1))}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);a=ap.parse_args();r=run(a.seed);Path(f'/mnt/data/whest_continue/baseline_gate_{a.seed}.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
