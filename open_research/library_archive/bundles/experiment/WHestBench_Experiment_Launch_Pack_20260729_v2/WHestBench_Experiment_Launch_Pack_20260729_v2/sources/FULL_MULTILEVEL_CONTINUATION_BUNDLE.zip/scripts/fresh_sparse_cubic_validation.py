from __future__ import annotations
import argparse,gc,json,sys,time
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/whest_mlmc');OUT=Path('/mnt/data/whest_continue/fresh_sparse_cubic_rows');OUT.mkdir(exist_ok=True)
A1=ROOT/'latest/agent1/agent1_residual_spectrum_final';A9=ROOT/'agent9_10_oracle_bundle/agent9_10_oracle_bundle'
sys.path[:0]=[str(A1),str(A9),'/mnt/data/whest_continue']
from agent1_residual_spectrum_screen import make_weights,first_activation_matrix,mse
from arc_experiments import rotation
from sparse_pilot_layer31 import pilot_points,capture_baseline,propagate_to31
import sparse_cubic_pilot_cv as s

REF_SEEDS=list(range(960000,960008));K=32;B=8;RIDGE=1.0;BASE_ALPHA=.5;ZCAP=.057
COST_RATIO=0.06447205062984496

def forward_final_mean(w,R):
 A=first_activation_matrix(w[0],R);buf=np.empty_like(A)
 for W in w[1:]:
  np.matmul(A,W,out=buf);np.maximum(buf,0,out=buf);A,buf=buf,A
 return A.mean(0,dtype=np.float64)
def cos(a,b):return float(np.dot(a,b)/max(np.linalg.norm(a)*np.linalg.norm(b),1e-300))
def run(seed):
 t0=time.time();w=make_weights(seed);pp=pilot_points()[:B*512]
 H31,A31,H32,base=capture_baseline(w);Y=np.maximum(H32,0).astype(np.float64)
 m=A31.mean(0,dtype=float);sd=np.maximum(A31.std(0,dtype=float),1e-8);orders=s.all_orders(H31,A31,H32,w[31]);idx=orders['gaussian_gap_sens'][:K]
 Z=s.feature_values(A31,m,sd,idx,'h3');fs=s.stats_by_fold(Z,Y)
 PA=propagate_to31(w,pp);PZ=s.feature_values(PA,m,sd,idx,'h3');anchor=s.feature_block_means(PZ.astype(np.float32)).mean(0)
 corr=s.correction_for_anchor(fs,K,anchor,RIDGE)
 ybm=Y.reshape(129,512,256).mean(1);se=np.sqrt(ybm.var(0,ddof=1)/129);z=float(np.sqrt(np.mean((BASE_ALPHA*corr/np.maximum(se,1e-12))**2)))
 alpha=min(BASE_ALPHA,ZCAP/max(z,1e-12));cand=base-alpha*corr
 # Independent complete-design references.
 refs=[]
 for rs in REF_SEEDS:
  refs.append(forward_final_mean(w,rotation(rs)));gc.collect()
 refs=np.stack(refs);t1=refs[:4].mean(0);t2=refs[4:].mean(0);target=refs.mean(0);floor=mse(t1,t2)/4
 bm=mse(base,target);cm=mse(cand,target)
 out={'seed':seed,'config':{'K':K,'B':B,'ridge':RIDGE,'base_alpha':BASE_ALPHA,'zcap':ZCAP,'cost_ratio':COST_RATIO},
  'alpha':alpha,'correction_z_rms':z,'baseline_mse':bm,'candidate_mse':cm,'candidate_over_baseline':cm/bm,'raw_gain':bm/cm,'adjusted_gain':(bm/cm)/(1+COST_RATIO),
  'reference_noise_floor':floor,'baseline_noise_corrected':max(0,bm-floor),'candidate_noise_corrected':max(0,cm-floor),
  'noise_corrected_gain':max(0,bm-floor)/max(max(0,cm-floor),1e-300),
  'half1_baseline_mse':mse(base,t1),'half1_candidate_mse':mse(cand,t1),'half2_baseline_mse':mse(base,t2),'half2_candidate_mse':mse(cand,t2),
  'reference_half_disagreement':mse(t1,t2),'correction_norm':float(np.linalg.norm(alpha*corr)),'elapsed_seconds':time.time()-t0}
 return out
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);a=ap.parse_args();r=run(a.seed);(OUT/f'{a.seed}.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
