from __future__ import annotations
import json,sys,gc
from pathlib import Path
import numpy as np
sys.path[:0]=['/mnt/data/whest_continue','/mnt/data/whest_mlmc/latest/agent1/agent1_residual_spectrum_final','/mnt/data/whest_mlmc/agent9_10_oracle_bundle/agent9_10_oracle_bundle']
import sparse_cubic_pilot_cv as s
from sparse_pilot_layer31 import pilot_points,capture_baseline,propagate_to31,block_means
from agent1_residual_spectrum_screen import make_weights,mse
from arc_cv.splits_v1 import SPLITS
ROOT=Path('/mnt/data/whest_mlmc')
CFG={'selector':'gaussian_gap_sens','k':32,'feature':'h3','B':8,'ridge':1.0,'alpha':0.5}

def cos(a,b):return float(np.dot(a,b)/max(np.linalg.norm(a)*np.linalg.norm(b),1e-300))
def run(seed,pp):
 rec=json.loads((ROOT/f'layer31_records/{seed}.json').read_text());target=np.array(rec['target_final'],float)
 w=make_weights(seed);H31,A31,H32,base=capture_baseline(w);Y=np.maximum(H32,0).astype(float);bm=mse(base,target)
 m=A31.mean(0,dtype=float);sd=np.maximum(A31.std(0,dtype=float),1e-8);orders=s.all_orders(H31,A31,H32,w[31]);idx=orders[CFG['selector']][:CFG['k']]
 Z=s.feature_values(A31,m,sd,idx,CFG['feature']);fs=s.stats_by_fold(Z,Y)
 PA=propagate_to31(w,pp[:16*512]);PZ=s.feature_values(PA,m,sd,idx,CFG['feature']);pb=s.feature_block_means(PZ.astype(np.float32))
 def corr(block_ids):
  anchor=pb[block_ids].mean(0);return s.correction_for_anchor(fs,CFG['k'],anchor,CFG['ridge'])
 c1=corr(np.arange(0,4));c2=corr(np.arange(4,8));c8=corr(np.arange(0,8));c_alt=corr(np.arange(8,16));c16=corr(np.arange(0,16))
 pred=base-CFG['alpha']*c8;cm=mse(pred,target)
 # Final-output Kerdock block standard error and correction z-score.
 ybm=Y.reshape(129,512,256).mean(1);se=np.sqrt(ybm.var(0,ddof=1)/129);znorm=float(np.sqrt(np.mean((CFG['alpha']*c8/np.maximum(se,1e-12))**2)))
 recout={'seed':seed,'ratio':cm/bm,'raw_gain':bm/cm,'baseline_mse':bm,'candidate_mse':cm,
  'half_cos':cos(c1,c2),'nested_cos_8_16':cos(c8,c16),'independent_cos_8_alt8':cos(c8,c_alt),
  'half_rel_disagreement':float(np.linalg.norm(c1-c2)/max(0.5*(np.linalg.norm(c1)+np.linalg.norm(c2)),1e-300)),
  'independent_rel_disagreement':float(np.linalg.norm(c8-c_alt)/max(0.5*(np.linalg.norm(c8)+np.linalg.norm(c_alt)),1e-300)),
  'correction_norm':float(np.linalg.norm(CFG['alpha']*c8)),'baseline_norm':float(np.linalg.norm(base)),
  'correction_z_rms':znorm,'pilot_anchor_half_cos':cos(pb[:4].mean(0),pb[4:8].mean(0)),
  'pilot_anchor_rel_disagreement':float(np.linalg.norm(pb[:4].mean(0)-pb[4:8].mean(0))/max(0.5*(np.linalg.norm(pb[:4].mean(0))+np.linalg.norm(pb[4:8].mean(0))),1e-300))}
 return recout

def main():
 pp=pilot_points();rows=[]
 for seed in SPLITS['screen']:
  print(seed,flush=True);rows.append(run(seed,pp));print(rows[-1],flush=True);gc.collect()
 out={'config':CFG,'rows':rows};Path('/mnt/data/whest_continue/sparse_cubic_gate_diagnostics.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
