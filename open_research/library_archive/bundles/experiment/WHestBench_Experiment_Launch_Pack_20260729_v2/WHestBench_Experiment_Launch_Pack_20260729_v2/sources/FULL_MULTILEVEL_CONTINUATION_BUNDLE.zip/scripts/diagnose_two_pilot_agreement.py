from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/whest_mlmc'); A1=ROOT/'latest/agent1/agent1_residual_spectrum_final'; A9=ROOT/'agent9_10_oracle_bundle/agent9_10_oracle_bundle'
sys.path[:0]=[str(A1),str(A9),'/mnt/data/whest_continue']
from agent1_residual_spectrum_screen import make_weights
from sparse_pilot_layer31 import pilot_points,capture_baseline,propagate_to31
import sparse_cubic_pilot_cv as feat
import sparse_cubic_block_cv as block
K=8; RIDGE=1.0
OUT=Path('/mnt/data/whest_continue/two_pilot_agreement');OUT.mkdir(exist_ok=True)

def cosine(a,b):
    na=np.linalg.norm(a);nb=np.linalg.norm(b)
    return float(a@b/max(na*nb,1e-300))
def rel_diff(a,b):
    return float(np.linalg.norm(a-b)/max(np.linalg.norm((a+b)/2),1e-300))
def run(seed):
    w=make_weights(seed); pp=pilot_points()[:1024]
    H31,A31,H32,base=capture_baseline(w);Y=np.maximum(H32,0).astype(float);yb=Y.reshape(129,512,256).mean(1)
    m=A31.mean(0,dtype=float);sd=np.maximum(A31.std(0,dtype=float),1e-8)
    idx=feat.all_orders(H31,A31,H32,w[31])['gaussian_gap_sens'][:K]
    Z=feat.feature_values(A31,m,sd,idx,'h3');zb=feat.feature_block_means(Z.astype(np.float32));fs=block.block_stats(zb,yb)
    PA=propagate_to31(w,pp);PZ=feat.feature_values(PA,m,sd,idx,'h3');pb=feat.feature_block_means(PZ.astype(np.float32))[:2]
    c1=block.corr_anchor(fs,K,pb[0],RIDGE);c2=block.corr_anchor(fs,K,pb[1],RIDGE);cm=block.corr_anchor(fs,K,pb.mean(0),RIDGE)
    out={'seed':seed,'anchor_cos':cosine(pb[0],pb[1]),'anchor_rel_diff':rel_diff(pb[0],pb[1]),'corr_cos':cosine(c1,c2),'corr_rel_diff':rel_diff(c1,c2),'corr1_norm':float(np.linalg.norm(c1)),'corr2_norm':float(np.linalg.norm(c2)),'corr_mean_norm':float(np.linalg.norm(cm))}
    (OUT/f'{seed}.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--seed',type=int,required=True);a=p.parse_args();run(a.seed)
