from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/whest_mlmc')
sys.path[:0]=['/mnt/data/whest_continue',str(ROOT/'latest/agent1/agent1_residual_spectrum_final'),str(ROOT/'agent9_10_oracle_bundle/agent9_10_oracle_bundle')]
from agent1_residual_spectrum_screen import make_weights
from sparse_pilot_layer31 import pilot_points,capture_baseline,propagate_to31
import sparse_cubic_pilot_cv as feat
K=8;RIDGE=1.;ALPHA=.25

def cos(a,b):return float(np.dot(a,b)/max(np.linalg.norm(a)*np.linalg.norm(b),1e-300))
def run(seed):
 w=make_weights(seed);pp=pilot_points()[:4*512];H31,A31,H32,base=capture_baseline(w);Y=np.maximum(H32,0).astype(float);yb=Y.reshape(129,512,256).mean(1);m=A31.mean(0,dtype=float);sd=np.maximum(A31.std(0,dtype=float),1e-8);orders=feat.all_orders(H31,A31,H32,w[31]);idx=orders['gaussian_gap_sens'][:K];Z=feat.feature_values(A31,m,sd,idx,'h3');zb=feat.feature_block_means(Z.astype(np.float32));PA=propagate_to31(w,pp);PZ=feat.feature_values(PA,m,sd,idx,'h3');pb=feat.feature_block_means(PZ.astype(np.float32));anchors=[pb[0],pb[1],pb[:2].mean(0),pb[2:4].mean(0)]
 fold=np.arange(129)%6; corrected=np.empty_like(yb);fold_corr=[];coefs=[]
 for f in range(6):
  te=fold==f;tr=~te;zt=zb[tr];yt=yb[tr];mz=zt.mean(0);my=yt.mean(0);Czz=(zt-mz).T@(zt-mz);Czy=(zt-mz).T@(yt-my);coef=np.linalg.solve(Czz+RIDGE*np.diag(np.maximum(np.diag(Czz),1e-12)),Czy);coefs.append(coef)
  corrected[te]=yb[te]-ALPHA*(zb[te]-anchors[2])@coef;fold_corr.append((zb[te].mean(0)-anchors[2])@coef)
 # full correction for each pilot anchor, average fold weighting
 def correction(anchor):
  c=np.zeros(256)
  for f,coef in enumerate(coefs):
   te=fold==f;c+=te.sum()*((zb[te].mean(0)-anchor)@coef)
  return c/129
 cs=[correction(a) for a in anchors];base_var=float(np.mean(yb.var(0,ddof=1)));cand_var=float(np.mean(corrected.var(0,ddof=1)))
 # Variance in dominant output PCA direction of block means.
 U,S,Vt=np.linalg.svd(yb-yb.mean(0),full_matrices=False);v=Vt[0];bv=float(np.var((yb-yb.mean(0))@v,ddof=1));cv=float(np.var((corrected-corrected.mean(0))@v,ddof=1))
 fc=np.stack(fold_corr);meanfc=fc.mean(0)
 return {'seed':seed,'block_variance_ratio':cand_var/base_var,'pca1_variance_ratio':cv/bv,'pilot_single_cos':cos(cs[0],cs[1]),'pilot_pair_cos':cos(cs[2],cs[3]),'pilot_correction_rel_disagreement':float(np.linalg.norm(cs[0]-cs[1])/max(.5*(np.linalg.norm(cs[0])+np.linalg.norm(cs[1])),1e-300)),'fold_correction_mean_cos':float(np.mean([cos(x,meanfc) for x in fc])),'fold_correction_rel_sd':float(np.sqrt(np.mean((fc-meanfc)**2))/max(np.sqrt(np.mean(meanfc**2)),1e-300)),'correction_norm':float(np.linalg.norm(ALPHA*cs[2])),'base_block_var':base_var}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);a=ap.parse_args();r=run(a.seed);print(json.dumps(r,indent=2));Path(f'/mnt/data/whest_continue/block_diag_{a.seed}.json').write_text(json.dumps(r,indent=2))
