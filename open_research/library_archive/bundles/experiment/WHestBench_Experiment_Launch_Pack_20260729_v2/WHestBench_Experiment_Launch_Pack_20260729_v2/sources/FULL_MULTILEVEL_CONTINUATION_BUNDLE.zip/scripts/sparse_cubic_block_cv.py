from __future__ import annotations
import gc,json,sys,time
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/whest_mlmc');A1=ROOT/'latest/agent1/agent1_residual_spectrum_final';A9=ROOT/'agent9_10_oracle_bundle/agent9_10_oracle_bundle'
sys.path[:0]=[str(A1),str(A9),'/mnt/data/whest_continue']
from agent1_residual_spectrum_screen import make_weights,mse
from arc_cv.splits_v1 import SPLITS
from sparse_pilot_layer31 import pilot_points,capture_baseline,propagate_to31
import sparse_cubic_pilot_cv as base
B_COUNTS=[2,4,8,16,32];KS=[8,16,32,64,128];FEATURES=['h3','cubic'];SELECTORS=['skew_sens','gaussian_gap_sens','rank_blend'];RIDGES=[.01,.1,1.,10.,100.];ALPHAS=[.25,.5,.75,1.]

def block_stats(Z,Y,nfold=6):
 fold=np.arange(len(Z))%nfold;out=[]
 for f in range(nfold):
  mask=fold==f;z=Z[mask];y=Y[mask];out.append({'n':len(z),'sz':z.sum(0),'sy':y.sum(0),'szz':z.T@z,'szy':z.T@y})
 return out

def corr_anchor(fs,k,anchor,ridge):
 nall=sum(x['n'] for x in fs);tz=sum((x['sz'][:k] for x in fs),np.zeros(k));ty=sum((x['sy'] for x in fs),np.zeros(256));tzz=sum((x['szz'][:k,:k] for x in fs),np.zeros((k,k)));tzy=sum((x['szy'][:k] for x in fs),np.zeros((k,256)));corr=np.zeros(256)
 for x in fs:
  nt=x['n'];n=nall-nt;mz=(tz-x['sz'][:k])/n;my=(ty-x['sy'])/n;Czz=(tzz-x['szz'][:k,:k])-n*np.outer(mz,mz);Czy=(tzy-x['szy'][:k])-n*np.outer(mz,my);scale=np.maximum(np.diag(Czz),1e-12);coef=np.linalg.solve(Czz+ridge*np.diag(scale),Czy);corr+=nt*((x['sz'][:k]/nt-anchor)@coef)
 return corr/nall

def cost(B,k): return (B/129)*(31/32) + (129*k*(k+256))/(66048*32*256*256)
def key(x):return tuple(x[z] for z in ('selector','k','feature','B','ridge','alpha'))
def run(seed,pp):
 t0=time.time();rec=json.loads((ROOT/f'layer31_records/{seed}.json').read_text());target=np.array(rec['target_final'],float);w=make_weights(seed);H31,A31,H32,basef=capture_baseline(w);Y=np.maximum(H32,0).astype(float);yb=Y.reshape(129,512,256).mean(1);bm=mse(basef,target);m=A31.mean(0,dtype=float);sd=np.maximum(A31.std(0,dtype=float),1e-8);orders=base.all_orders(H31,A31,H32,w[31]);PA=propagate_to31(w,pp);rows=[]
 for sel in SELECTORS:
  idxall=orders[sel][:max(KS)]
  for feat in FEATURES:
   Z=base.feature_values(A31,m,sd,idxall,feat);zb=base.feature_block_means(Z.astype(np.float32));PZ=base.feature_values(PA,m,sd,idxall,feat);pb=base.feature_block_means(PZ.astype(np.float32));pref=np.cumsum(pb,axis=0)/np.arange(1,len(pb)+1)[:,None];fs=block_stats(zb,yb)
   for k in KS:
    for B in B_COUNTS:
     anchor=pref[B-1,:k]
     for ridge in RIDGES:
      c=corr_anchor(fs,k,anchor,ridge)
      for alpha in ALPHAS:
       pred=basef-alpha*c;cm=mse(pred,target);cr=cost(B,k);rows.append({'selector':sel,'k':k,'feature':feat,'B':B,'ridge':ridge,'alpha':alpha,'mse':cm,'gain':bm/max(cm,1e-300),'adjusted_gain':(bm/max(cm,1e-300))/(1+cr),'added_cost_ratio':cr})
   del Z,zb,PZ,pb,fs;gc.collect()
 return {'seed':seed,'baseline_mse':bm,'rows':rows,'elapsed':time.time()-t0}
def summarize(records,seeds):
 rr=[r for r in records if r['seed'] in seeds];maps=[{key(x):x for x in r['rows']} for r in rr];qs=list(maps[0]);out=[]
 for q in qs:
  xs=[m[q] for m in maps];b=np.array([r['baseline_mse'] for r in rr]);c=np.array([x['mse'] for x in xs]);g=float(b.sum()/c.sum());cr=xs[0]['added_cost_ratio'];out.append({'selector':q[0],'k':q[1],'feature':q[2],'B':q[3],'ridge':q[4],'alpha':q[5],'raw_gain':g,'adjusted_gain':g/(1+cr),'wins':int((c<b).sum()),'worst':float((c/b).max()),'added_cost_ratio':cr})
 return sorted(out,key=lambda x:x['adjusted_gain'],reverse=True)
def main():
 out=Path('/mnt/data/whest_continue/sparse_cubic_block_records');out.mkdir(exist_ok=True);pp=pilot_points();seeds=list(SPLITS['screen']);records=[]
 for seed in seeds:
  p=out/f'{seed}.json'
  if p.exists():r=json.load(open(p))
  else:print('network',seed,flush=True);r=run(seed,pp);p.write_text(json.dumps(r));print(' done',r['elapsed'],flush=True)
  records.append(r)
 disc,val=seeds[:4],seeds[4:];ds=summarize(records,disc);vs=summarize(records,val);alls=summarize(records,seeds);sel=ds[0];q=key(sel);frozen=next(x for x in vs if key(x)==q);payload={'selected':sel,'frozen':frozen,'all_best':alls[0],'discovery_top':ds[:50],'validation_top':vs[:50],'all_top':alls[:50]};Path('/mnt/data/whest_continue/sparse_cubic_block_summary.json').write_text(json.dumps(payload,indent=2));print(json.dumps({'selected':sel,'frozen':frozen,'all_best':alls[0]},indent=2))
if __name__=='__main__':main()
