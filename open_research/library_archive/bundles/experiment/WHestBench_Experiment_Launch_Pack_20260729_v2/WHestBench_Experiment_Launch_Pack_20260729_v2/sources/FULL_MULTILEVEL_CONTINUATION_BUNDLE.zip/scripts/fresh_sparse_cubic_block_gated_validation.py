from __future__ import annotations
import argparse,gc,json,sys,time
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/whest_mlmc');OUT=Path('/mnt/data/whest_continue/fresh_sparse_cubic_block_gated_rows');OUT.mkdir(exist_ok=True)
A1=ROOT/'latest/agent1/agent1_residual_spectrum_final';A9=ROOT/'agent9_10_oracle_bundle/agent9_10_oracle_bundle'
sys.path[:0]=[str(A1),str(A9),'/mnt/data/whest_continue']
from agent1_residual_spectrum_screen import make_weights,first_activation_matrix,mse
from arc_experiments import rotation
from sparse_pilot_layer31 import pilot_points,capture_baseline,propagate_to31
import sparse_cubic_pilot_cv as feat
import sparse_cubic_block_cv as block
REF_SEEDS=list(range(970000,970008));K=8;B=2;RIDGE=1.;ALPHA=.25;COST=.015021346798238827;GATE=1.0

def forward_final_mean(w,R):
 A=first_activation_matrix(w[0],R);buf=np.empty_like(A)
 for W in w[1:]:np.matmul(A,W,out=buf);np.maximum(buf,0,out=buf);A,buf=buf,A
 return A.mean(0,dtype=np.float64)
def block_variance_ratio(zb,yb,anchor):
 fold=np.arange(129)%6;corrected=np.empty_like(yb)
 for f in range(6):
  te=fold==f;tr=~te;z=zb[tr];y=yb[tr];mz=z.mean(0);my=y.mean(0);Czz=(z-mz).T@(z-mz);Czy=(z-mz).T@(y-my);coef=np.linalg.solve(Czz+RIDGE*np.diag(np.maximum(np.diag(Czz),1e-12)),Czy);corrected[te]=yb[te]-ALPHA*(zb[te]-anchor)@coef
 return float(np.mean(corrected.var(0,ddof=1))/np.mean(yb.var(0,ddof=1)))
def run(seed):
 t0=time.time();w=make_weights(seed);pp=pilot_points()[:B*512];H31,A31,H32,base=capture_baseline(w);Y=np.maximum(H32,0).astype(float);yb=Y.reshape(129,512,256).mean(1);m=A31.mean(0,dtype=float);sd=np.maximum(A31.std(0,dtype=float),1e-8);orders=feat.all_orders(H31,A31,H32,w[31]);idx=orders['gaussian_gap_sens'][:K];Z=feat.feature_values(A31,m,sd,idx,'h3');zb=feat.feature_block_means(Z.astype(np.float32));fs=block.block_stats(zb,yb);PA=propagate_to31(w,pp);PZ=feat.feature_values(PA,m,sd,idx,'h3');anchor=feat.feature_block_means(PZ.astype(np.float32)).mean(0);corr=block.corr_anchor(fs,K,anchor,RIDGE);vr=block_variance_ratio(zb,yb,anchor);applied=vr<GATE;cand=base-ALPHA*corr if applied else base.copy()
 refs=[]
 for rs in REF_SEEDS:refs.append(forward_final_mean(w,rotation(rs)));gc.collect()
 refs=np.stack(refs);t1=refs[:4].mean(0);t2=refs[4:].mean(0);target=refs.mean(0);floor=mse(t1,t2)/4;bm=mse(base,target);cm=mse(cand,target)
 return {'seed':seed,'config':{'K':K,'B':B,'ridge':RIDGE,'alpha':ALPHA,'gate':GATE,'cost_ratio':COST},'block_variance_ratio':vr,'applied':applied,'baseline_mse':bm,'candidate_mse':cm,'candidate_over_baseline':cm/bm,'raw_gain':bm/cm,'adjusted_gain':(bm/cm)/(1+COST),'reference_noise_floor':floor,'baseline_noise_corrected':max(0,bm-floor),'candidate_noise_corrected':max(0,cm-floor),'noise_corrected_gain':max(0,bm-floor)/max(max(0,cm-floor),1e-300),'half1_baseline_mse':mse(base,t1),'half1_candidate_mse':mse(cand,t1),'half2_baseline_mse':mse(base,t2),'half2_candidate_mse':mse(cand,t2),'reference_half_disagreement':mse(t1,t2),'elapsed_seconds':time.time()-t0}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--seed',type=int,required=True);a=ap.parse_args();r=run(a.seed);(OUT/f'{a.seed}.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
