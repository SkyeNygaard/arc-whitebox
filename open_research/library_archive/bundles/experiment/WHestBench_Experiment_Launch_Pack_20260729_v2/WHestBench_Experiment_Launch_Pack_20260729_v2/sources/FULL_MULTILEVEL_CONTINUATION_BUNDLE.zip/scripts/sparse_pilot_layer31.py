from __future__ import annotations

import gc
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path('/mnt/data/whest_mlmc')
A1 = ROOT / 'latest/agent1/agent1_residual_spectrum_final'
A9 = ROOT / 'agent9_10_oracle_bundle/agent9_10_oracle_bundle'
sys.path[:0] = [str(A1), str(A9)]

from agent1_residual_spectrum_screen import first_activation_matrix, make_weights, mse
from arc_cv.kerdock import full_real_kerdock_bases, chi_mean
from arc_cv.splits_v1 import SPLITS
from arc_experiments import D, rotation

R0 = np.load(A1 / 'config/kerdock_rotation_seed3.npy', allow_pickle=False).astype(np.float32)
PILOT_ROT_SEEDS = list(range(950000, 950008))
PILOT_BASIS_INDICES = [0, 17, 43, 89]
B_COUNTS = [1, 2, 4, 8, 16, 32]
KS = [8, 12, 16, 24]
SELECTORS = ['gaussian_gap_sens', 'block_std_sens', 'halfdiff_sens', 'rank_blend']
ALPHAS = [0.25, 0.5, 0.75, 1.0]
ZS = [0.5, 1.0, 1.5, 2.0]
LAMBDAS = [0.5, 1.0, 2.0, 4.0]


def capture_baseline(weights: list[np.ndarray]):
    A = first_activation_matrix(weights[0], R0)
    B = np.empty_like(A)
    for W in weights[1:30]:
        np.matmul(A, W, out=B); np.maximum(B, 0, out=B); A, B = B, A
    H31 = A @ weights[30]
    A31 = np.maximum(H31, 0).astype(np.float32, copy=False)
    H32 = A31 @ weights[31]
    Y32 = np.maximum(H32, 0)
    return H31, A31, H32, Y32.mean(0, dtype=np.float64)


def propagate_to31(weights: list[np.ndarray], points: np.ndarray):
    # The optimized first-layer helper is specialized to the complete 66,048-row
    # Kerdock design. Independent pilot clouds use the ordinary dense product.
    A = np.maximum(points @ weights[0], 0).astype(np.float32, copy=False)
    B = np.empty_like(A)
    for W in weights[1:31]:
        np.matmul(A, W, out=B); np.maximum(B, 0, out=B); A, B = B, A
    return A


def pilot_points() -> np.ndarray:
    bases = list(full_real_kerdock_bases(D))
    r = chi_mean(D)
    blocks = []
    for rs in PILOT_ROT_SEEDS:
        R = rotation(rs)
        for bi in PILOT_BASIS_INDICES:
            b = bases[bi].astype(np.float32) @ R
            blocks.append(np.concatenate([b, -b], axis=0) * r)
    return np.ascontiguousarray(np.concatenate(blocks, axis=0).astype(np.float32))


def block_means(A: np.ndarray) -> np.ndarray:
    return A.reshape(-1, 512, D).mean(1, dtype=np.float64)


def baseline_block_stats(A31: np.ndarray):
    bm = block_means(A31)
    return bm.std(0, ddof=1), bm[:64].mean(0) - bm[64:].mean(0)


def rank_scores(x: np.ndarray) -> np.ndarray:
    order = np.argsort(-x)
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(len(x), dtype=np.float64)
    return 1.0 - ranks / max(len(x) - 1, 1)


def selectors(H31: np.ndarray, A31: np.ndarray, H32: np.ndarray, W32: np.ndarray):
    p31 = (H31 > 0).mean(0, dtype=np.float64)
    mu31 = A31.mean(0, dtype=np.float64)
    sigma31 = H31.std(0, dtype=np.float64)
    gaussian_gap = sigma31 / math.sqrt(2 * math.pi) - mu31
    p32 = (H32 > 0).mean(0, dtype=np.float64)
    sensitivity = np.linalg.norm(W32.astype(np.float64) * p32[None, :], axis=1)
    bstd, hdiff = baseline_block_stats(A31)
    scores = {
        'gaussian_gap_sens': np.abs(gaussian_gap) * sensitivity,
        'block_std_sens': bstd * sensitivity,
        'halfdiff_sens': np.abs(hdiff) * sensitivity,
    }
    scores['rank_blend'] = (rank_scores(scores['gaussian_gap_sens']) + rank_scores(scores['block_std_sens']) + rank_scores(scores['halfdiff_sens'])) / 3
    return {k: np.argsort(-v).astype(int) for k, v in scores.items()}, p32


def method_delta(dhat: np.ndarray, se: np.ndarray, kind: str, param: float) -> np.ndarray:
    if kind == 'alpha':
        return param * dhat
    if kind == 'zgate':
        return 0.75 * dhat * (np.abs(dhat) >= param * se)
    if kind == 'js':
        shrink = np.maximum(0.0, 1.0 - param * se * se / np.maximum(dhat * dhat, 1e-300))
        return shrink * dhat
    raise ValueError(kind)


def solve_shift_column(a: np.ndarray, target: float) -> np.ndarray:
    cur = float(np.mean(a, dtype=np.float64))
    target = max(float(target), 0.0)
    if target >= cur:
        return np.maximum(a + np.float32(target - cur), 0) - a
    if target <= 0:
        return -a
    v = np.sort(a.astype(np.float64))[::-1]
    c = np.cumsum(v); n = len(v); k = np.arange(1, n + 1, dtype=np.float64)
    s = (c - n * target) / k
    nxt = np.empty_like(v); nxt[:-1] = v[1:]; nxt[-1] = -np.inf
    valid = (s <= v + 1e-12) & (s >= nxt - 1e-12) & (s >= -1e-12)
    ids = np.flatnonzero(valid)
    shift = -float(s[ids[0]]) if len(ids) else None
    if shift is None:
        lo, hi = 0.0, float(v[0])
        for _ in range(45):
            mid = 0.5 * (lo + hi)
            val = float(np.maximum(a.astype(np.float64) - mid, 0).mean())
            if val > target: lo = mid
            else: hi = mid
        shift = -0.5 * (lo + hi)
    return np.maximum(a + np.float32(shift), 0) - a


def exact_replay(A31: np.ndarray, H32: np.ndarray, W32: np.ndarray, idx: np.ndarray, delta: np.ndarray):
    # Modify only selected columns, then replay the true final layer.
    H = H32.copy()
    for j, d in zip(idx, delta):
        Dcol = solve_shift_column(A31[:, j], float(A31[:, j].mean(dtype=np.float64) + d))
        H += Dcol[:, None] * W32[j][None, :]
    return np.maximum(H, 0).mean(0, dtype=np.float64)


def configs():
    out = []
    for sel in SELECTORS:
        for k in KS:
            for B in B_COUNTS:
                for a in ALPHAS: out.append((sel, k, B, 'alpha', a))
                for z in ZS: out.append((sel, k, B, 'zgate', z))
                for l in LAMBDAS: out.append((sel, k, B, 'js', l))
    return out


def added_cost_ratio(B: int) -> float:
    # Pilot layer-31 propagation plus one full final-layer replay, relative to 32-layer full Kerdock.
    return (B / 129.0) * (31.0 / 32.0) + 1.0 / 32.0


def run_network(seed: int, pp: np.ndarray):
    t0 = time.time()
    rec = json.loads((ROOT / f'layer31_records/{seed}.json').read_text())
    target31 = np.asarray(rec['target31'], dtype=np.float64)
    targetf = np.asarray(rec['target_final'], dtype=np.float64)
    weights = make_weights(seed)
    H31, A31, H32, basef = capture_baseline(weights)
    base31 = A31.mean(0, dtype=np.float64)
    base_mse = mse(basef, targetf)
    orders, p32 = selectors(H31, A31, H32, weights[31])
    PA = propagate_to31(weights, pp)
    pbm = block_means(PA)
    del PA; gc.collect()
    prefix_mean = np.cumsum(pbm, axis=0) / np.arange(1, len(pbm) + 1)[:, None]
    prefix_var = np.zeros_like(prefix_mean)
    for b in B_COUNTS:
        prefix_var[b-1] = pbm[:b].var(0, ddof=1) / b if b > 1 else np.full(D, np.inf)
    rows = []
    for cfg in configs():
        sel, k, B, kind, param = cfg
        idx = orders[sel][:k]
        dhat = prefix_mean[B-1, idx] - base31[idx]
        se = np.sqrt(prefix_var[B-1, idx]) if B > 1 else np.full(k, np.inf)
        d = method_delta(dhat, se, kind, param)
        # Cheap first-order final prediction for configuration selection.
        response = weights[31][idx].astype(np.float64) * p32[None, :]
        pred_lin = basef + d @ response
        cmse = mse(pred_lin, targetf)
        true_d = target31[idx] - base31[idx]
        denom = max(float(np.linalg.norm(d) * np.linalg.norm(true_d)), 1e-300)
        rows.append({
            'selector': sel, 'k': k, 'B': B, 'kind': kind, 'param': param,
            'linear_mse': cmse, 'linear_ratio': base_mse / max(cmse, 1e-300),
            'added_cost_ratio': added_cost_ratio(B),
            'linear_adjusted_gain': (base_mse / max(cmse, 1e-300)) / (1 + added_cost_ratio(B)),
            'correction_cosine': float(np.dot(d, true_d) / denom),
            'correction_rms': float(np.sqrt(np.mean(d*d))),
            'true_defect_rms_selected': float(np.sqrt(np.mean(true_d*true_d))),
        })
    return {
        'seed': seed, 'baseline_mse': base_mse, 'rows': rows,
        'elapsed_seconds': time.time() - t0,
    }, (weights, A31, H32, targetf, basef, orders, pbm, base31, target31)


def summarize(records, seeds):
    rs = [r for r in records if r['seed'] in seeds]
    keys = [(x['selector'], x['k'], x['B'], x['kind'], x['param']) for x in rs[0]['rows']]
    out = []
    for key in keys:
        b = np.array([r['baseline_mse'] for r in rs])
        xs = [next(x for x in r['rows'] if (x['selector'],x['k'],x['B'],x['kind'],x['param']) == key) for r in rs]
        c = np.array([x['linear_mse'] for x in xs])
        gain = float(b.sum()/c.sum())
        cr = xs[0]['added_cost_ratio']
        out.append({
            'selector': key[0], 'k': key[1], 'B': key[2], 'kind': key[3], 'param': key[4],
            'aggregate_linear_gain': gain,
            'aggregate_linear_adjusted_gain': gain/(1+cr),
            'wins': int(np.sum(c<b)), 'worst_candidate_over_baseline': float(np.max(c/b)),
            'mean_cosine': float(np.mean([x['correction_cosine'] for x in xs])),
            'added_cost_ratio': cr,
        })
    return sorted(out, key=lambda x: x['aggregate_linear_adjusted_gain'], reverse=True)


def main():
    outdir = Path('/mnt/data/whest_continue/sparse_pilot_records'); outdir.mkdir(exist_ok=True)
    pp = pilot_points()
    seeds = list(SPLITS['screen'])
    records = []
    states = {}
    for seed in seeds:
        p = outdir / f'{seed}.json'
        if p.exists():
            r = json.loads(p.read_text())
            # Need state for exact replay; recompute only after selection.
        else:
            print('network', seed, flush=True)
            r, _ = run_network(seed, pp)
            p.write_text(json.dumps(r, indent=2))
            print(' done', seed, r['elapsed_seconds'], flush=True)
        records.append(r)
    disc, val = seeds[:4], seeds[4:]
    ds = summarize(records, disc); vs = summarize(records, val); alls = summarize(records, seeds)
    selected = ds[0]
    key = (selected['selector'], selected['k'], selected['B'], selected['kind'], selected['param'])
    frozen_lin = next(x for x in vs if (x['selector'],x['k'],x['B'],x['kind'],x['param']) == key)
    print('selected linear', json.dumps(selected, indent=2), flush=True)
    print('frozen linear', json.dumps(frozen_lin, indent=2), flush=True)

    # Exact nonlinear replay for frozen configuration on all networks.
    exact_rows = []
    for seed in seeds:
        print('exact replay', seed, flush=True)
        rec = json.loads((ROOT / f'layer31_records/{seed}.json').read_text())
        targetf = np.asarray(rec['target_final'], dtype=np.float64)
        target31 = np.asarray(rec['target31'], dtype=np.float64)
        weights = make_weights(seed)
        H31, A31, H32, basef = capture_baseline(weights)
        base31 = A31.mean(0, dtype=np.float64)
        orders, _ = selectors(H31, A31, H32, weights[31])
        PA = propagate_to31(weights, pp[:selected['B']*512])
        bm = block_means(PA)
        idx = orders[selected['selector']][:selected['k']]
        dhat = bm.mean(0)[idx] - base31[idx]
        se = np.sqrt(bm.var(0, ddof=1)[idx] / selected['B']) if selected['B'] > 1 else np.full(selected['k'], np.inf)
        d = method_delta(dhat, se, selected['kind'], selected['param'])
        pred = exact_replay(A31, H32, weights[31], idx, d)
        bmse = mse(basef, targetf); cmse = mse(pred, targetf)
        td = target31[idx] - base31[idx]
        exact_rows.append({
            'seed': seed, 'baseline_mse': bmse, 'candidate_mse': cmse,
            'candidate_over_baseline': cmse/bmse,
            'raw_gain': bmse/cmse,
            'correction_cosine': float(np.dot(d,td)/max(np.linalg.norm(d)*np.linalg.norm(td),1e-300)),
        })
        del PA, A31, H31, H32; gc.collect()
    def agg(ss):
        rr=[r for r in exact_rows if r['seed'] in ss]
        b=sum(r['baseline_mse'] for r in rr);c=sum(r['candidate_mse'] for r in rr)
        raw=b/c; adj=raw/(1+selected['added_cost_ratio'])
        return {'raw_gain':raw,'adjusted_gain':adj,'wins':sum(r['candidate_mse']<r['baseline_mse'] for r in rr),'worst':max(r['candidate_over_baseline'] for r in rr),'mean_cosine':float(np.mean([r['correction_cosine'] for r in rr]))}
    payload={
        'pilot_rotation_seeds':PILOT_ROT_SEEDS,'pilot_basis_indices':PILOT_BASIS_INDICES,
        'seeds':seeds,'discovery':disc,'validation':val,
        'selected_linear':selected,'frozen_linear':frozen_lin,
        'exact_discovery':agg(disc),'exact_validation':agg(val),'exact_all':agg(seeds),
        'exact_rows':exact_rows,'discovery_top_linear':ds[:30],'validation_top_linear':vs[:30],'all_top_linear':alls[:30],
    }
    Path('/mnt/data/whest_continue/sparse_pilot_summary.json').write_text(json.dumps(payload,indent=2))
    print(json.dumps({'exact_discovery':payload['exact_discovery'],'exact_validation':payload['exact_validation'],'exact_all':payload['exact_all']},indent=2))

if __name__ == '__main__':
    main()
