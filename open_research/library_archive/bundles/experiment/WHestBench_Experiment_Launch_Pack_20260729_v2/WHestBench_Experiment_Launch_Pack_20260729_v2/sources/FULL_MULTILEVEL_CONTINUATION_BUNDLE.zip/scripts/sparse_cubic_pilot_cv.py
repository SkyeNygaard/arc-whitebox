from __future__ import annotations
import gc,json,sys,time
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/whest_mlmc');A1=ROOT/'latest/agent1/agent1_residual_spectrum_final';A9=ROOT/'agent9_10_oracle_bundle/agent9_10_oracle_bundle'
sys.path[:0]=[str(A1),str(A9),'/mnt/data/whest_continue']
from agent1_residual_spectrum_screen import make_weights,mse
from arc_cv.splits_v1 import SPLITS
from sparse_pilot_layer31 import pilot_points,capture_baseline,propagate_to31,selectors
D=256
B_COUNTS=[2,4,8,16,32];KS=[16,32,64,128]
FEATURES=['h3','cubic'];SELECTORS=['skew_sens','gaussian_gap_sens','rank_blend']
RIDGES=[0.001,0.01,0.1,1.0];ALPHAS=[0.25,0.5,0.75,1.0]


def feature_values(A,m,s,idx,kind):
 u=(A[:,idx].astype(np.float64)-m[idx][None,:])/s[idx][None,:]
 return u*u*u-3*u if kind=='h3' else u*u*u

def feature_block_means(Z):
 return Z.reshape(-1,512,Z.shape[1]).mean(1,dtype=np.float64)

def all_orders(H31,A31,H32,W32):
 base,_=selectors(H31,A31,H32,W32);m=A31.mean(0,dtype=float);s=np.maximum(A31.std(0,dtype=float),1e-8)
 skew=np.mean(((A31.astype(np.float64)-m)/s)**3,axis=0);p32=(H32>0).mean(0,dtype=float);sens=np.linalg.norm(W32.astype(float)*p32[None,:],axis=1)
 out=dict(base);out['skew_sens']=np.argsort(-(np.abs(skew)*sens));return out

def stats_by_fold(Z,Y,nfold=6):
 blocks=np.arange(len(Z))//512;fold=blocks%nfold
 out=[]
 for f in range(nfold):
  mask=fold==f;z=Z[mask];y=Y[mask]
  out.append({'n':len(z),'sz':z.sum(0),'sy':y.sum(0),'szz':z.T@z,'szy':z.T@y})
 return out

def correction_for_anchor(fstats,k,anchor,ridge):
 nall=sum(q['n'] for q in fstats);tz=sum((q['sz'][:k] for q in fstats),np.zeros(k));ty=sum((q['sy'] for q in fstats),np.zeros(D));tzz=sum((q['szz'][:k,:k] for q in fstats),np.zeros((k,k)));tzy=sum((q['szy'][:k] for q in fstats),np.zeros((k,D)))
 corr=np.zeros(D)
 for q in fstats:
  nt=q['n'];n=nall-nt;mz=(tz-q['sz'][:k])/n;my=(ty-q['sy'])/n
  Czz=(tzz-q['szz'][:k,:k])-n*np.outer(mz,mz);Czy=(tzy-q['szy'][:k])-n*np.outer(mz,my)
  scale=np.maximum(np.diag(Czz),1e-12);coef=np.linalg.solve(Czz+ridge*np.diag(scale),Czy)
  ztest=q['sz'][:k]/nt
  corr+=nt*((ztest-anchor)@coef)
 return corr/nall

def fit_cost_ratio(k): return (k*(k+D))/(32*D*D)
def added_ratio(B,k): return (B/129)*(31/32)+fit_cost_ratio(k)

def run_network(seed,pp):
 t0=time.time();rec=json.loads((ROOT/f'layer31_records/{seed}.json').read_text());targetf=np.array(rec['target_final'],float)
 w=make_weights(seed);H31,A31,H32,basef=capture_baseline(w);Y=np.maximum(H32,0).astype(np.float64);bm=mse(basef,targetf)
 m=A31.mean(0,dtype=float);s=np.maximum(A31.std(0,dtype=float),1e-8);orders=all_orders(H31,A31,H32,w[31]);PA=propagate_to31(w,pp);rows=[]
 for sel in SELECTORS:
  idxall=orders[sel][:max(KS)]
  for kind in FEATURES:
   Z=feature_values(A31,m,s,idxall,kind);PZ=feature_values(PA,m,s,idxall,kind);pb=feature_block_means(PZ.astype(np.float32));pref=np.cumsum(pb,axis=0)/np.arange(1,len(pb)+1)[:,None];fs=stats_by_fold(Z,Y)
   for k in KS:
    for Bn in B_COUNTS:
     anchor=pref[Bn-1,:k]
     for ridge in RIDGES:
      corr=correction_for_anchor(fs,k,anchor,ridge)
      for alpha in ALPHAS:
       pred=basef-alpha*corr;cm=mse(pred,targetf);cr=added_ratio(Bn,k)
       rows.append({'selector':sel,'k':k,'feature':kind,'B':Bn,'ridge':ridge,'alpha':alpha,'mse':cm,'gain':bm/max(cm,1e-300),'adjusted_gain':(bm/max(cm,1e-300))/(1+cr),'added_cost_ratio':cr})
   del Z,PZ,pb,fs;gc.collect()
 return {'seed':seed,'baseline_mse':bm,'rows':rows,'elapsed':time.time()-t0}
def key(x):return tuple(x[z] for z in ('selector','k','feature','B','ridge','alpha'))
def summarize(records,seeds):
 rr=[r for r in records if r['seed'] in seeds];maps=[{key(x):x for x in r['rows']} for r in rr];keys=list(maps[0]);out=[]
 for q in keys:
  xs=[m[q] for m in maps];b=np.array([r['baseline_mse'] for r in rr]);c=np.array([x['mse'] for x in xs]);g=float(b.sum()/c.sum());cr=xs[0]['added_cost_ratio']
  out.append({'selector':q[0],'k':q[1],'feature':q[2],'B':q[3],'ridge':q[4],'alpha':q[5],'raw_gain':g,'adjusted_gain':g/(1+cr),'wins':int(np.sum(c<b)),'worst':float(np.max(c/b)),'added_cost_ratio':cr})
 return sorted(out,key=lambda x:x['adjusted_gain'],reverse=True)
def main():
 out=Path('/mnt/data/whest_continue/sparse_cubic_records');out.mkdir(exist_ok=True);pp=pilot_points();seeds=list(SPLITS['screen']);records=[]
 for seed in seeds:
  p=out/f'{seed}.json'
  if p.exists():r=json.load(open(p))
  else:print('network',seed,flush=True);r=run_network(seed,pp);p.write_text(json.dumps(r));print(' done',r['elapsed'],flush=True)
  records.append(r)
 disc,val=seeds[:4],seeds[4:];ds=summarize(records,disc);vs=summarize(records,val);alls=summarize(records,seeds);selected=ds[0];q=key(selected);frozen=next(x for x in vs if key(x)==q)
 payload={'seeds':seeds,'discovery':disc,'validation':val,'selected':selected,'frozen':frozen,'discovery_top':ds[:50],'validation_top':vs[:50],'all_top':alls[:50]};Path('/mnt/data/whest_continue/sparse_cubic_summary.json').write_text(json.dumps(payload,indent=2));print(json.dumps({'selected':selected,'frozen':frozen,'all_best':alls[0]},indent=2))
if __name__=='__main__':main()
