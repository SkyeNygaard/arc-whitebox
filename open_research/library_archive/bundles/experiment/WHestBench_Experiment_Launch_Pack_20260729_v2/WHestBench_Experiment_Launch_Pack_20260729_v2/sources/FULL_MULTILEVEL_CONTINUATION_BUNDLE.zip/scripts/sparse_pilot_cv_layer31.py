from __future__ import annotations
import gc, json, math, sys, time
from pathlib import Path
import numpy as np

ROOT=Path('/mnt/data/whest_mlmc')
A1=ROOT/'latest/agent1/agent1_residual_spectrum_final'
A9=ROOT/'agent9_10_oracle_bundle/agent9_10_oracle_bundle'
sys.path[:0]=[str(A1),str(A9),'/mnt/data/whest_continue']
from agent1_residual_spectrum_screen import first_activation_matrix, make_weights, mse
from arc_cv.kerdock import full_real_kerdock_bases, chi_mean
from arc_cv.splits_v1 import SPLITS
from arc_cv.surrogates import HomogeneousClosureRidge
from arc_cv.closure import gaussian_closure, eigen_ramp
from arc_experiments import D, rotation
from sparse_pilot_layer31 import (R0, PILOT_ROT_SEEDS, PILOT_BASIS_INDICES,
    capture_baseline, propagate_to31, pilot_points, block_means, selectors,
    method_delta, exact_replay)

BASE_COMPUTE=175.5e9
B_COUNTS=[1,2,4,8,16,32]
KS=[8,12,16,24]
SELECTORS=['gaussian_gap_sens','block_std_sens','rank_blend']
RANKS=[2,4,8,16,32]
VARIANTS=['base','eig_ramp_0.8_16']
ALPHAS=[0.25,0.5,0.75,1.0]
ZS=[0.5,1.0,1.5,2.0]
LAMBDAS=[0.5,1.0,2.0,4.0]


def build_surrogates(weights64, variant):
    top=1.0 if variant=='base' else eigen_ramp(len(weights64),0.8,16)
    state=gaussian_closure(weights64,top_eig_scale=top,cdf_order=16,psd_project=True)
    return {r:HomogeneousClosureRidge.build_from_state(weights64,state,rank=r,variant=variant) for r in RANKS}


def sparse_replay_ratio(k):
    # k outer products N x k x D versus a dense N x D x D final layer.
    return (k/D)/32.0


def added_cost_ratio(B,k,surr):
    exact_pilot=(B/129.0)*(31.0/32.0)
    setup=surr.setup_flops_estimate/BASE_COMPUTE
    evalr=surr.evaluation_flops(B*512)/BASE_COMPUTE
    return exact_pilot+setup+evalr+sparse_replay_ratio(k)


def config_iter():
    for variant in VARIANTS:
      for rank in RANKS:
       for sel in SELECTORS:
        for k in KS:
         for B in B_COUNTS:
          for a in ALPHAS: yield variant,rank,sel,k,B,'alpha',a
          for z in ZS: yield variant,rank,sel,k,B,'zgate',z
          for l in LAMBDAS: yield variant,rank,sel,k,B,'js',l


def run_network(seed,pp):
    t0=time.time()
    rec=json.loads((ROOT/f'layer31_records/{seed}.json').read_text())
    target31=np.asarray(rec['target31'],float); targetf=np.asarray(rec['target_final'],float)
    weights=make_weights(seed)
    H31,A31,H32,basef=capture_baseline(weights)
    base31=A31.mean(0,dtype=np.float64); bmse=mse(basef,targetf)
    orders,p32=selectors(H31,A31,H32,weights[31])
    PA=propagate_to31(weights,pp)
    exact_bm=block_means(PA)
    weights64=[w.astype(np.float64) for w in weights[:31]]
    rows=[]
    for variant in VARIANTS:
        surrogates=build_surrogates(weights64,variant)
        for rank,surr in surrogates.items():
            G=surr.evaluate(pp).astype(np.float32)
            res_bm=block_means(PA-G)
            eg=surr.analytic_expectation().astype(np.float64)
            pref=np.cumsum(res_bm,axis=0)/np.arange(1,len(res_bm)+1)[:,None]
            for sel in SELECTORS:
              for k in KS:
                idx=orders[sel][:k]
                response=weights[31][idx].astype(np.float64)*p32[None,:]
                true_d=target31[idx]-base31[idx]
                for B in B_COUNTS:
                    est=eg[idx]+pref[B-1,idx]
                    dhat=est-base31[idx]
                    if B>1: se=np.sqrt(res_bm[:B,idx].var(0,ddof=1)/B)
                    else: se=np.full(k,np.inf)
                    for kind,params in [('alpha',ALPHAS),('zgate',ZS),('js',LAMBDAS)]:
                      for param in params:
                        d=method_delta(dhat,se,kind,param)
                        pred=basef+d@response
                        cmse=mse(pred,targetf)
                        denom=max(float(np.linalg.norm(d)*np.linalg.norm(true_d)),1e-300)
                        cr=added_cost_ratio(B,k,surr)
                        rows.append({'variant':variant,'rank':rank,'selector':sel,'k':k,'B':B,
                          'kind':kind,'param':param,'linear_mse':cmse,'linear_gain':bmse/max(cmse,1e-300),
                          'added_cost_ratio':cr,'linear_adjusted_gain':(bmse/max(cmse,1e-300))/(1+cr),
                          'correction_cosine':float(np.dot(d,true_d)/denom),
                          'residual_block_var_selected':float(np.mean(res_bm[:,idx].var(0,ddof=1))),
                          'exact_block_var_selected':float(np.mean(exact_bm[:,idx].var(0,ddof=1))),
                          'variance_ratio':float(np.mean(res_bm[:,idx].var(0,ddof=1))/max(np.mean(exact_bm[:,idx].var(0,ddof=1)),1e-300))})
            del G,res_bm
        del surrogates
        gc.collect()
    return {'seed':seed,'baseline_mse':bmse,'rows':rows,'elapsed_seconds':time.time()-t0}


def summarize(records,seeds):
    rr=[r for r in records if r['seed'] in seeds]
    keys=[tuple(x[k] for k in ('variant','rank','selector','k','B','kind','param')) for x in rr[0]['rows']]
    out=[]
    for key in keys:
      xs=[]
      for r in rr:
        xs.append(next(x for x in r['rows'] if tuple(x[k] for k in ('variant','rank','selector','k','B','kind','param'))==key))
      b=np.array([r['baseline_mse'] for r in rr]); c=np.array([x['linear_mse'] for x in xs])
      gain=float(b.sum()/c.sum()); cr=xs[0]['added_cost_ratio']
      out.append({'variant':key[0],'rank':key[1],'selector':key[2],'k':key[3],'B':key[4],'kind':key[5],'param':key[6],
       'aggregate_linear_gain':gain,'aggregate_adjusted_gain':gain/(1+cr),'wins':int(np.sum(c<b)),
       'worst_candidate_over_baseline':float(np.max(c/b)),'mean_cosine':float(np.mean([x['correction_cosine'] for x in xs])),
       'mean_variance_ratio':float(np.mean([x['variance_ratio'] for x in xs])),'added_cost_ratio':cr})
    return sorted(out,key=lambda x:x['aggregate_adjusted_gain'],reverse=True)


def recompute_exact(seed,pp,cfg):
    rec=json.loads((ROOT/f'layer31_records/{seed}.json').read_text())
    target31=np.asarray(rec['target31'],float);targetf=np.asarray(rec['target_final'],float)
    weights=make_weights(seed);H31,A31,H32,basef=capture_baseline(weights);base31=A31.mean(0,dtype=np.float64)
    orders,_=selectors(H31,A31,H32,weights[31]);idx=orders[cfg['selector']][:cfg['k']]
    PA=propagate_to31(weights,pp[:cfg['B']*512])
    weights64=[w.astype(np.float64) for w in weights[:31]]
    s=build_surrogates(weights64,cfg['variant'])[cfg['rank']]
    G=s.evaluate(pp[:cfg['B']*512]).astype(np.float32)
    rb=block_means(PA-G); est=s.analytic_expectation()[idx]+rb.mean(0)[idx]
    dhat=est-base31[idx]
    se=np.sqrt(rb[:,idx].var(0,ddof=1)/cfg['B']) if cfg['B']>1 else np.full(cfg['k'],np.inf)
    d=method_delta(dhat,se,cfg['kind'],cfg['param'])
    pred=exact_replay(A31,H32,weights[31],idx,d)
    bm=mse(basef,targetf);cm=mse(pred,targetf);td=target31[idx]-base31[idx]
    return {'seed':seed,'baseline_mse':bm,'candidate_mse':cm,'candidate_over_baseline':cm/bm,'raw_gain':bm/cm,
      'correction_cosine':float(np.dot(d,td)/max(np.linalg.norm(d)*np.linalg.norm(td),1e-300))}


def main():
    outdir=Path('/mnt/data/whest_continue/sparse_pilot_cv_records');outdir.mkdir(exist_ok=True)
    pp=pilot_points();seeds=list(SPLITS['screen']);records=[]
    for seed in seeds:
      p=outdir/f'{seed}.json'
      if p.exists(): r=json.loads(p.read_text())
      else:
       print('network',seed,flush=True);r=run_network(seed,pp);p.write_text(json.dumps(r));print(' done',seed,r['elapsed_seconds'],flush=True)
      records.append(r)
    disc,val=seeds[:4],seeds[4:]
    ds=summarize(records,disc);vs=summarize(records,val);alls=summarize(records,seeds)
    # Exclude exact no-ops caused by B=1 z/js.
    dnon=[x for x in ds if not (x['B']==1 and x['kind'] in ('zgate','js'))]
    selected=dnon[0]
    key=tuple(selected[k] for k in ('variant','rank','selector','k','B','kind','param'))
    frozen=next(x for x in vs if tuple(x[k] for k in ('variant','rank','selector','k','B','kind','param'))==key)
    print('SELECTED',json.dumps(selected,indent=2));print('FROZEN',json.dumps(frozen,indent=2))
    exact=[]
    for seed in seeds:
      print('exact',seed,flush=True);exact.append(recompute_exact(seed,pp,selected))
    def agg(ss):
      x=[r for r in exact if r['seed'] in ss];b=sum(r['baseline_mse'] for r in x);c=sum(r['candidate_mse'] for r in x);raw=b/c
      return {'raw_gain':raw,'adjusted_gain':raw/(1+selected['added_cost_ratio']),'wins':sum(r['candidate_mse']<r['baseline_mse'] for r in x),
       'worst':max(r['candidate_over_baseline'] for r in x),'mean_cosine':float(np.mean([r['correction_cosine'] for r in x]))}
    payload={'seeds':seeds,'discovery':disc,'validation':val,'selected':selected,'frozen_linear':frozen,
      'exact_discovery':agg(disc),'exact_validation':agg(val),'exact_all':agg(seeds),'exact_rows':exact,
      'discovery_top':ds[:40],'validation_top':vs[:40],'all_top':alls[:40]}
    Path('/mnt/data/whest_continue/sparse_pilot_cv_summary.json').write_text(json.dumps(payload,indent=2))
    print(json.dumps({k:payload[k] for k in ('exact_discovery','exact_validation','exact_all')},indent=2))
if __name__=='__main__':main()
