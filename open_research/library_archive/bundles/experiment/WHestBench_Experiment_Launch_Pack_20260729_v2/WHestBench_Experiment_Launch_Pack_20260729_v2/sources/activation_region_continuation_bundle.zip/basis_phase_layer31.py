#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math, os, sys, time, csv
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
import numpy as np
from scipy.linalg import hadamard
from scipy.stats import skew, kurtosis
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.cross_decomposition import PLSRegression

ROOT=Path('/mnt/data/whest_research')
A1=ROOT/'agent1/agent1_residual_spectrum_final'
A9=ROOT/'agent9/agent9_continuation_bundle'
sys.path.insert(0,str(A1)); sys.path.insert(0,str(A9))
os.environ.setdefault('AGENT9_BUNDLE',str(A9)); os.environ.setdefault('ARC_KERDOCK_ASSET',str(A9/'kerdock_mub5_seed3.npz'))
from agent1_residual_spectrum_screen import first_activation_matrix, make_weights, mse
from arc_cv.splits_v1 import SPLITS
from conditional_region_layer31 import selected_translation_deltas

D=256; N=66048; SPLIT=128*D
H128=hadamard(128,dtype=np.int8).astype(np.float64)/128.0

REF_DIRS={
 'screen':ROOT/'conditional_region_cv_screen/reference_cache',
 'validation':ROOT/'conditional_region_cv_validation/reference_cache',
 'holdout':ROOT/'conditional_region_cv_holdout/reference_cache',
}

def capture(seed:int):
    w=make_weights(seed); R0=np.load(A1/'config/kerdock_rotation_seed3.npy').astype(np.float32)
    A=first_activation_matrix(w[0],R0); B=np.empty_like(A)
    for W in w[1:30]:
        np.matmul(A,W,out=B); np.maximum(B,0,out=B); A,B=B,A
    H31=np.empty_like(A); np.matmul(A,w[30],out=H31)
    A31=np.maximum(H31,0).astype(np.float32,copy=False)
    H32=np.empty_like(A31); np.matmul(A31,w[31],out=H32)
    bf=np.maximum(H32,0).mean(0,dtype=np.float64)
    return w,H31,A31,H32,bf

def basis_means(A31:np.ndarray)->np.ndarray:
    # 128 chirp bases: all positive blocks then all negative blocks; coordinate basis last.
    pos=A31[:SPLIT].reshape(128,D,D)
    neg=A31[SPLIT:2*SPLIT].reshape(128,D,D)
    b=np.empty((129,D),dtype=np.float64)
    b[:128]=(pos.sum(axis=1,dtype=np.float64)+neg.sum(axis=1,dtype=np.float64))/(2*D)
    b[128]=(A31[2*SPLIT:2*SPLIT+D].sum(axis=0,dtype=np.float64)+A31[2*SPLIT+D:].sum(axis=0,dtype=np.float64))/(2*D)
    return b

def features(H31,A31,H32,W32):
    emp=A31.mean(0,dtype=np.float64); B=basis_means(A31); C=B-emp[None,:]
    chirp=C[:128]
    # Walsh coefficients across Kerdock basis labels. DC is omitted.
    wal=(H128@chirp)[1:].T  # 256 x 127
    sd=np.std(chirp,axis=0,ddof=0); eps=1e-12
    qs=np.quantile(chirp,[.05,.1,.25,.5,.75,.9,.95],axis=0).T
    stats=np.column_stack([
        emp,
        H31.mean(0,dtype=np.float64),H31.std(0,dtype=np.float64),(H31>0).mean(0,dtype=np.float64),
        C[128],sd,np.mean(np.abs(chirp),axis=0),
        skew(chirp,axis=0,bias=True),kurtosis(chirp,axis=0,fisher=True,bias=True),
        np.min(chirp,axis=0),np.max(chirp,axis=0),
        qs,
    ])
    p32=(H32>0).mean(0,dtype=np.float64)
    J=W32.astype(np.float64)*p32[None,:]
    sens=np.linalg.norm(J,axis=1)
    incoming=np.linalg.norm(W32.astype(np.float64),axis=1)
    local=np.column_stack([stats,sens,incoming])
    X=np.column_stack([local,wal,wal/(sd[:,None]+eps)])
    names=(['emp','hmean','hstd','pon','coord_dev','block_sd','block_mad','block_skew','block_kurt','block_min','block_max',
            'q05','q10','q25','q50','q75','q90','q95','sensitivity','out_weight_norm']+
           [f'wal_{i}' for i in range(1,128)]+[f'wal_norm_{i}' for i in range(1,128)])
    return X.astype(np.float64),names,emp,B,J,sens

def extract_one(seed:int,split:str,out_dir:str):
    out=Path(out_dir); p=out/f'seed_{seed}.npz'
    if p.exists(): return {'seed':seed,'cached':True}
    t=time.perf_counter(); w,H31,A31,H32,bf=capture(seed)
    rp=REF_DIRS[split]/f'seed_{seed}_refs.npz'
    if not rp.exists(): raise FileNotFoundError(rp)
    with np.load(rp) as z: ta31=z['ta31']; taf=z['taf']; tb31=z['tb31']; tbf=z['tbf']
    truth31=.5*(ta31+tb31); truthf=.5*(taf+tbf)
    X,names,emp,B,J,sens=features(H31,A31,H32,w[31])
    np.savez_compressed(p,X=X,y=truth31-emp,hstd=H31.std(0,dtype=np.float64),emp=emp,J=J,sens=sens,
                        bf=bf,taf=taf,tbf=tbf,truthf=truthf,basis_means=B,feature_names=np.array(names,dtype='U40'))
    return {'seed':seed,'seconds':time.perf_counter()-t}

def load_split(split,out_dir):
    rows=[]
    for seed in SPLITS[split]:
        p=Path(out_dir)/split/f'seed_{seed}.npz'
        with np.load(p) as z:
            rows.append({k:z[k].copy() for k in z.files}|{'seed':seed})
    return rows

def variants(nfeat):
    # local first 20; raw Walsh next 127; normalized Walsh final 127
    return {'local':np.arange(20),'raw_walsh':np.arange(20,147),'local_raw':np.arange(147),
            'local_norm':np.r_[np.arange(20),np.arange(147,nfeat)],'full':np.arange(nfeat)}

def fit_predict(train, test, variant, model_kind, param, target_mode):
    idx=variants(train[0]['X'].shape[1])[variant]
    Xt=np.nan_to_num(np.concatenate([r['X'][:,idx] for r in train]),nan=0.0,posinf=0.0,neginf=0.0); yt=np.concatenate([r['y'] for r in train])
    if target_mode=='hstd': yt=yt/np.concatenate([r['hstd'] for r in train])
    if model_kind=='ridge': model=make_pipeline(StandardScaler(),Ridge(alpha=float(param)))
    elif model_kind=='pls': model=make_pipeline(StandardScaler(),PLSRegression(n_components=int(param),scale=False,max_iter=1000))
    else: raise ValueError(model_kind)
    model.fit(Xt,yt)
    preds=[]
    for r in test:
        q=np.asarray(model.predict(np.nan_to_num(r['X'][:,idx],nan=0.0,posinf=0.0,neginf=0.0))).reshape(-1)
        if target_mode=='hstd': q=q*r['hstd']
        preds.append(q)
    return preds,model

def lin_score(rows,preds,k,alpha):
    b=[];c=[];corr=[];wc=[]
    for r,p in zip(rows,preds):
        score=np.abs(p)*r['sens']; idx=np.argsort(-score)[:k]
        dy=(alpha*p[idx])@r['J'][idx]
        e=r['bf']-r['truthf']; ep=e+dy
        b.append(np.mean(e*e)); c.append(np.mean(ep*ep))
        y=r['y']; corr.append(np.corrcoef(p,y)[0,1] if np.std(p)>1e-15 else 0)
        wc.append(np.dot(p*r['sens'],y*r['sens'])/max(np.linalg.norm(p*r['sens'])*np.linalg.norm(y*r['sens']),1e-300))
    return {'ratio':float(np.sum(b)/np.sum(c)),'wins':int(np.sum(np.array(c)<np.array(b))),'worst':float(np.max(np.array(c)/np.array(b))),
            'corr':float(np.mean(corr)),'weighted_cosine':float(np.mean(wc))}

def screen_models(data,out_path):
    configs=[]
    for variant in variants(data[0]['X'].shape[1]):
      for target_mode in ['raw','hstd']:
       for a in [0.01,0.1,1,10,100,1000]: configs.append((variant,'ridge',a,target_mode))
       for n in [2,4,8,16]: configs.append((variant,'pls',n,target_mode))
    ks=[4,8,12,16,24,32,64,128,256]; alphas=[.1,.25,.5,.75,1.0]
    results=[]
    for ci,cfg in enumerate(configs):
        loo=[]
        for i in range(len(data)):
            ps,_=fit_predict(data[:i]+data[i+1:],[data[i]],*cfg); loo.append(ps[0])
        best=None
        for k in ks:
          for alpha in alphas:
            s=lin_score(data,loo,k,alpha)
            row={'variant':cfg[0],'model':cfg[1],'param':cfg[2],'target_mode':cfg[3],'k':k,'alpha':alpha,**s}
            if best is None or row['ratio']>best['ratio']: best=row
        results.append(best)
        print(json.dumps({'stage':'config','i':ci,'n':len(configs),'best':best}),flush=True)
    results.sort(key=lambda x:x['ratio'],reverse=True)
    Path(out_path).write_text(json.dumps({'results':results,'best':results[0]},indent=2)+'\n')
    return results

def build_predictions(screen,other,best,out_dir):
    cfg=(best['variant'],best['model'],best['param'],best['target_mode'])
    # Cross-validated screen predictions
    sp=[]
    for i in range(len(screen)):
        ps,_=fit_predict(screen[:i]+screen[i+1:],[screen[i]],*cfg);sp.append(ps[0])
    vp,model=fit_predict(screen,other,*cfg)
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    for split,rows,preds in [('screen',screen,sp),('validation',other,vp)]:
      for r,p in zip(rows,preds): np.save(out/f'{split}_seed_{r["seed"]}.npy',p)
    return sp,vp

def exact_one(seed,split,pred_path,k,alpha,out_dir):
    p=Path(out_dir)/f'seed_{seed}.json'
    if p.exists(): return json.loads(p.read_text())
    t=time.perf_counter();w,H31,A31,H32,bf=capture(seed); pred=np.load(pred_path)
    with np.load(REF_DIRS[split]/f'seed_{seed}_refs.npz') as z: taf=z['taf'];tbf=z['tbf']
    p32=(H32>0).mean(0,dtype=np.float64);sens=np.linalg.norm(w[31].astype(np.float64)*p32[None,:],axis=1)
    idx=np.argsort(-(np.abs(pred)*sens))[:k]; targets=A31.mean(0,dtype=np.float64)[idx]+alpha*pred[idx]
    Dsel=selected_translation_deltas(A31,idx,targets)
    cand=np.maximum(H32+Dsel@w[31][idx],0).mean(0,dtype=np.float64)
    base=.5*(mse(bf,taf)+mse(bf,tbf)); cm=.5*(mse(cand,taf)+mse(cand,tbf))
    r={'seed':seed,'split':split,'baseline_cross_mse':base,'candidate_cross_mse':cm,'candidate_over_baseline':cm/base,'raw_mse_ratio':base/cm,
       'pred_rms':float(np.sqrt(np.mean(pred*pred))),'selected_pred_rms':float(np.sqrt(np.mean(pred[idx]*pred[idx]))),'elapsed_seconds':time.perf_counter()-t}
    p.write_text(json.dumps(r,indent=2)+'\n');return r

def summarize_exact(rs,out):
    b=np.array([r['baseline_cross_mse'] for r in rs]);c=np.array([r['candidate_cross_mse'] for r in rs]);ratio=float(b.sum()/c.sum())
    rng=np.random.default_rng(48191);idx=rng.integers(0,len(rs),(30000,len(rs)));vals=b[idx].sum(1)/c[idx].sum(1)
    s={'n':len(rs),'ratio':ratio,'ci95':[float(x) for x in np.quantile(vals,[.025,.975])],'wins':int(np.sum(c<b)),'worst_candidate_over_baseline':float(np.max(c/b)),
       'per_network':[{'seed':r['seed'],'candidate_over_baseline':r['candidate_over_baseline']} for r in rs]}
    Path(out).write_text(json.dumps(s,indent=2)+'\n');return s

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['extract','screen','exact']);ap.add_argument('--split',choices=['screen','validation'],default='screen')
    ap.add_argument('--workers',type=int,default=4);ap.add_argument('--data-dir',default=str(ROOT/'basis_phase_data'));ap.add_argument('--model-json',default=str(ROOT/'basis_phase_model_screen.json'))
    ap.add_argument('--pred-dir',default=str(ROOT/'basis_phase_predictions'));ap.add_argument('--exact-dir',default=None);args=ap.parse_args()
    if args.mode=='extract':
      out=Path(args.data_dir)/args.split;out.mkdir(parents=True,exist_ok=True)
      with ProcessPoolExecutor(max_workers=args.workers) as ex:
       fs=[ex.submit(extract_one,s,args.split,str(out)) for s in SPLITS[args.split]]
       for f in as_completed(fs): print(json.dumps({'stage':'extract',**f.result()}),flush=True)
    elif args.mode=='screen':
      scr=load_split('screen',args.data_dir);val=load_split('validation',args.data_dir)
      res=screen_models(scr,args.model_json);best=res[0];sp,vp=build_predictions(scr,val,best,args.pred_dir)
      print(json.dumps({'stage':'selected','best':best,'screen_linear':lin_score(scr,sp,best['k'],best['alpha']),'validation_linear':lin_score(val,vp,best['k'],best['alpha'])}),flush=True)
    else:
      spec=json.load(open(args.model_json))['best']; k=spec['k'];alpha=spec['alpha'];split=args.split
      out=Path(args.exact_dir or ROOT/f'basis_phase_exact_{split}');out.mkdir(parents=True,exist_ok=True)
      with ProcessPoolExecutor(max_workers=args.workers) as ex:
       fs=[ex.submit(exact_one,s,split,str(Path(args.pred_dir)/f'{split}_seed_{s}.npy'),k,alpha,str(out)) for s in SPLITS[split]]
       rs=[]
       for f in as_completed(fs): r=f.result();rs.append(r);print(json.dumps({'stage':'exact','seed':r['seed'],'ratio':r['raw_mse_ratio']}),flush=True)
      rs.sort(key=lambda r:SPLITS[split].index(r['seed']));s=summarize_exact(rs,out/'summary.json');print(json.dumps({'stage':'summary',**s}),flush=True)
if __name__=='__main__': main()
