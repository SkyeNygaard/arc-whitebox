import json,sys,numpy as np
sys.path.insert(0,'/mnt/data/whest_research')
import basis_phase_layer31 as b
D='/mnt/data/whest_research/basis_phase_data'
scr=b.load_split('screen',D); val=b.load_split('validation',D)
cfg=('raw_walsh','ridge',1.0,'raw'); shrink=.1
sp=[]
for i in range(len(scr)):
 p,_=b.fit_predict(scr[:i]+scr[i+1:],[scr[i]],*cfg);sp.append(p[0])
vp,model=b.fit_predict(scr,val,*cfg)
def eval(rows,preds,name):
 bs=[];cs=[]; per=[]
 for r,p in zip(rows,preds):
  cand=r['bf']+shrink*(p@r['J'])
  base=.5*(np.mean((r['bf']-r['taf'])**2)+np.mean((r['bf']-r['tbf'])**2))
  cm=.5*(np.mean((cand-r['taf'])**2)+np.mean((cand-r['tbf'])**2))
  bs.append(base);cs.append(cm);per.append({'seed':r['seed'],'ratio':base/cm,'candidate_over_baseline':cm/base})
 bs=np.array(bs);cs=np.array(cs);rng=np.random.default_rng(77551);idx=rng.integers(0,len(bs),(50000,len(bs)));rat=bs[idx].sum(1)/cs[idx].sum(1)
 out={'split':name,'n':len(bs),'ratio':float(bs.sum()/cs.sum()),'ci95':[float(x) for x in np.quantile(rat,[.025,.975])],
      'wins':int(np.sum(cs<bs)),'worst_candidate_over_baseline':float(np.max(cs/bs)),'per_network':per}
 return out
out={'spec':{'variant':'raw_walsh','ridge_alpha':1.0,'target':'raw','output_shrinkage':.1,'all_coordinates':True},'screen':eval(scr,sp,'screen'),'validation':eval(val,vp,'validation')}
json.dump(out,open('/mnt/data/whest_research/frozen_phase_candidate_screen_validation.json','w'),indent=2)
print(json.dumps(out,indent=2))
# persist final model parameters via joblib
import joblib
joblib.dump(model,'/mnt/data/whest_research/frozen_phase_model_screen.joblib')
