import sys,glob,json,numpy as np
from pathlib import Path
sys.path.insert(0,'/mnt/data/whest_research')
import basis_phase_layer31 as b
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.cross_decomposition import PLSRegression
from sklearn.ensemble import ExtraTreesRegressor,HistGradientBoostingRegressor

CORP=Path('/mnt/data/whest_research/phase_large_corpus')

def loadfiles(path,limit=None):
 ps=sorted(glob.glob(str(path/'seed_*.npz')))
 if limit:ps=ps[:limit]
 out=[]
 for p in ps:
  with np.load(p) as z:out.append({k:z[k].copy() for k in z.files}|{'file':p})
 return out
train=loadfiles(CORP/'train',64);dev=loadfiles(CORP/'dev',18)
val=b.load_split('validation','/mnt/data/whest_research/basis_phase_data')

def augment(r,variant):
 X=np.nan_to_num(r['X'],nan=0.0,posinf=0.0,neginf=0.0)
 if variant=='local':return X[:,:20]
 if variant=='raw_walsh':return X[:,20:147]
 if variant=='local_raw':return X[:,:147]
 if variant=='full':return X
 B=r['basis_means'][:128];C=B-B.mean(0);sd=np.std(C,axis=0)+1e-12;sn=np.sort(C/sd[None,:],axis=0).T
 if variant=='sorted_norm':return sn
 if variant=='local_sorted':return np.column_stack([X[:,:20],sn])
 raise ValueError(variant)

def fit_model(variant,kind,param,target_mode='raw'):
 X=np.concatenate([augment(r,variant) for r in train]);y=np.concatenate([r['y'] for r in train])
 if target_mode=='hstd':y=y/np.concatenate([r['hstd'] for r in train])
 if kind=='ridge':m=make_pipeline(StandardScaler(),Ridge(alpha=param))
 elif kind=='pls':m=make_pipeline(StandardScaler(),PLSRegression(n_components=int(param),scale=False,max_iter=1000))
 elif kind=='extra':m=ExtraTreesRegressor(n_estimators=int(param),min_samples_leaf=20,max_features=.7,n_jobs=-1,random_state=1)
 elif kind=='hist':m=HistGradientBoostingRegressor(max_iter=int(param),learning_rate=.05,max_leaf_nodes=15,l2_regularization=1e-5,random_state=1)
 m.fit(X,y);return m

def preds(m,rows,variant,target_mode):
 out=[]
 for r in rows:
  p=np.asarray(m.predict(augment(r,variant))).reshape(-1)
  if target_mode=='hstd':p*=r['hstd']
  out.append(p)
 return out

def coord(rows,ps):
 y=np.concatenate([r['y'] for r in rows]);p=np.concatenate(ps);return {'corr':float(np.corrcoef(p,y)[0,1]),'mse_ratio':float(np.mean(y*y)/np.mean((p-y)**2)),'pred_rms':float(np.sqrt(np.mean(p*p))),'target_rms':float(np.sqrt(np.mean(y*y)))}
def final(rows,ps,sh):
 bs=[];cs=[]
 for r,p in zip(rows,ps):
  cand=r['bf']+sh*(p@r['J']);base=.5*(np.mean((r['bf']-r['taf'])**2)+np.mean((r['bf']-r['tbf'])**2));cm=.5*(np.mean((cand-r['taf'])**2)+np.mean((cand-r['tbf'])**2));bs.append(base);cs.append(cm)
 return {'ratio':float(sum(bs)/sum(cs)),'wins':int(sum(c<b for b,c in zip(bs,cs))),'worst':float(max(c/b for b,c in zip(bs,cs)))}
configs=[]
for v in ['local','raw_walsh','local_raw','full','sorted_norm','local_sorted']:
 for tm in ['raw','hstd']:
  for a in [1,10,100,1000,10000]:configs.append((v,'ridge',a,tm))
  if v in ['local','raw_walsh','local_raw','sorted_norm']:
   for n in [2,4,8,16]:configs.append((v,'pls',n,tm))
# small nonlinear invariant candidates
for v in ['local','sorted_norm','local_sorted']:
 configs += [(v,'extra',200,'raw'),(v,'hist',200,'raw')]
rows=[]
for i,cfg in enumerate(configs):
 try:
  m=fit_model(*cfg);dp=preds(m,dev,cfg[0],cfg[3]);vp=preds(m,val,cfg[0],cfg[3]);dc=coord(dev,dp)
  fs=[(s,final(val,vp,s)) for s in [.02,.05,.1,.2,.3,.5,1.0]];best=max(fs,key=lambda x:x[1]['ratio'])
  row={'variant':cfg[0],'kind':cfg[1],'param':cfg[2],'target_mode':cfg[3],**{f'dev_{k}':v for k,v in dc.items()},'best_shrink':best[0],**{f'val_{k}':v for k,v in best[1].items()}}
  rows.append(row);print(i,row,flush=True)
 except Exception as e:print('ERR',cfg,repr(e),flush=True)
rows.sort(key=lambda r:r['dev_corr'],reverse=True)
json.dump({'rows':rows,'top_dev':rows[:20],'top_val':sorted(rows,key=lambda r:r['val_ratio'],reverse=True)[:20]},open('/mnt/data/whest_research/large_phase_models.json','w'),indent=2)
print('TOP DEV');[print(r) for r in rows[:15]]
print('TOP VAL');[print(r) for r in sorted(rows,key=lambda r:r['val_ratio'],reverse=True)[:15]]
