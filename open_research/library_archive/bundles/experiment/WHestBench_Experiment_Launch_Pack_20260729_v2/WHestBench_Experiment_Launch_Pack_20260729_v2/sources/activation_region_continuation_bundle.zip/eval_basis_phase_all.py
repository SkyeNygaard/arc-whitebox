import json,sys
from pathlib import Path
sys.path.insert(0,'/mnt/data/whest_research')
import basis_phase_layer31 as b
D='/mnt/data/whest_research/basis_phase_data'
scr=b.load_split('screen',D); val=b.load_split('validation',D)
res=json.load(open('/mnt/data/whest_research/basis_phase_model_screen.json'))['results']
out=[]
for i,r in enumerate(res):
 cfg=(r['variant'],r['model'],r['param'],r['target_mode'])
 vp,_=b.fit_predict(scr,val,*cfg)
 v=b.lin_score(val,vp,r['k'],r['alpha'])
 out.append({**r,**{f'val_{k}':x for k,x in v.items()}})
 print(i,r['variant'],r['model'],r['param'],r['target_mode'],'screen',r['ratio'],'val',v['ratio'],v['wins'],v['worst'])
json.dump({'rows':out},open('/mnt/data/whest_research/basis_phase_all_validation.json','w'),indent=2)
print('\nTOP VALIDATION')
for r in sorted(out,key=lambda x:x['val_ratio'],reverse=True)[:20]: print(r)
