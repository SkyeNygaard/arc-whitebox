#!/usr/bin/env python3
import glob, numpy as np, json
from pathlib import Path
ROOT=Path('/mnt/data/whest_research/basis_phase_data')

def load(split):
 out=[]
 for p in sorted(glob.glob(str(ROOT/split/'seed_*.npz'))):
  with np.load(p) as z: out.append({k:z[k].copy() for k in z.files}|{'file':p})
 return out

def qs(r):
 C=r['basis_means'][:128]-r['emp'][None,:]
 sd=np.sqrt(np.mean(C*C,axis=0))+1e-12
 Z=C/sd[None,:]
 rn=np.mean(Z*Z,axis=1)
 # phase-label invariant equivariant vectors in layer-31 neuron space
 out={}
 out['coord_skew']=np.mean(Z**3,axis=0)*sd
 out['coord_fifth']=np.mean(Z**5,axis=0)*sd
 out['global_cubic']=np.mean(Z*rn[:,None],axis=0)*sd
 out['global_quintic']=np.mean(Z*(rn[:,None]**2),axis=0)*sd
 # output-sensitive row norms based on linearized suffix
 D=C@r['J']; dn=np.mean(D*D,axis=1)/(np.mean(D*D)+1e-30)
 out['output_cubic']=np.mean(Z*dn[:,None],axis=0)*sd
 out['output_quintic']=np.mean(Z*(dn[:,None]**2),axis=0)*sd
 # PCA-score skew reconstruction, ranks 1/2/4/8/16
 U,S,Vt=np.linalg.svd(Z,full_matrices=False)
 for k in [1,2,4,8,16]:
  V=Vt[:k]; scores=Z@V.T
  coeff=np.mean(scores**3,axis=0)/(np.mean(scores**2,axis=0)+1e-30)
  out[f'pca_skew_{k}']=(coeff@V)*sd
 # vector in final output space directly from linearized basis deviations
 Dout=Z@r['J']
 norm=np.mean(Dout*Dout,axis=1)/(np.mean(Dout*Dout)+1e-30)
 out['direct_output_cubic_layer31']=np.mean(Z*norm[:,None],axis=0)*sd
 return out

def base_error(r): return r['bf']-.5*(r['taf']+r['tbf'])

def score(rows,name,alpha):
 bs=[];cs=[];per=[]
 for r in rows:
  q=qs(r)[name]; dy=alpha*(q@r['J']); e=base_error(r)
  b=np.mean(e*e);c=np.mean((e+dy)**2);bs.append(b);cs.append(c);per.append(c/b)
 return {'ratio':float(sum(bs)/sum(cs)),'wins':int(sum(c<b for b,c in zip(bs,cs))),'worst':float(max(per))}

def fit_alpha(rows,name):
 # minimize sum ||e + a d||^2
 num=den=0.
 for r in rows:
  q=qs(r)[name];d=q@r['J'];e=base_error(r);num+=np.dot(e,d);den+=np.dot(d,d)
 return -num/max(den,1e-300)

scr=load('screen');val=load('validation');names=list(qs(scr[0]))
res=[]
for name in names:
 a=fit_alpha(scr,name)
 s=score(scr,name,a);v=score(val,name,a)
 res.append({'name':name,'alpha':a,'screen':s,'validation':v})
 print(res[-1],flush=True)
Path('/mnt/data/whest_research/vector_phase_invariants.json').write_text(json.dumps({'rows':res},indent=2)+'\n')
