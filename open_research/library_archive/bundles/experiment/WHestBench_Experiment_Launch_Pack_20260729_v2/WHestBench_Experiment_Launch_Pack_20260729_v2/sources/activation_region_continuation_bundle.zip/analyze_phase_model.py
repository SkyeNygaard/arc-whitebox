import sys,json,numpy as np
sys.path.insert(0,'/mnt/data/whest_research')
import basis_phase_layer31 as b
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
D='/mnt/data/whest_research/basis_phase_data'; scr=b.load_split('screen',D); val=b.load_split('validation',D)
idx=b.variants(scr[0]['X'].shape[1])['raw_walsh']
def fit(rows,fit_intercept=True):
 X=np.nan_to_num(np.concatenate([r['X'][:,idx] for r in rows]));y=np.concatenate([r['y'] for r in rows])
 m=make_pipeline(StandardScaler(),Ridge(alpha=1.0,fit_intercept=fit_intercept));m.fit(X,y);return m
ms=fit(scr);mv=fit(val);ma=fit(scr+val)
cs=ms[-1].coef_;cv=mv[-1].coef_;ca=ma[-1].coef_
print('intercepts',ms[-1].intercept_,mv[-1].intercept_,ma[-1].intercept_)
print('coef norms',np.linalg.norm(cs),np.linalg.norm(cv),np.linalg.norm(ca))
print('coef cosine screen-val',np.dot(cs,cv)/(np.linalg.norm(cs)*np.linalg.norm(cv)))
print('top screen',sorted(enumerate(cs,1),key=lambda x:-abs(x[1]))[:15])
print('top val',sorted(enumerate(cv,1),key=lambda x:-abs(x[1]))[:15])

def predict_model(model,rows): return [model.predict(np.nan_to_num(r['X'][:,idx])).reshape(-1) for r in rows]
def cross(rows,preds,sh=.1):
 bs=[];cs=[]
 for r,p in zip(rows,preds):
  cand=r['bf']+sh*(p@r['J']);base=.5*(np.mean((r['bf']-r['taf'])**2)+np.mean((r['bf']-r['tbf'])**2));cm=.5*(np.mean((cand-r['taf'])**2)+np.mean((cand-r['tbf'])**2));bs.append(base);cs.append(cm)
 return sum(bs)/sum(cs),sum(c<b for b,c in zip(bs,cs)),max(c/b for b,c in zip(bs,cs))
# screen-trained full, intercept-only, coefficient-only, and mean delta baselines on validation
pfull=predict_model(ms,val)
mean_delta=np.mean(np.concatenate([r['y'] for r in scr]))
pint=[np.full(256,mean_delta) for _ in val]
# use model predictions minus intercept (feature-only)
pcoef=[p-ms[-1].intercept_ for p in pfull]
print('validation full',cross(val,pfull))
print('validation intercept-only',mean_delta,cross(val,pint))
print('validation coef-only',cross(val,pcoef))
# no-intercept model
mni=fit(scr,False);pni=predict_model(mni,val);print('validation fit_intercept_false',cross(val,pni),'norm',np.linalg.norm(mni[-1].coef_))
# permute coefficient features per row destroys label phase but keeps marginal distribution
rng=np.random.default_rng(123); pp=[]
for r in val:
 X=np.nan_to_num(r['X'][:,idx]).copy()
 for j in range(len(X)): X[j]=X[j,rng.permutation(X.shape[1])]
 pp.append(ms.predict(X).reshape(-1))
print('validation permuted walsh labels',cross(val,pp))
