#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,os,sys,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/whest_research');A1=ROOT/'agent1/agent1_residual_spectrum_final';A9=ROOT/'agent9/agent9_continuation_bundle'
sys.path.insert(0,str(A1));sys.path.insert(0,str(A9));os.environ.setdefault('ARC_KERDOCK_ASSET',str(A9/'kerdock_mub5_seed3.npz'))
from agent1_residual_spectrum_screen import first_activation_matrix,make_weights,mse
from arc_cv.splits_v1 import SPLITS
D=256;SPLIT=128*D
REF={'screen':ROOT/'conditional_region_cv_screen/reference_cache','validation':ROOT/'conditional_region_cv_validation/reference_cache'}
CS=[1,2,4,8,16,32]
PATTERNS=['first','even','random_same','random_basis','diagonal']

def capture(seed):
 w=make_weights(seed);R0=np.load(A1/'config/kerdock_rotation_seed3.npy').astype(np.float32);A=first_activation_matrix(w[0],R0);B=np.empty_like(A)
 for W in w[1:30]:np.matmul(A,W,out=B);np.maximum(B,0,out=B);A,B=B,A
 H31=np.empty_like(A);np.matmul(A,w[30],out=H31);A31=np.maximum(H31,0).astype(np.float32,copy=False)
 H32=np.empty_like(A31);np.matmul(A31,w[31],out=H32);bf=np.maximum(H32,0).mean(0,dtype=np.float64)
 return w,A31,H32,bf

def indices(pattern,c,basis):
 if pattern=='first':return np.arange(c)
 if pattern=='even':return (np.arange(c)*D//c).astype(int)
 if pattern=='random_same':return np.sort(np.random.default_rng(4400+c).choice(D,c,replace=False))
 if pattern=='random_basis':return np.sort(np.random.default_rng(550000+1009*basis+c).choice(D,c,replace=False))
 if pattern=='diagonal':return ((basis+np.arange(c)*D//c)%D).astype(int)
 raise ValueError(pattern)

def subset_mean(A,pattern,c):
 total=np.zeros(D,dtype=np.float64);n=0
 for b in range(128):
  idx=indices(pattern,c,b);total+=A[b*D+idx].sum(0,dtype=np.float64);total+=A[SPLIT+b*D+idx].sum(0,dtype=np.float64);n+=2*c
 idx=indices(pattern,c,128);total+=A[2*SPLIT+idx].sum(0,dtype=np.float64);total+=A[2*SPLIT+D+idx].sum(0,dtype=np.float64);n+=2*c
 return total/n

def run_one(seed,split,out_dir):
 p=Path(out_dir)/f'seed_{seed}.json'
 if p.exists():return json.loads(p.read_text())
 t=time.perf_counter();w,A,H,bf=capture(seed);emp=A.mean(0,dtype=np.float64)
 with np.load(REF[split]/f'seed_{seed}_refs.npz') as z:taf=z['taf'];tbf=z['tbf'];truth=.5*(z['ta31']+z['tb31'])
 base=.5*(mse(bf,taf)+mse(bf,tbf));p32=(H>0).mean(0,dtype=np.float64);J=w[31].astype(np.float64)*p32[None,:];sens=np.linalg.norm(J,axis=1);true=truth-emp
 rows=[];di=[]
 for pat in PATTERNS:
  for c in CS:
   d=subset_mean(A,pat,c)-emp;name=f'{pat}_c{c}';di.append({'config':name,'points':2*129*c,'delta_rms':float(np.sqrt(np.mean(d*d))),'corr':float(np.corrcoef(d,true)[0,1]),'weighted_cosine':float(np.dot(d*sens,true*sens)/max(np.linalg.norm(d*sens)*np.linalg.norm(true*sens),1e-300))})
   order=np.argsort(-(np.abs(d)*sens))
   for k in [8,16,32,64,128,256]:
    ix=order[:k];dy=d[ix]@J[ix]
    for a in [.001,.002,.005,.01,.02,.05,.1,.2]:
     cand=bf+a*dy;cm=.5*(mse(cand,taf)+mse(cand,tbf));rows.append({'config':name,'points':2*129*c,'k':k,'alpha':a,'candidate_cross_mse':cm,'raw_mse_ratio':base/cm,'candidate_over_baseline':cm/base})
 r={'seed':seed,'split':split,'baseline_cross_mse':base,'rows':rows,'diagnostics':di,'elapsed_seconds':time.perf_counter()-t};p.write_text(json.dumps(r,indent=2)+'\n');return r

def summarize(rs,out):
 configs=[f'{p}_c{c}' for p in PATTERNS for c in CS];rows=[]
 for cfg in configs:
  for k in [8,16,32,64,128,256]:
   for a in [.001,.002,.005,.01,.02,.05,.1,.2]:
    q=[next(x for x in r['rows'] if x['config']==cfg and x['k']==k and x['alpha']==a) for r in rs];b=np.array([r['baseline_cross_mse'] for r in rs]);cc=np.array([x['candidate_cross_mse'] for x in q]);rat=float(b.sum()/cc.sum());rng=np.random.default_rng(3100+k+int(a*1e5)+sum(map(ord,cfg)));ii=rng.integers(0,len(rs),(30000,len(rs)));vv=b[ii].sum(1)/cc[ii].sum(1);rows.append({'config':cfg,'points':q[0]['points'],'k':k,'alpha':a,'ratio':rat,'ci_low':float(np.quantile(vv,.025)),'ci_high':float(np.quantile(vv,.975)),'wins':int(np.sum(cc<b)),'worst':float(np.max(cc/b))})
 rows.sort(key=lambda x:x['ratio'],reverse=True);di=[]
 for cfg in configs:
  q=[next(x for x in r['diagnostics'] if x['config']==cfg) for r in rs];di.append({'config':cfg,**{z:float(np.mean([x[z] for x in q])) for z in ['points','delta_rms','corr','weighted_cosine']}})
 s={'n':len(rs),'best':rows[0],'rows':rows,'diagnostics':di};Path(out).write_text(json.dumps(s,indent=2)+'\n');return s

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--split',choices=['screen','validation'],default='screen');ap.add_argument('--workers',type=int,default=4);ap.add_argument('--out-dir',default=None);args=ap.parse_args();out=Path(args.out_dir or ROOT/f'internal_pilot_{args.split}');out.mkdir(parents=True,exist_ok=True);rs=[]
 with ProcessPoolExecutor(max_workers=args.workers) as ex:
  fs=[ex.submit(run_one,s,args.split,str(out)) for s in SPLITS[args.split]]
  for f in as_completed(fs):r=f.result();rs.append(r);print(json.dumps({'stage':'done','seed':r['seed'],'seconds':r['elapsed_seconds']}),flush=True)
 rs.sort(key=lambda r:SPLITS[args.split].index(r['seed']));s=summarize(rs,out/'summary.json');print(json.dumps({'stage':'summary','best':s['best'],'top_diagnostics':sorted(s['diagnostics'],key=lambda x:x['weighted_cosine'],reverse=True)[:10]}),flush=True)
if __name__=='__main__':main()
