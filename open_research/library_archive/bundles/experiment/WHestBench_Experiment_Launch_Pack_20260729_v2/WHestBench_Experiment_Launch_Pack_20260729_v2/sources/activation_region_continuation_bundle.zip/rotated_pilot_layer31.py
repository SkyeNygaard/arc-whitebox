#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,os,sys,time,csv
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/whest_research');A1=ROOT/'agent1/agent1_residual_spectrum_final';A9=ROOT/'agent9/agent9_continuation_bundle'
sys.path.insert(0,str(A1));sys.path.insert(0,str(A9));os.environ.setdefault('ARC_KERDOCK_ASSET',str(A9/'kerdock_mub5_seed3.npz'))
from agent1_residual_spectrum_screen import first_activation_matrix,make_weights,mse
from arc_cv.splits_v1 import SPLITS
from arc_cv.kerdock import full_real_kerdock_bases,chi_mean
from arc_experiments import rotation
D=256;RADIUS=np.float32(chi_mean(D))
REF={'screen':ROOT/'conditional_region_cv_screen/reference_cache','validation':ROOT/'conditional_region_cv_validation/reference_cache'}
CONFIGS={
 'r1c1':[(920000,1)],'r1c2':[(920000,2)],'r1c4':[(920000,4)],'r1c8':[(920000,8)],
 'r2c4':[(920000,4),(920001,4)],'r4c2':[(920000+i,2) for i in range(4)],
 'r2c8':[(920000,8),(920001,8)],'r4c8':[(920000+i,8) for i in range(4)],
}
def baseline(seed):
 w=make_weights(seed);R0=np.load(A1/'config/kerdock_rotation_seed3.npy').astype(np.float32)
 A=first_activation_matrix(w[0],R0);B=np.empty_like(A)
 for W in w[1:30]: np.matmul(A,W,out=B);np.maximum(B,0,out=B);A,B=B,A
 H31=np.empty_like(A);np.matmul(A,w[30],out=H31);A31=np.maximum(H31,0).astype(np.float32,copy=False)
 H32=np.empty_like(A31);np.matmul(A31,w[31],out=H32);bf=np.maximum(H32,0).mean(0,dtype=np.float64)
 return w,A31,H32,bf

def pilot_inputs(rot_seed,c):
 rng=np.random.default_rng(rot_seed+77123*c);idx=np.sort(rng.choice(D,size=c,replace=False));R=rotation(rot_seed)
 rows=[]
 for B in full_real_kerdock_bases(D):
  V=B[idx].astype(np.float32)@R
  rows.append(V);rows.append(-V)
 return (np.concatenate(rows,axis=0)*RADIUS).astype(np.float32,copy=False)

def pilot_mean31(w,rot_seed,c):
 X=pilot_inputs(rot_seed,c);A=X@w[0];np.maximum(A,0,out=A);B=np.empty_like(A)
 for W in w[1:31]: np.matmul(A,W,out=B);np.maximum(B,0,out=B);A,B=B,A
 return A.mean(0,dtype=np.float64)

def run_one(seed,split,out_dir):
 p=Path(out_dir)/f'seed_{seed}.json'
 if p.exists():return json.loads(p.read_text())
 t=time.perf_counter();w,A31,H32,bf=baseline(seed);emp=A31.mean(0,dtype=np.float64)
 with np.load(REF[split]/f'seed_{seed}_refs.npz') as z:taf=z['taf'];tbf=z['tbf'];truth31=.5*(z['ta31']+z['tb31'])
 base=.5*(mse(bf,taf)+mse(bf,tbf));p32=(H32>0).mean(0,dtype=np.float64);J=w[31].astype(np.float64)*p32[None,:];sens=np.linalg.norm(J,axis=1)
 rows=[];diags=[]
 for name,parts in CONFIGS.items():
  mus=[pilot_mean31(w,*q) for q in parts];pm=np.mean(mus,axis=0);d=pm-emp;true=truth31-emp
  diags.append({'config':name,'points':sum(2*129*c for _,c in parts),'delta_rms':float(np.sqrt(np.mean(d*d))),'true_rms':float(np.sqrt(np.mean(true*true))),
    'corr':float(np.corrcoef(d,true)[0,1]),'weighted_cosine':float(np.dot(d*sens,true*sens)/max(np.linalg.norm(d*sens)*np.linalg.norm(true*sens),1e-300))})
  order=np.argsort(-(np.abs(d)*sens))
  for k in [8,16,32,64,128,256]:
   idx=order[:k]
   basecorr=d[idx]@J[idx]
   for a in [.001,.002,.005,.01,.02,.05,.1,.2]:
    cand=bf+a*basecorr;cm=.5*(mse(cand,taf)+mse(cand,tbf))
    rows.append({'config':name,'points':sum(2*129*c for _,c in parts),'k':k,'alpha':a,'candidate_cross_mse':cm,'raw_mse_ratio':base/cm,'candidate_over_baseline':cm/base})
 r={'seed':seed,'split':split,'baseline_cross_mse':base,'rows':rows,'diagnostics':diags,'elapsed_seconds':time.perf_counter()-t};p.write_text(json.dumps(r,indent=2)+'\n');return r

def summary(rs,out):
 rows=[]
 for name in CONFIGS:
  for k in [8,16,32,64,128,256]:
   for a in [.001,.002,.005,.01,.02,.05,.1,.2]:
    sel=[next(x for x in r['rows'] if x['config']==name and x['k']==k and x['alpha']==a) for r in rs];b=np.array([r['baseline_cross_mse'] for r in rs]);c=np.array([x['candidate_cross_mse'] for x in sel]);ratio=float(b.sum()/c.sum());rng=np.random.default_rng(1000+k+int(a*10000)+len(name));ii=rng.integers(0,len(rs),(30000,len(rs)));v=b[ii].sum(1)/c[ii].sum(1)
    rows.append({'config':name,'points':sel[0]['points'],'k':k,'alpha':a,'ratio':ratio,'ci_low':float(np.quantile(v,.025)),'ci_high':float(np.quantile(v,.975)),'wins':int(np.sum(c<b)),'worst':float(np.max(c/b))})
 rows.sort(key=lambda x:x['ratio'],reverse=True);di=[]
 for name in CONFIGS:
  q=[next(x for x in r['diagnostics'] if x['config']==name) for r in rs];di.append({'config':name,**{k:float(np.mean([x[k] for x in q])) for k in ['points','delta_rms','true_rms','corr','weighted_cosine']}})
 s={'n':len(rs),'best':rows[0],'rows':rows,'diagnostics':di};Path(out).write_text(json.dumps(s,indent=2)+'\n');return s

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--split',choices=['screen','validation'],default='screen');ap.add_argument('--workers',type=int,default=4);ap.add_argument('--out-dir',default=None);ap.add_argument('--n',type=int,default=None);args=ap.parse_args();seeds=list(SPLITS[args.split]);
 if args.n:seeds=seeds[:args.n]
 out=Path(args.out_dir or ROOT/f'rotated_pilot_{args.split}');out.mkdir(parents=True,exist_ok=True);rs=[]
 with ProcessPoolExecutor(max_workers=args.workers) as ex:
  fs=[ex.submit(run_one,s,args.split,str(out)) for s in seeds]
  for f in as_completed(fs):r=f.result();rs.append(r);print(json.dumps({'stage':'done','seed':r['seed'],'seconds':r['elapsed_seconds']}),flush=True)
 rs.sort(key=lambda r:seeds.index(r['seed']));s=summary(rs,out/'summary.json');print(json.dumps({'stage':'summary','best':s['best'],'diagnostics':s['diagnostics']}),flush=True)
if __name__=='__main__':main()
