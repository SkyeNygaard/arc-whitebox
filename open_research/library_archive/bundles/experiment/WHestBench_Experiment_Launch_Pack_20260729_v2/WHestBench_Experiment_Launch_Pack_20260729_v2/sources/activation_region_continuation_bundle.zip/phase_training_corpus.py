#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,os,sys,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
import numpy as np
ROOT=Path('/mnt/data/whest_research');A1=ROOT/'agent1/agent1_residual_spectrum_final';A9=ROOT/'agent9/agent9_continuation_bundle'
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(A1));sys.path.insert(0,str(A9));os.environ.setdefault('ARC_KERDOCK_ASSET',str(A9/'kerdock_mub5_seed3.npz'))
from agent1_residual_spectrum_screen import first_activation_matrix,make_weights
from arc_experiments import rotation
from basis_phase_layer31 import features
from arc_cv.splits_v1 import SPLITS
D=256

def derive(version,n,used):
 out=[];i=0
 while len(out)<n:
  x=int.from_bytes(hashlib.sha256(f'{version}:{i}'.encode()).digest()[:4],'big')&0x7fffffff;i+=1
  if x<100000 or x in used or x in out:continue
  out.append(x)
 return out
used=set(sum([list(v) for v in SPLITS.values()],[]))
TRAIN=derive('arc-phase-large-train-v1',128,used);used.update(TRAIN)
DEV=derive('arc-phase-large-dev-v1',32,used)

def baseline(seed):
 w=make_weights(seed);R0=np.load(A1/'config/kerdock_rotation_seed3.npy').astype(np.float32);A=first_activation_matrix(w[0],R0);B=np.empty_like(A)
 for W in w[1:30]:np.matmul(A,W,out=B);np.maximum(B,0,out=B);A,B=B,A
 H31=np.empty_like(A);np.matmul(A,w[30],out=H31);A31=np.maximum(H31,0).astype(np.float32,copy=False)
 H32=np.empty_like(A31);np.matmul(A31,w[31],out=H32)
 return w,H31,A31,H32

def rotated_mean31(w,rs):
 A=first_activation_matrix(w[0],rotation(rs));B=np.empty_like(A)
 for W in w[1:31]:np.matmul(A,W,out=B);np.maximum(B,0,out=B);A,B=B,A
 return A.mean(0,dtype=np.float64)

def one(seed,index,split,out_dir,nrefs):
 p=Path(out_dir)/f'seed_{seed}.npz'
 if p.exists():return {'seed':seed,'cached':True}
 t=time.perf_counter();w,H,A,H32=baseline(seed);X,names,emp,B,J,sens=features(H,A,H32,w[31]);refs=[]
 for q in range(nrefs):refs.append(rotated_mean31(w,940000+1000*q+(index%997)))
 y=np.mean(refs,axis=0)-emp
 np.savez_compressed(p,X=X,y=y,hstd=H.std(0,dtype=np.float64),emp=emp,basis_means=B,feature_names=np.array(names,dtype='U40'),seed=np.int64(seed),ref_seeds=np.array([940000+1000*q+(index%997) for q in range(nrefs)]))
 return {'seed':seed,'seconds':time.perf_counter()-t}

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--split',choices=['train','dev'],default='train');ap.add_argument('--workers',type=int,default=8);ap.add_argument('--nrefs',type=int,default=1);ap.add_argument('--out-dir',default=str(ROOT/'phase_large_corpus'));args=ap.parse_args();seeds=TRAIN if args.split=='train' else DEV;out=Path(args.out_dir)/args.split;out.mkdir(parents=True,exist_ok=True)
 manifest={'version':'arc-phase-large-v1','train':TRAIN,'dev':DEV,'nrefs':args.nrefs};(Path(args.out_dir)/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 with ProcessPoolExecutor(max_workers=args.workers) as ex:
  fs=[ex.submit(one,s,i,args.split,str(out),args.nrefs) for i,s in enumerate(seeds)]
  for f in as_completed(fs):print(json.dumps({'stage':args.split,**f.result()}),flush=True)
if __name__=='__main__':main()
