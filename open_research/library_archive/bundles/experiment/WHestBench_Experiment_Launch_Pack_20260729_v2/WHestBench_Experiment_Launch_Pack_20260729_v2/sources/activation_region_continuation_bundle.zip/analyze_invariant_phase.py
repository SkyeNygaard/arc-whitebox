import sys,json,numpy as np
sys.path.insert(0,'/mnt/data/whest_research')
import basis_phase_layer31 as b
from sklearn.linear_model import Ridge,LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
D='/mnt/data/whest_research/basis_phase_data'
scr=b.load_split('screen',D); val=b.load_split('validation',D)

def feats(r):
 B=r['basis_means'][:128]; mu=B.mean(0); C=B-mu
 m2=np.mean(C**2,axis=0); sd=np.sqrt(m2)+1e-15
 m3=np.mean(C**3,axis=0);m5=np.mean(C**5,axis=0);m7=np.mean(C**7,axis=0)
 q=np.quantile(C,[.05,.1,.25,.75,.9,.95],axis=0)
 return np.column_stack([
  m3/(m2+1e-30), m5/(m2**2+1e-30), m7/(m2**3+1e-30),
  (q[5]+q[0]),(q[4]+q[1]),(q[3]+q[2]),
  r['basis_means'][128]-r['emp'], sd, np.mean(np.abs(C),axis=0),
 ])
names=['m3/m2','m5/m2^2','m7/m2^3','q95+q05','q90+q10','q75+q25','coord_dev','sd','mad']
for split,rows in [('screen',scr),('validation',val)]:
 X=np.concatenate([feats(r) for r in rows]);y=np.concatenate([r['y'] for r in rows])
 print('\n',split,'target mean',y.mean(),'std',y.std())
 for i,n in enumerate(names):
  x=X[:,i];coef=np.dot(x-x.mean(),y-y.mean())/np.dot(x-x.mean(),x-x.mean());corr=np.corrcoef(x,y)[0,1]
  print(n,'corr',corr,'coef',coef,'xstd',x.std())
# fit screen models and evaluate linear final correction with a fixed output shrink grid

def fitpred(cols,alpha=1.0,fit_intercept=True):
 X=np.concatenate([feats(r)[:,cols] for r in scr]);y=np.concatenate([r['y'] for r in scr])
 model=make_pipeline(StandardScaler(),Ridge(alpha=alpha,fit_intercept=fit_intercept));model.fit(X,y)
 return [model.predict(feats(r)[:,cols]).reshape(-1) for r in val],model

def score(rows,preds,sh):
 bs=[];cs=[]
 for r,p in zip(rows,preds):
  cand=r['bf']+sh*(p@r['J']);base=.5*(np.mean((r['bf']-r['taf'])**2)+np.mean((r['bf']-r['tbf'])**2));cm=.5*(np.mean((cand-r['taf'])**2)+np.mean((cand-r['tbf'])**2));bs.append(base);cs.append(cm)
 return sum(bs)/sum(cs),sum(c<b for b,c in zip(bs,cs)),max(c/b for b,c in zip(bs,cs))
for cols,label in [([0],'cubic'),([1],'quintic'),([2],'septic'),([0,1,2],'oddmom'),([0,3,4,5],'cubic_quant'),([0,1,2,3,4,5],'allodd'),([0,1,2,3,4,5,6,7,8],'all')]:
 for a in [0.1,1,10,100]:
  p,m=fitpred(cols,a)
  best=max([(score(val,p,s),s) for s in [.05,.1,.2,.3,.5,1.0]],key=lambda x:x[0][0])
  print('model',label,'ridge',a,'best_val',best,'coef',m[-1].coef_,'intercept',m[-1].intercept_)
