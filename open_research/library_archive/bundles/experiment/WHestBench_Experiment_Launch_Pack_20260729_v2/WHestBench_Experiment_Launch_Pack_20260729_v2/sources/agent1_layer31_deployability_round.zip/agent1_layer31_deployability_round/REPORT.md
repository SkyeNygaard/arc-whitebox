# Agent 1 continuation — deployability of the layer-31 residual channel

## Decision

**STOP the sampled partial-MUB pilot. CONTINUE the layer-31 mechanism only through analytic, learned, or otherwise near-zero-extra-trajectory coefficient estimators.**

Agent 1's prior round established that replacing the Kerdock layer-31 post-ReLU mean by a high-precision reference removes about 78% of final-layer MSE and transfers through 64 untouched networks. This continuation asked whether a small independent structured pilot can estimate the low-dimensional layer-31 correction cheaply enough to realize that oracle.

The answer is negative. The layer-31 signal is real and low-dimensional, and the final ReLU can be linearized essentially exactly. The unresolved problem is estimating the signed layer-31 mode coefficients. Partial-MUB sampling either leaves severe per-network sign tails or consumes as much compute as the raw-MSE improvement it creates.

## Frozen mechanism

The protected seed-3 Kerdock trajectory is propagated to layer 31. Its 129 complete antipodal MUB-basis means define a 129 x 256 observable matrix. PCA of that matrix supplies network-specific layer-31 directions.

The frozen candidate used:

- 16 independent pilot MUB bases / 8,192 rows;
- two globally rotated Kerdock designs;
- top 12 layer-31 basis-PCA modes;
- retain a mode when `abs(pilot_mean) / pilot_SE >= 0.5`;
- multiply retained pilot coefficients by 0.15;
- convert the layer-31 displacement to final output using the empirical Kerdock final-gate map `J = W32 * P_K(z32 > 0)`.

The tuple `(16 bases, rank 12, z=0.5, shrink=0.15)` was frozen before generating the new screen. It was an interior point on a broad development plateau, not a grid-edge choice.

## Fresh 8-network screen

Reference targets average 16 independent complete Kerdock rotations, split 8/8 to estimate target noise.

| Metric | Result |
|---|---:|
| Baseline raw MSE | `5.25691194e-7` |
| Candidate raw MSE | `3.88521621e-7` |
| Raw-MSE ratio | `1.35306x` |
| Raw 95% CI | `0.81272x–1.74617x` |
| Reference-noise fraction | `5.70%` |
| Baseline effective compute | `175.5 B` |
| Candidate estimated effective compute | `196.965 B` |
| Compute ratio | `1.12231x` |
| Baseline adjusted score | `3.39187e-7` |
| Candidate adjusted score | `2.81343e-7` |
| Adjusted ratio | `1.20560x` |
| Adjusted 95% CI | `0.72415x–1.55587x` |
| Wins | `4 / 8` |
| Worst candidate / baseline | `1.58636` |

The point estimate is positive because one network has unusually large baseline Kerdock error and the pilot helps it strongly. It does not meet the confidence or tail gates. Two networks degrade by more than 17%; the worst degrades by 58.6%.

**Screen recommendation: STOP.** Frozen validation and holdout remain unopened.

## Failure decomposition

After the frozen screen failed, those eight networks became development data for causal diagnosis.

### Rank-12 true-coefficient oracle

Project the high-precision true layer-31 mean error into exactly the same 12 observable basis-PCA modes, then apply the terminal correction:

- aggregate raw-MSE improvement: **`7.22581x`**;
- bootstrap 95% CI: **`2.71274x–15.19428x`**;
- wins: **8/8**;
- worst network still improves **`1.591x`**.

Thus rank 12 contains much more than enough useful signal. The candidate is not failing because its mode space is too small.

### Final-layer linearization

The rank-12 oracle gives:

- exact nonlinear replay: `7.22581x`;
- empirical-gate linear map: `7.22626x`;
- maximum per-network difference in candidate/baseline ratio: below `8e-5`.

The final ReLU is not the obstruction. A deployable estimator does not need to replay the 66,048-row final layer after constructing a small displacement.

### Pilot coefficients

For the frozen two-rotation pilot, mean cosine similarity between the estimated and true rank-12 coefficient vectors is only **`0.264`**. Increasing rotation diversity at the same 16-basis row count is not monotonic and does not solve the sign problem. Rotation-agreement gating either returns the baseline on most networks or retains harmful corrections.

## Pilot scaling

Post-screen diagnostic sweeps increased the independent pilot size while preserving the same basic estimator identity.

| Pilot | Representative raw ratio | Compute ratio | Adjusted ratio | Wins | Worst candidate/base | Conclusion |
|---|---:|---:|---:|---:|---:|---|
| 16 bases | `1.353x` frozen | `1.122x` | `1.206x` | 4/8 | `1.586` | Unsafe tail |
| 64 bases | `1.489x` | `1.482x` | `1.004x` | 8/8 | `0.937` | Tail resolves, score gain vanishes |
| 128 bases | `1.598x` | `1.963x` | `0.814x` | 8/8 | `0.976` | Robust raw gain, score-negative |

The 64- and 128-basis rows are post-hoc diagnostics, not staged candidates. They establish the mechanism of failure: enough structured samples recover the coefficient signs, but their propagation cost consumes or exceeds the statistical gain.

## Implication for the project

The next method should estimate only approximately 8–16 signed coefficients in the observable layer-31 basis-PCA space, but it cannot pay for another substantial input trajectory.

The benchmark target for any analytic or learned proposal is now precise:

1. Produce a layer-31 displacement in the frozen observable mode basis.
2. Map it through the cheap empirical final-gate matrix.
3. Judge the complete final prediction, not standalone layer-31 accuracy.
4. Require at least a 1.3x oracle/full-width raw improvement for a major method, or at least 5% adjusted improvement with a CI excluding zero and no severe tail for a cheap additive method.

Promising admissible sources of coefficient information include weight-only finite-width closure defects, adjoint-weighted covariance/cumulant contractions, or a learned weight-to-12-coefficient map with strict network splits. More sampled rotations, Haar pilots, or partial-MUB pilots should be closed.

## Exact reproduction

From the extracted bundle directory, with the owner project's environment available:

```bash
export AGENT9_BUNDLE=/path/to/agent9_10_oracle_bundle
export PYTHONPATH=$PWD/code:$AGENT9_BUNDLE
export OPENBLAS_NUM_THREADS=4 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4

python code/layer31_mub_mode_pilot_fresh.py \
  --split screen \
  --manifest config/layer31_mub_mode_pilot_split_v2.json \
  --preregistered config/layer31_mub_mode_pilot_preregistered_v2.json \
  --rotation-npy /path/to/kerdock_rotation_seed3.npy \
  --out-dir results/fresh_screen
```

Failure decomposition:

```bash
python code/layer31_mub_failure_decomposition.py \
  --seeds 575538457 1559754874 48930467 1457528141 \
          835339345 245382030 1870130490 1923055293 \
  --screen-dir results/fresh_screen \
  --rotation-npy /path/to/kerdock_rotation_seed3.npy \
  --output results/failure_decomposition.json
```

Pilot scaling is reproduced with `code/layer31_mode_mub_pilot_diagnostic.py`; the exact explored outputs are included in `results/layer31_mub_pilot_scaling_failedscreen_v2_merged.json`.
