#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
# Collect every previously declared network seed under config plus the old Agent-1 split.
used=set()
for p in ROOT.glob('config/*split*.json'):
    try:o=json.loads(p.read_text())
    except Exception:continue
    for k in ('screen','validation','holdout'):
        used.update(int(x) for x in o.get(k,[]))
old=Path('/mnt/data/arc_agents/agent1_residual_spectrum_final/config/split_manifest_v2.json')
if old.exists():
    o=json.loads(old.read_text())
    for k in ('screen','validation','holdout'):used.update(int(x) for x in o.get(k,[]))

def stream(label,n):
    out=[];i=0
    while len(out)<n:
        h=hashlib.sha256(f'{label}:{i}'.encode()).digest();i+=1
        x=int.from_bytes(h[:8],'little')%(2**31-1)
        if x<100000 or x in used or x in out:continue
        out.append(x);used.add(x)
    return out
manifest={
 'version':'layer31-mub-mode-pilot-v2',
 'derivation':'sha256("arc-layer31-mub-mode-pilot-v2:<split>:i") first 64 bits little-endian modulo 2^31-1; reject <100000, duplicates, and every previously declared split seed',
 'screen':stream('arc-layer31-mub-mode-pilot-v2:screen',8),
 'validation':stream('arc-layer31-mub-mode-pilot-v2:validation',24),
 'holdout':stream('arc-layer31-mub-mode-pilot-v2:holdout',64),
 'pilot_rotation_seeds':[950000,950001],
 'reference_rotation_seeds_a':list(range(960000,960008)),
 'reference_rotation_seeds_b':list(range(960008,960016)),
}
raw=json.dumps(manifest,sort_keys=True,separators=(',',':')).encode();manifest['sha256']=hashlib.sha256(raw).hexdigest()
prereg={
 'version':'layer31-mub-mode-pilot-candidate-v2',
 'frozen_before_fresh_screen':True,
 'mechanism':'Use the 129 observable layer-31 Kerdock-basis means to define PCA modes. Estimate the true-minus-baseline coefficients of the first 12 modes from 16 independent partial-MUB pilot bases, retain modes with |mean|/SE >= 0.5, shrink coefficients by 0.15, and map the layer-31 displacement through the empirical final-layer ReLU gate linearization.',
 'candidate':{
   'pilot_bases':16,'pilot_rows':8192,'pilot_rotations':2,'basis_order_seed':2026072951,
   'rank':12,'z_threshold':0.5,'shrink':0.15,
   'layer':31,'terminal_map':'J = W32 * empirical_Kerdock_gate_probability',
   'pca_source':'129 complete antipodal basis means of the protected seed-3 Kerdock layer-31 cloud',
   'pilot_source':'alternating bases from two globally rotated independent Kerdock/MUB designs',
   'reference_target':'average of 16 independent complete Kerdock rotations, split 8/8 for target-noise estimate',
 },
 'compute':{
   'baseline_effective_compute':175500000000.0,
   'pilot_propagation_estimate':21065266316.57913,
   'misc_pca_and_terminal_estimate':400000000.0,
   'candidate_effective_compute':196965266316.57913,
   'compute_ratio':196965266316.57913/175500000000.0,
   'note':'Conservative analytic estimate; exact FlopScope integration is required after statistical validation.'
 },
 'screen_gate':{
   'minimum_adjusted_score_improvement_fraction':0.05,
   'paired_bootstrap_adjusted_ratio_ci_lower_gt':1.0,
   'maximum_worst_network_candidate_over_baseline':1.05,
   'target_noise_fraction_max':0.10,
 },
 'validation_gate':{
   'minimum_adjusted_score_improvement_fraction':0.05,
   'paired_bootstrap_adjusted_ratio_ci_lower_gt':1.0,
   'maximum_worst_network_candidate_over_baseline':1.05,
 },
 'holdout_opening_rule':'Open only after the frozen 24-network validation passes without changing any candidate field.',
 'development_result':{
   'networks':8,'observed_raw_ratio':1.2954331546351783,
   'observed_raw_ratio_ci95':[1.14357510897069,1.3841808974145215],
   'adjusted_ratio':1.1542569047329398,'adjusted_improvement_fraction':0.13364174309932353,
   'wins':8,'worst_candidate_over_baseline':0.9651302695522684,
   'grid_position':'interior rank/shrink/z point on a broad rank-8-to-32 plateau'
 },
}
raw=json.dumps(prereg,sort_keys=True,separators=(',',':')).encode();prereg['sha256']=hashlib.sha256(raw).hexdigest()
(ROOT/'config/layer31_mub_mode_pilot_split_v2.json').write_text(json.dumps(manifest,indent=2)+'\n')
(ROOT/'config/layer31_mub_mode_pilot_preregistered_v2.json').write_text(json.dumps(prereg,indent=2)+'\n')
print(json.dumps({'manifest':manifest,'preregistered':prereg},indent=2))
