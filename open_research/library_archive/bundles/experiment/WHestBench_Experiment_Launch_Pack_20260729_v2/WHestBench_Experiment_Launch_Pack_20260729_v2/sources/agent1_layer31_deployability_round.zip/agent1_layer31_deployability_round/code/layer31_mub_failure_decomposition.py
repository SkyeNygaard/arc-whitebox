#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,os,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
AGENT9=Path(os.environ.get('AGENT9_BUNDLE','/mnt/data/arc_agents/work/agent9/unpacked/agent9_10_oracle_bundle'))
sys.path[:0]=[str(ROOT),str(AGENT9)]
from agent1_residual_spectrum_screen import D,make_weights,first_activation_matrix,mse
from cheap_final_basis_cv_fresh import basis_means
from arc_experiments import rotation
from layer31_mub_mode_pilot_fresh import basis_indices,capture31

def forward31(weights,r):
 a=first_activation_matrix(weights[0],r);b=np.empty_like(a)
 for w in weights[1:-1]:np.matmul(a,w,out=b);np.maximum(b,0,out=b);a,b=b,a
 return a.mean(0,dtype=np.float64)

def pilot_by_pattern(weights,rot_seeds,basis_order,total=16):
 # One propagation block after independently generating selected first-layer bases.
 chunks=[];owners=[]
 nrot=len(rot_seeds)
 for k in range(total):
  ri=k%nrot;bid=int(basis_order[k//nrot]);a1=first_activation_matrix(weights[0],rotation(int(rot_seeds[ri])));chunks.append(a1[basis_indices(bid)]);owners.append(ri)
 a=np.concatenate(chunks,0);b=np.empty_like(a)
 for w in weights[1:-1]:np.matmul(a,w,out=b);np.maximum(b,0,out=b);a,b=b,a
 means=a.reshape(total,2*D,D).mean(1,dtype=np.float64)
 return means,np.array(owners)

def evaluate(seed,args):
 w=make_weights(seed);r0=np.load(args.rotation_npy).astype(np.float32);a31,base,gate=capture31(w,r0);z=a31@w[-1];mu=a31.mean(0,dtype=np.float64);bm=basis_means(a31);xc=bm-bm.mean(0,keepdims=True);_,s,vt=np.linalg.svd(xc,full_matrices=False);v=vt.T[:,:args.rank]
 # final high-precision target already computed by frozen screen
 arr=np.load(Path(args.screen_dir)/f'seed_{seed}_arrays.npz');target=arr['target'].astype(float)
 # layer31 reference
 ra=[];rb=[]
 for group,seeds,dest in [('a',range(args.ref_start,args.ref_start+8),ra),('b',range(args.ref_start+8,args.ref_start+16),rb)]:
  for rs in seeds:dest.append(forward31(w,rotation(rs)))
 ta=np.mean(ra,0);tb=np.mean(rb,0);t31=.5*(ta+tb);noise31=mse(ta,tb)/4
 true_coeff=(t31-mu)@v
 W=np.asarray(w[-1],float);J=W*gate[None,:]
 def preds(coeff,active=None,shrink=1.0):
  if active is None:active=np.ones(len(coeff),bool)
  disp=v@(shrink*coeff*active);lin=base+disp@J;exact=np.maximum(z+disp@W,0).mean(0,dtype=np.float64)
  return {'disp':disp,'linear_mse':mse(lin,target),'exact_mse':mse(exact,target),'linear_over_base':mse(lin,target)/mse(base,target),'exact_over_base':mse(exact,target)/mse(base,target)}
 oracle=preds(true_coeff); oracle.pop('disp',None)
 out={'seed':seed,'baseline_mse':mse(base,target),'layer31_reference_noise':noise31,'true_coeff':true_coeff.tolist(),'oracle_rank_full':oracle}
 rng=np.random.default_rng(args.basis_order_seed);order=rng.permutation(128)
 patterns={2:[950000,950001],4:list(range(970000,970004)),8:list(range(970000,970008)),16:list(range(970000,970016))}
 rows=[]
 for nrot,seeds in patterns.items():
  p,owners=pilot_by_pattern(w,seeds,order,args.total_bases);coef=(p-mu[None,:])@v;mean=coef.mean(0);se=coef.std(0,ddof=1)/math.sqrt(len(coef));zscore=np.abs(mean)/np.maximum(se,1e-300);active=zscore>=args.z_threshold
  group_means=np.stack([coef[owners==ri].mean(0) for ri in range(nrot)])
  sign_agree=np.abs(np.sign(group_means).sum(0))==nrot
  median=np.median(group_means,axis=0)
  for method,c,a in [('pooled',mean,active),('agree',mean,active&sign_agree),('median',median,active)]:
   pr=preds(c,a,args.shrink)
   rows.append({'nrot':nrot,'method':method,'coeff':c.tolist(),'se':se.tolist(),'z':zscore.tolist(),'active':a.tolist(),'coeff_cosine_true':float(np.dot(c,true_coeff)/(np.linalg.norm(c)*np.linalg.norm(true_coeff)+1e-300)),'sign_accuracy_true':float(np.mean(np.sign(c[a])==np.sign(true_coeff[a]))) if a.any() else None,**{k:v for k,v in pr.items() if k!='disp'}})
 out['pilot_rows']=rows
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--seeds',nargs='+',type=int,required=True);ap.add_argument('--screen-dir',required=True);ap.add_argument('--output',required=True);ap.add_argument('--rotation-npy',default=str(ROOT/'config/kerdock_rotation_seed3.npy'));ap.add_argument('--rank',type=int,default=12);ap.add_argument('--total-bases',type=int,default=16);ap.add_argument('--basis-order-seed',type=int,default=2026072951);ap.add_argument('--z-threshold',type=float,default=.5);ap.add_argument('--shrink',type=float,default=.15);ap.add_argument('--ref-start',type=int,default=960000);args=ap.parse_args()
 p=Path(args.output);p.parent.mkdir(parents=True,exist_ok=True);nets=[]
 if p.exists():
  try:nets=json.load(open(p)).get('networks',[])
  except:pass
 done={n['seed'] for n in nets}
 for s in args.seeds:
  if s in done:continue
  t=time.perf_counter();n=evaluate(s,args);nets.append(n);p.write_text(json.dumps({'config':vars(args),'networks':nets},indent=2)+'\n');print(json.dumps({'seed':s,'sec':time.perf_counter()-t,'base':n['baseline_mse'],'oracle':n['oracle_rank_full']['exact_over_base'],'rows':[{k:r[k] for k in ('nrot','method','linear_over_base','exact_over_base','coeff_cosine_true')} for r in n['pilot_rows']]}),flush=True)
if __name__=='__main__':main()
