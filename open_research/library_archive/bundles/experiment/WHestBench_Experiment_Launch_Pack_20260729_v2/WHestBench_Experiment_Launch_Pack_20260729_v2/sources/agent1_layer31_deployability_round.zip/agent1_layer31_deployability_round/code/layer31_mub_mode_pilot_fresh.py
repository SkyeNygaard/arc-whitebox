#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math, os, sys, time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
AGENT9=Path(os.environ.get('AGENT9_BUNDLE','/mnt/data/arc_agents/work/agent9/unpacked/agent9_10_oracle_bundle'))
sys.path[:0]=[str(ROOT),str(AGENT9)]
from agent1_residual_spectrum_screen import D, make_weights, first_activation_matrix, mse
from cheap_final_basis_cv_fresh import basis_means
from arc_experiments import rotation

KERDOCK_N=66048

def basis_indices(b:int)->np.ndarray:
    split=128*D
    if b<128:
        return np.r_[np.arange(b*D,(b+1)*D),np.arange(split+b*D,split+(b+1)*D)]
    return np.arange(2*split,2*split+2*D)

def capture31(weights:list[np.ndarray],r0:np.ndarray):
    a=first_activation_matrix(weights[0],r0);buf=np.empty_like(a)
    for w in weights[1:-1]:
        np.matmul(a,w,out=buf);np.maximum(buf,0,out=buf);a,buf=buf,a
    z=a@weights[-1]
    gate=np.mean(z>0,axis=0,dtype=np.float64)
    base=np.maximum(z,0).mean(axis=0,dtype=np.float64)
    return a,base,gate

def partial_mub31(weights:list[np.ndarray],rot_seeds:list[int],basis_order:np.ndarray,max_total:int)->np.ndarray:
    by_rotation=[]
    for ri,rs in enumerate(rot_seeds):
        positions=list(range(ri,max_total,len(rot_seeds)))
        bids=[int(basis_order[k//len(rot_seeds)]) for k in positions]
        a1=first_activation_matrix(weights[0],rotation(int(rs)))
        a=np.concatenate([a1[basis_indices(b)] for b in bids],axis=0);buf=np.empty_like(a)
        for w in weights[1:-1]:
            np.matmul(a,w,out=buf);np.maximum(buf,0,out=buf);a,buf=buf,a
        by_rotation.append(a.reshape(len(bids),2*D,D).mean(axis=1,dtype=np.float64))
    curs=[0]*len(rot_seeds);out=[]
    for k in range(max_total):
        ri=k%len(rot_seeds);out.append(by_rotation[ri][curs[ri]]);curs[ri]+=1
    return np.stack(out)

def candidate_prediction(weights,r0,prereg,manifest):
    cfg=prereg['candidate'];rank=int(cfg['rank']);nb=int(cfg['pilot_bases']);zthr=float(cfg['z_threshold']);shrink=float(cfg['shrink'])
    a31,base,gate=capture31(weights,r0)
    mu=a31.mean(axis=0,dtype=np.float64)
    bm=basis_means(a31);centered=bm-bm.mean(axis=0,keepdims=True)
    # Full SVD is deterministic. PCA signs cancel because pilot coefficients use the same vectors.
    _,sing,vt=np.linalg.svd(centered,full_matrices=False);v=vt.T[:,:rank]
    rng=np.random.default_rng(int(cfg['basis_order_seed']));order=rng.permutation(128)
    p=partial_mub31(weights,[int(x) for x in manifest['pilot_rotation_seeds']],order,nb)
    coeff=(p-mu[None,:])@v
    mean=coeff.mean(axis=0)
    se=coeff.std(axis=0,ddof=1)/math.sqrt(nb)
    z=np.abs(mean)/np.maximum(se,1e-300)
    active=z>=zthr
    displacement=v@(shrink*mean*active)
    terminal=np.asarray(weights[-1],dtype=np.float64)*gate[None,:]
    correction=displacement@terminal
    pred=base+correction
    meta={
      'baseline':base,'candidate':pred,'correction':correction,'displacement':displacement,
      'mode_coeff_mean':mean,'mode_coeff_se':se,'mode_z':z,'active_modes':active,
      'pca_singular_values':sing[:rank],
      'pilot_basis_order':order[:nb].astype(np.int64),
    }
    return meta

def forward_final_mean(weights,r)->np.ndarray:
    a=first_activation_matrix(weights[0],r);buf=np.empty_like(a)
    for w in weights[1:]:
        np.matmul(a,w,out=buf);np.maximum(buf,0,out=buf);a,buf=buf,a
    return a.mean(axis=0,dtype=np.float64)

def bootstrap_ratio(base,cand,seed,n_boot=50000):
    rng=np.random.default_rng(seed);idx=rng.integers(0,len(base),(n_boot,len(base)))
    rr=base[idx].mean(1)/np.maximum(cand[idx].mean(1),1e-300)
    return {'ratio':float(base.mean()/max(cand.mean(),1e-300)),'ci95':[float(x) for x in np.quantile(rr,[.025,.975])]}

def run_network(seed,args,manifest,prereg,r0):
    od=Path(args.out_dir);od.mkdir(parents=True,exist_ok=True)
    jp=od/f'seed_{seed}.json';ap=od/f'seed_{seed}_arrays.npz'
    if jp.exists() and ap.exists() and not args.force:return json.loads(jp.read_text())
    w=make_weights(seed);t0=time.perf_counter();tc=time.perf_counter();meta=candidate_prediction(w,r0,prereg,manifest);cand_sec=time.perf_counter()-tc
    refs_a=[];refs_b=[];timings=[]
    for group,seeds,dest in [('a',manifest['reference_rotation_seeds_a'],refs_a),('b',manifest['reference_rotation_seeds_b'],refs_b)]:
        for rs in seeds:
            tr=time.perf_counter();dest.append(forward_final_mean(w,rotation(int(rs))));elapsed=time.perf_counter()-tr
            timings.append({'group':group,'rotation_seed':int(rs),'seconds':elapsed})
            print(json.dumps({'stage':args.split,'network_seed':seed,'reference_group':group,'rotation_seed':int(rs),'seconds':elapsed}),flush=True)
    ta=np.mean(np.stack(refs_a),axis=0);tb=np.mean(np.stack(refs_b),axis=0);target=.5*(ta+tb)
    base=meta['baseline'];cand=meta['candidate'];noise=mse(ta,tb)/4;base_m=mse(base,target);cand_m=mse(cand,target)
    np.savez_compressed(ap,seed=np.int64(seed),baseline=base,candidate=cand,correction=meta['correction'],displacement=meta['displacement'],target_a=ta,target_b=tb,target=target,mode_coeff_mean=meta['mode_coeff_mean'],mode_coeff_se=meta['mode_coeff_se'],mode_z=meta['mode_z'],active_modes=meta['active_modes'],pca_singular_values=meta['pca_singular_values'],pilot_basis_order=meta['pilot_basis_order'])
    payload={'seed':seed,'split':args.split,'baseline_mse':base_m,'candidate_mse':cand_m,'candidate_over_baseline':cand_m/max(base_m,1e-300),'raw_ratio':base_m/max(cand_m,1e-300),'reference_noise_mse':noise,'noise_fraction':noise/max(base_m,1e-300),'baseline_noise_corrected_mse':max(0.,base_m-noise),'candidate_noise_corrected_mse':max(0.,cand_m-noise),'active_modes':int(meta['active_modes'].sum()),'mode_z':meta['mode_z'].tolist(),'correction_rms':float(np.sqrt(np.mean(meta['correction']**2))),'displacement_rms':float(np.sqrt(np.mean(meta['displacement']**2))),'candidate_seconds_excluding_references':cand_sec,'reference_timings':timings,'elapsed_seconds':time.perf_counter()-t0,'array_file':ap.name}
    jp.write_text(json.dumps(payload,indent=2)+'\n');return payload

def summarize(rows,split,prereg):
    b=np.array([r['baseline_mse'] for r in rows]);c=np.array([r['candidate_mse'] for r in rows]);n=np.array([r['reference_noise_mse'] for r in rows]);bc=np.maximum(b-n,0);cc=np.maximum(c-n,0)
    obs=bootstrap_ratio(b,c,2026072961+len(rows));cor=bootstrap_ratio(bc,cc,2026072962+len(rows))
    cb=float(prereg['compute']['baseline_effective_compute']);cn=float(prereg['compute']['candidate_effective_compute']);comp=cn/cb;adj=obs['ratio']/comp;adjci=[x/comp for x in obs['ci95']];gain=1-1/adj
    worst=float(np.max(c/np.maximum(b,1e-300)));noise_frac=float(n.mean()/max(b.mean(),1e-300))
    gate_cfg=prereg['screen_gate'] if split=='screen' else prereg['validation_gate'];gate={'adjusted_gain_pass':gain>=float(gate_cfg['minimum_adjusted_score_improvement_fraction']),'ci_pass':adjci[0]>float(gate_cfg['paired_bootstrap_adjusted_ratio_ci_lower_gt']),'tail_pass':worst<=float(gate_cfg['maximum_worst_network_candidate_over_baseline'])}
    if split=='screen':gate['noise_pass']=noise_frac<=float(gate_cfg['target_noise_fraction_max'])
    gate['overall_pass']=bool(all(gate.values()))
    return {'split':split,'n_networks':len(rows),'baseline_observed_mean_mse':float(b.mean()),'candidate_observed_mean_mse':float(c.mean()),'observed_raw_ratio':obs['ratio'],'observed_raw_ratio_ci95':obs['ci95'],'baseline_noise_corrected_mean_mse':float(bc.mean()),'candidate_noise_corrected_mean_mse':float(cc.mean()),'noise_corrected_ratio':cor['ratio'],'noise_corrected_ratio_ci95':cor['ci95'],'reference_noise_mean_mse':float(n.mean()),'reference_noise_fraction':noise_frac,'baseline_effective_compute':cb,'candidate_effective_compute_estimate':cn,'compute_ratio':comp,'adjusted_score_ratio_baseline_over_candidate':adj,'adjusted_score_ratio_ci95':adjci,'adjusted_score_improvement_fraction':gain,'wins':int((c<b).sum()),'worst_candidate_over_baseline':worst,'median_candidate_over_baseline':float(np.median(c/np.maximum(b,1e-300))),'mean_active_modes':float(np.mean([r['active_modes'] for r in rows])),'gate':gate,'per_network':rows}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--split',choices=['screen','validation','holdout'],required=True);ap.add_argument('--manifest',default=str(ROOT/'config/layer31_mub_mode_pilot_split_v2.json'));ap.add_argument('--preregistered',default=str(ROOT/'config/layer31_mub_mode_pilot_preregistered_v2.json'));ap.add_argument('--rotation-npy',default=str(ROOT/'config/kerdock_rotation_seed3.npy'));ap.add_argument('--out-dir',required=True);ap.add_argument('--force',action='store_true');args=ap.parse_args()
    manifest=json.loads(Path(args.manifest).read_text());prereg=json.loads(Path(args.preregistered).read_text());seeds=[int(x) for x in manifest[args.split]];r0=np.load(args.rotation_npy,allow_pickle=False).astype(np.float32);od=Path(args.out_dir);od.mkdir(parents=True,exist_ok=True);rows=[]
    for i,s in enumerate(seeds,1):
        tr=time.perf_counter();row=run_network(s,args,manifest,prereg,r0);rows.append(row);sm=summarize(rows,args.split,prereg);(od/f'{args.split}_summary_partial.json').write_text(json.dumps(sm,indent=2)+'\n')
        print(json.dumps({'stage':args.split,'completed':i,'total':len(seeds),'seed':s,'network_raw_ratio':row['raw_ratio'],'candidate_over_baseline':row['candidate_over_baseline'],'active_modes':row['active_modes'],'aggregate_adjusted_ratio':sm['adjusted_score_ratio_baseline_over_candidate'],'aggregate_worst':sm['worst_candidate_over_baseline'],'seconds':time.perf_counter()-tr}),flush=True)
    sm=summarize(rows,args.split,prereg);(od/f'{args.split}_summary.json').write_text(json.dumps(sm,indent=2)+'\n');print(json.dumps({'done':True,'summary':sm},indent=2),flush=True)
if __name__=='__main__':main()
