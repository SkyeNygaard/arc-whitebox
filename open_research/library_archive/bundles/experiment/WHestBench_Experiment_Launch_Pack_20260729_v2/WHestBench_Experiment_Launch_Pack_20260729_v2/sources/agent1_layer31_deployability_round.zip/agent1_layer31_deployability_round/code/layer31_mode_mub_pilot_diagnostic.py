#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,os,sys,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
AGENT9=Path(os.environ.get('AGENT9_BUNDLE','/mnt/data/arc_agents/work/agent9/unpacked/agent9_10_oracle_bundle'))
sys.path[:0]=[str(ROOT),str(AGENT9)]
from agent1_residual_spectrum_screen import D,make_weights,first_activation_matrix,mse
from cheap_final_basis_cv_fresh import basis_means
from arc_experiments import rotation
BASE_C=175.5e9; KERDOCK_N=66048

def basis_indices(b):
    split=128*D
    if b<128:
        return np.r_[np.arange(b*D,(b+1)*D),np.arange(split+b*D,split+(b+1)*D)]
    return np.arange(2*split,2*split+2*D)

def capture31(weights,r0):
    a=first_activation_matrix(weights[0],r0);b=np.empty_like(a)
    for w in weights[1:-1]:
        np.matmul(a,w,out=b);np.maximum(b,0,out=b);a,b=b,a
    z=a@weights[-1];gate=np.mean(z>0,axis=0,dtype=np.float64);base=np.maximum(z,0).mean(0,dtype=np.float64)
    return a,base,gate

def partial_mub31(weights,rot_seeds,basis_order,max_total):
    # Propagate all selected bases from each global rotation in one dense block,
    # then restore the alternating nested order.
    by_rotation=[]
    counts=[]
    for ri,rs in enumerate(rot_seeds):
        positions=list(range(ri,max_total,len(rot_seeds)));counts.append(len(positions))
        bids=[int(basis_order[k//len(rot_seeds)]) for k in positions]
        a1=first_activation_matrix(weights[0],rotation(rs))
        a=np.concatenate([a1[basis_indices(b)] for b in bids],axis=0);b=np.empty_like(a)
        for w in weights[1:-1]:
            np.matmul(a,w,out=b);np.maximum(b,0,out=b);a,b=b,a
        by_rotation.append(a.reshape(len(bids),2*D,D).mean(1,dtype=np.float64))
    curs=[0]*len(rot_seeds);per=[]
    for k in range(max_total):
        ri=k%len(rot_seeds);per.append(by_rotation[ri][curs[ri]]);curs[ri]+=1
    return np.stack(per)
def bootstrap(b,c,seed=7512,n=30000):
    rng=np.random.default_rng(seed);ix=rng.integers(0,len(b),(n,len(b)));r=b[ix].mean(1)/c[ix].mean(1);return float(b.mean()/c.mean()),[float(x) for x in np.quantile(r,[.025,.975])]
def run(seed,args,r0,basis_order):
    with np.load(Path(args.array_dir)/f'seed_{seed}_arrays.npz') as z:target=z['target'].astype(float);ta=z['target_a'].astype(float);tb=z['target_b'].astype(float)
    w=make_weights(seed);a,base,gate=capture31(w,r0);mu=a.mean(0,dtype=np.float64);x=basis_means(a);xc=x-x.mean(0,keepdims=True);_,_,vt=np.linalg.svd(xc,full_matrices=False);v=vt.T
    p=partial_mub31(w,args.pilot_rotation_seeds,basis_order,args.max_bases);j=np.asarray(w[-1],float)*gate[None,:];base_mse=mse(base,target);noise=mse(ta,tb)/4;rows=[]
    for nb in args.basis_counts:
        db=p[:nb]-mu[None,:]
        for rank in args.ranks:
            coeff=db@v[:,:rank];mean=coeff.mean(0);se=coeff.std(0,ddof=1)/math.sqrt(nb) if nb>1 else np.full(rank,np.inf)
            for zthr in args.z_thresholds:
                active=np.abs(mean)/np.maximum(se,1e-300)>=zthr
                for shrink in args.shrinks:
                    ep=v[:,:rank]@(shrink*mean*active);pred=base+ep@j
                    rows.append({'basis_count':nb,'rows':nb*2*D,'rank':rank,'z_threshold':zthr,'shrink':shrink,'active_modes':int(active.sum()),
                                 'coeff_mean':mean.tolist(),'coeff_se':se.tolist(),'baseline_mse':base_mse,'candidate_mse':mse(pred,target),'noise':noise,
                                 'candidate_over_baseline':mse(pred,target)/base_mse,'correction_rms':float(np.sqrt(np.mean((ep@j)**2)))})
    return {'seed':seed,'rows':rows}
def summarize(nets,nrot):
    keys=sorted({(r['basis_count'],r['rank'],r['z_threshold'],r['shrink']) for n in nets for r in n['rows']});out=[]
    for key in keys:
        rs=[[r for r in n['rows'] if (r['basis_count'],r['rank'],r['z_threshold'],r['shrink'])==key][0] for n in nets]
        b=np.array([r['baseline_mse'] for r in rs]);c=np.array([r['candidate_mse'] for r in rs]);noise=np.array([r['noise'] for r in rs]);rat,ci=bootstrap(b,c,7512+key[0]+key[1]);bc=np.maximum(b-noise,0);cc=np.maximum(c-noise,0);cr,cci=bootstrap(bc,cc,8512+key[0]+key[1])
        pilot_fraction=(key[0]*2*D/KERDOCK_N)*(30/31);first_layer_overhead=nrot*.15e9;added=pilot_fraction*BASE_C+first_layer_overhead+.1e9;comp=(BASE_C+added)/BASE_C;adj=rat/comp
        out.append({'basis_count':key[0],'rows':key[0]*2*D,'rank':key[1],'z_threshold':key[2],'shrink':key[3],
                    'observed_ratio':rat,'observed_ci95':ci,'noise_corrected_ratio':cr,'noise_corrected_ci95':cci,'compute_estimate':BASE_C+added,
                    'compute_ratio':comp,'adjusted_ratio':adj,'adjusted_gain':1-1/adj,'wins':int((c<b).sum()),'worst':float(np.max(c/b)),
                    'mean_active_modes':float(np.mean([r['active_modes'] for r in rs])),'per_network':(c/b).tolist()})
    return sorted(out,key=lambda x:x['adjusted_ratio'],reverse=True)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',nargs='+',type=int,required=True);ap.add_argument('--array-dir',required=True);ap.add_argument('--output',required=True);ap.add_argument('--rotation-npy',default=str(ROOT/'config/kerdock_rotation_seed3.npy'));ap.add_argument('--pilot-rotation-seeds',nargs='+',type=int,default=[930000,930001]);ap.add_argument('--basis-order-seed',type=int,default=2026072951);ap.add_argument('--max-bases',type=int,default=32);ap.add_argument('--basis-counts',nargs='+',type=int,default=[2,4,8,16,32]);ap.add_argument('--ranks',nargs='+',type=int,default=[1,2,4,8]);ap.add_argument('--z-thresholds',nargs='+',type=float,default=[0,.5,1,1.5,2]);ap.add_argument('--shrinks',nargs='+',type=float,default=[.02,.05,.1,.2,.3,.5,1]);args=ap.parse_args()
    rng=np.random.default_rng(args.basis_order_seed);order=rng.permutation(128);r0=np.load(args.rotation_npy).astype(np.float32);nets=[];out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True)
    for s in args.seeds:
        t=time.perf_counter();nets.append(run(s,args,r0,order));payload={'config':vars(args),'basis_order':order.tolist(),'networks':nets,'summary':summarize(nets,len(args.pilot_rotation_seeds))};out.write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps({'seed':s,'sec':time.perf_counter()-t,'best':payload['summary'][0]}),flush=True)
    print(json.dumps({'done':True,'top':payload['summary'][:25]},indent=2))
if __name__=='__main__':main()
