import sys,json
from pathlib import Path
import numpy as np,torch
sys.path.insert(0,'/mnt/data/arc_weight_model')
from bieq_layer31_experiment import load_data,ForwardEqNet,eval_replay,bootstrap_ratio
root=Path('/mnt/data/arc_weight_model/bieq_w32_big');D=load_data(root/'data');m=D['meta'];N=512;n=32
W0=np.asarray(D['weights']);S0=np.asarray(D['kstats']);B0=np.asarray(D['basis31']);P=np.asarray(D['particles31']);T=(np.asarray(D['targets_a'])+np.asarray(D['targets_b']))*.5;K=S0[...,0]
W=torch.from_numpy(np.array(W0[:N],copy=True));S=torch.from_numpy(np.array(S0[:N],copy=True));B=torch.from_numpy(np.array(B0[:N],copy=True));Y=T[:N,-2]-K[:N,-2];scale=float(Y.std());Yt=torch.from_numpy((Y/scale).astype(np.float32));model=ForwardEqNet(32);torch.manual_seed(37);torch.set_num_threads(4);opt=torch.optim.AdamW(model.parameters(),lr=1.5e-3,weight_decay=2e-4);rng=np.random.default_rng(37)
nt=m['n_train'];nc=m['n_calib'];ci=np.arange(nt,nt+nc);Wc=torch.from_numpy(np.array(W0[ci],copy=True));Sc=torch.from_numpy(np.array(S0[ci],copy=True));Bc=torch.from_numpy(np.array(B0[ci],copy=True));yc=(T[ci,-2]-K[ci,-2])/scale;best=1e99;state=None;hist=[]
for ep in range(2):
 model.train();perm=rng.permutation(N);ls=[]
 for st in range(0,N,128):
  ix=torch.from_numpy(perm[st:st+128]);opt.zero_grad(set_to_none=True);p,_=model(W[ix],S[ix],B[ix]);loss=((p-Yt[ix])**2).mean();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),2);opt.step();ls.append(float(loss.detach()))
 model.eval();
 with torch.no_grad():pc,_=model(Wc,Sc,Bc);cal=float(np.mean((pc.numpy()-yc)**2))
 hist.append({'epoch':ep+1,'train':float(np.mean(ls)),'cal':cal});print(hist[-1],flush=True)
 if cal<best:best=cal;state={k:v.detach().clone() for k,v in model.state_dict().items()}
model.load_state_dict(state);vi=np.arange(nt+nc,nt+nc+m['n_val']);Wv=torch.from_numpy(np.array(W0[vi],copy=True));Sv=torch.from_numpy(np.array(S0[vi],copy=True));Bv=torch.from_numpy(np.array(B0[vi],copy=True));model.eval()
with torch.no_grad():pc,_=model(Wc,Sc,Bc);pv,_=model(Wv,Sv,Bv)
pc=pc.numpy()*scale;pv=pv.numpy()*scale;yc0=T[ci,-2]-K[ci,-2];yv=T[vi,-2]-K[vi,-2];alpha=float(np.clip(np.sum(pc*yc0)/max(np.sum(pc*pc),1e-30),-1,1.5));ev=eval_replay(W0[vi],P[vi],K[vi],T[vi],pv,alpha);ratio,ci95=bootstrap_ratio(ev['base'],ev['corr'],seed=1771)
r=dict(kind='identity_forward',train_examples=N,params=sum(p.numel() for p in model.parameters()),best_cal=best,alpha=alpha,effective_corr=float(np.corrcoef(yv.ravel(),(alpha*pv).ravel())[0,1]),effective_layer31_gain=float(np.mean(yv*yv)/np.mean((yv-alpha*pv)**2)),replay_gain=ratio,replay_ci95=ci95,wins=ev['wins'],baseline_mse=ev['base_mean'],corrected_mse=ev['corr_mean'],worst_ratio=float(np.max(ev['corr']/ev['base'])),median_ratio=float(np.median(ev['corr']/ev['base'])),history=hist);(root/'identity_forward_512_result.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
