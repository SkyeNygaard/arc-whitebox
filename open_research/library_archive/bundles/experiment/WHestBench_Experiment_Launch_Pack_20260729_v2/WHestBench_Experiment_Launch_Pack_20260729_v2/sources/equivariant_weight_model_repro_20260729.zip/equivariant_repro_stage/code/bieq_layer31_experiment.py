#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import time
import os
from pathlib import Path
from typing import Dict, Tuple

import numpy as np
import torch
from scipy.special import gamma
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

ROOT = Path('/mnt/data/arc_weight_model/weightspace_v3/v3_bundle')
import sys
sys.path.insert(0, str(ROOT))
import whest_experiments as wx
from kerdock_error_probe import design


def make_weights(seed: int, depth: int, width: int) -> np.ndarray:
    return wx.make_weights(seed, depth, width).astype(np.float32)


def qmc_inputs(width: int, power: int, seed: int) -> np.ndarray:
    return wx.qmc_gaussian(width, power, 1, seed).astype(np.float32)


def forward_means(W: np.ndarray, X: np.ndarray, chunk: int = 8192) -> np.ndarray:
    sums = np.zeros((len(W), W.shape[1]), dtype=np.float64)
    count = 0
    for start in range(0, len(X), chunk):
        h = np.array(X[start:start + chunk], dtype=np.float32, copy=True)
        for li, A in enumerate(W):
            h = h @ A.T
            np.maximum(h, 0, out=h)
            sums[li] += h.sum(axis=0, dtype=np.float64)
        count += len(h)
    return (sums / count).astype(np.float32)


def particle_stats(h: np.ndarray) -> np.ndarray:
    # Per-neuron [mean, std, standardized skew, excess kurtosis].
    x = h.astype(np.float64, copy=False)
    mu = x.mean(axis=0)
    c = x - mu
    sd = np.sqrt(np.maximum(np.mean(c * c, axis=0), 1e-12))
    z = c / sd
    skew = np.mean(z ** 3, axis=0)
    kurt = np.mean(z ** 4, axis=0) - 3.0
    return np.stack([mu, sd, skew, kurt], axis=-1).astype(np.float32)


def generate_dataset(out: Path, n_train: int, n_calib: int, n_val: int, width: int, depth: int,
                     train_power: int, val_power: int, seed: int) -> None:
    out.mkdir(parents=True, exist_ok=True)
    total = n_train + n_calib + n_val
    meta_path = out / 'meta.json'
    if meta_path.exists():
        meta = json.loads(meta_path.read_text())
        expected = dict(n_train=n_train, n_calib=n_calib, n_val=n_val, width=width, depth=depth,
                        train_power=train_power, val_power=val_power, seed=seed)
        if all(meta.get(k) == v for k, v in expected.items()) and meta.get('complete'):
            print('dataset cache hit', out, flush=True)
            return

    X = design(width).astype(np.float32)
    mrad = math.sqrt(2.0) * gamma((width + 1) / 2.0) / (math.sqrt(width) * gamma(width / 2.0))
    X *= np.float32(mrad)
    n_particles = len(X)
    n_groups = width // 2 + 1  # d(d+2)/(2d) = d/2+1 complete antipodal bases
    group_size = 2 * width
    assert n_groups * group_size == n_particles

    expected_weight_bytes = 128 + total * depth * width * width * 4
    resume = (out / 'weights.npy').exists()
    mode = 'r+' if resume else 'w+'
    arrays = {
        'weights': np.lib.format.open_memmap(out / 'weights.npy', mode=mode, dtype=np.float32,
                                            shape=(total, depth, width, width)),
        'targets_a': np.lib.format.open_memmap(out / 'targets_a.npy', mode=mode, dtype=np.float32,
                                              shape=(total, depth, width)),
        'targets_b': np.lib.format.open_memmap(out / 'targets_b.npy', mode=mode, dtype=np.float32,
                                              shape=(total, depth, width)),
        'kstats': np.lib.format.open_memmap(out / 'kstats.npy', mode=mode, dtype=np.float32,
                                           shape=(total, depth, width, 4)),
        'basis31': np.lib.format.open_memmap(out / 'basis31.npy', mode=mode, dtype=np.float32,
                                            shape=(total, n_groups, width)),
        'particles31': np.lib.format.open_memmap(out / 'particles31.npy', mode=mode, dtype=np.float32,
                                                shape=(total, n_particles, width)),
    }
    if resume:
        done_mask = (np.any(np.asarray(arrays['weights']).reshape(total, -1) != 0, axis=1) &
                     np.any(np.asarray(arrays['targets_a']).reshape(total, -1) != 0, axis=1) &
                     np.any(np.asarray(arrays['targets_b']).reshape(total, -1) != 0, axis=1) &
                     np.any(np.asarray(arrays['kstats']).reshape(total, -1) != 0, axis=1) &
                     np.any(np.asarray(arrays['particles31']).reshape(total, -1) != 0, axis=1))
        zeros = np.flatnonzero(~done_mask)
        start_i = int(zeros[0]) if len(zeros) else total
        print('resuming dataset at', start_i, flush=True)
    else:
        start_i = 0
    t0 = time.time()
    limit = int(os.environ.get('GEN_LIMIT', '0'))
    end_i = min(total, start_i + limit) if limit > 0 else total
    for i in range(start_i, end_i):
        W = make_weights(seed + i, depth, width)
        arrays['weights'][i] = W
        h = X.copy()
        for li, A in enumerate(W):
            h = h @ A.T
            np.maximum(h, 0, out=h)
            # Mean/std at every layer; expensive skew/kurt only in the final two layers.
            x64 = h.astype(np.float64, copy=False)
            mu = x64.mean(axis=0)
            centered = x64 - mu
            sd = np.sqrt(np.maximum(np.mean(centered * centered, axis=0), 1e-12))
            arrays['kstats'][i, li, :, 0] = mu.astype(np.float32)
            arrays['kstats'][i, li, :, 1] = sd.astype(np.float32)
            if li >= depth - 2:
                z = centered / sd
                arrays['kstats'][i, li, :, 2] = np.mean(z ** 3, axis=0).astype(np.float32)
                arrays['kstats'][i, li, :, 3] = (np.mean(z ** 4, axis=0) - 3.0).astype(np.float32)
            else:
                arrays['kstats'][i, li, :, 2:] = 0.0
            if li == depth - 2:
                arrays['particles31'][i] = h
                arrays['basis31'][i] = h.reshape(n_groups, group_size, width).mean(axis=1)
        power = train_power if i < n_train + n_calib else val_power
        xa = qmc_inputs(width, power, seed + 1_000_000 + i * 37)
        arrays['targets_a'][i] = forward_means(W, xa)
        if i < n_train + n_calib:
            arrays['targets_b'][i] = arrays['targets_a'][i]
        else:
            xb = qmc_inputs(width, power, seed + 2_000_000 + i * 41)
            arrays['targets_b'][i] = forward_means(W, xb)
        if (i + 1) % 20 == 0 or i + 1 == total:
            # Avoid msync-ing the entire large sparse memmap at each checkpoint.
            print(f'data {i+1}/{total} elapsed={time.time()-t0:.1f}s', flush=True)

    meta = dict(n_train=n_train, n_calib=n_calib, n_val=n_val, width=width, depth=depth,
                train_power=train_power, val_power=val_power, seed=seed, n_particles=n_particles,
                n_groups=n_groups, mrad=float(mrad), runtime=time.time() - t0, complete=(end_i >= total))
    meta_path.write_text(json.dumps(meta, indent=2))


def exact_mean_translation(A: np.ndarray, target: np.ndarray) -> np.ndarray:
    A = np.asarray(A, dtype=np.float32)
    target = np.maximum(np.asarray(target, dtype=np.float64), 0.0)
    current = A.mean(axis=0, dtype=np.float64)
    shifts = target - current
    down = np.flatnonzero(shifts < 0)
    if len(down):
        n = A.shape[0]
        for j in down:
            v = np.sort(A[:, j].astype(np.float64))[::-1]
            if target[j] <= 0:
                shifts[j] = -float(v[0])
                continue
            c = np.cumsum(v)
            k = np.arange(1, n + 1, dtype=np.float64)
            s = (c - n * target[j]) / k
            nxt = np.empty_like(v)
            nxt[:-1] = v[1:]
            nxt[-1] = -np.inf
            valid = (s <= v + 1e-12) & (s >= nxt - 1e-12) & (s >= -1e-12)
            idx = np.flatnonzero(valid)
            if len(idx):
                shifts[j] = -float(s[idx[0]])
            else:
                lo, hi = 0.0, float(v[0])
                for _ in range(45):
                    mid = 0.5 * (lo + hi)
                    val = float(np.maximum(A[:, j].astype(np.float64) - mid, 0.0).mean())
                    if val > target[j]:
                        lo = mid
                    else:
                        hi = mid
                shifts[j] = -0.5 * (lo + hi)
    out = A + shifts.astype(np.float32)[None, :]
    np.maximum(out, 0, out=out)
    return out


class ForwardEqNet(nn.Module):
    """Fair target-redesign control: close to the earlier one-way architecture."""
    def __init__(self, depth: int, hidden: int = 32, emb: int = 8, mlp: int = 96):
        super().__init__()
        self.depth = depth
        self.hidden = hidden
        self.h0 = nn.Parameter(torch.zeros(hidden))
        self.le = nn.Embedding(depth, emb)
        din = 4 * hidden + 5 + 4 + emb
        self.up = nn.Sequential(nn.Linear(din, mlp), nn.SiLU(), nn.Linear(mlp, hidden), nn.SiLU(),
                                nn.Linear(hidden, hidden), nn.LayerNorm(hidden))
        self.head31 = nn.Sequential(nn.Linear(hidden + 4, 64), nn.SiLU(), nn.Linear(64, 1))
        self.head32 = nn.Sequential(nn.Linear(hidden + 4, 64), nn.SiLU(), nn.Linear(64, 1))

    def forward(self, W: torch.Tensor, stats: torch.Tensor, basis31: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        del basis31
        B, L, n, _ = W.shape
        h = self.h0[None, None, :].expand(B, n, -1)
        out31 = None
        sq = math.sqrt(n)
        for l in range(L):
            A = W[:, l]
            U = A * math.sqrt(n / 2.0)
            u2 = U * U - 1.0
            ua = U.abs() - math.sqrt(2.0 / math.pi)
            a1 = torch.bmm(U, h) / sq
            a2 = torch.bmm(u2, h) / sq
            aa = torch.bmm(ua, h) / sq
            glob = h.mean(1, keepdim=True).expand(-1, n, -1)
            rs = torch.stack([U.mean(-1), U.std(-1), (U ** 3).mean(-1),
                              (U ** 4).mean(-1) - 3.0, A.sum(-1)], dim=-1)
            e = self.le.weight[l][None, None, :].expand(B, n, -1)
            h = self.up(torch.cat([a1, a2, aa, glob, rs, stats[:, l], e], dim=-1))
            if l == L - 2:
                out31 = self.head31(torch.cat([h, stats[:, l]], dim=-1)).squeeze(-1)
        out32 = self.head32(torch.cat([h, stats[:, -1]], dim=-1)).squeeze(-1)
        assert out31 is not None
        return out31, out32


class BiEqNet(nn.Module):
    """Bidirectional permutation-equivariant weight-space network.

    Hidden-neuron permutations act by permuting the node axis at each layer. All
    edge contractions and set summaries commute with those permutations.
    """
    def __init__(self, depth: int, hidden: int = 48, emb: int = 12, mlp: int = 128, basis_hidden: int = 24):
        super().__init__()
        self.depth = depth
        self.hidden = hidden
        self.f0 = nn.Parameter(torch.zeros(hidden))
        self.b0 = nn.Parameter(torch.zeros(hidden))
        self.le = nn.Embedding(depth, emb)
        din = 5 * hidden + 10 + 4 + emb
        self.fup = nn.Sequential(nn.Linear(din, mlp), nn.SiLU(), nn.Linear(mlp, mlp), nn.SiLU(),
                                 nn.Linear(mlp, hidden), nn.LayerNorm(hidden))
        self.bup = nn.Sequential(nn.Linear(din, mlp), nn.SiLU(), nn.Linear(mlp, mlp), nn.SiLU(),
                                 nn.Linear(mlp, hidden), nn.LayerNorm(hidden))
        self.basis_phi = nn.Sequential(nn.Linear(2, basis_hidden), nn.SiLU(),
                                       nn.Linear(basis_hidden, basis_hidden), nn.SiLU())
        head_in = 2 * hidden + 4 + 2 * basis_hidden + 10
        self.head31 = nn.Sequential(nn.Linear(head_in, 128), nn.SiLU(), nn.Linear(128, 64), nn.SiLU(), nn.Linear(64, 1))
        self.head32 = nn.Sequential(nn.Linear(hidden + 4 + 10, 128), nn.SiLU(), nn.Linear(128, 1))

    @staticmethod
    def edge_local(A: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        n = A.shape[-1]
        U = A * math.sqrt(n / 2.0)
        row = torch.stack([U.mean(-1), U.std(-1), (U ** 3).mean(-1),
                           (U ** 4).mean(-1) - 3.0, A.sum(-1)], dim=-1)
        col = torch.stack([U.mean(-2), U.std(-2), (U ** 3).mean(-2),
                           (U ** 4).mean(-2) - 3.0, A.sum(-2)], dim=-1)
        return U, row, col

    def contract(self, U: torch.Tensor, h: torch.Tensor, transpose: bool = False) -> Tuple[torch.Tensor, ...]:
        if transpose:
            U = U.transpose(1, 2)
        sq = math.sqrt(U.shape[-1])
        u2 = U * U - 1.0
        ua = U.abs() - math.sqrt(2.0 / math.pi)
        us = torch.sign(U) * torch.sqrt(U.abs() + 1e-5)
        return (torch.bmm(U, h) / sq, torch.bmm(u2, h) / sq,
                torch.bmm(ua, h) / sq, torch.bmm(us, h) / sq)

    def forward(self, W: torch.Tensor, stats: torch.Tensor, basis31: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        B, L, n, _ = W.shape
        edge = [self.edge_local(W[:, l]) for l in range(L)]
        f = self.f0[None, None, :].expand(B, n, -1)
        fstates = []
        for l in range(L):
            U, row, col = edge[l]
            msgs = self.contract(U, f, False)
            glob = f.mean(1, keepdim=True).expand(-1, n, -1)
            e = self.le.weight[l][None, None, :].expand(B, n, -1)
            # Row describes target neuron; column aggregate gives source-side context.
            colg = col.mean(1, keepdim=True).expand(-1, n, -1)
            f = self.fup(torch.cat([*msgs, glob, row, colg, stats[:, l], e], dim=-1))
            fstates.append(f)

        b = self.b0[None, None, :].expand(B, n, -1)
        bstates = [None] * L
        for l in range(L - 1, -1, -1):
            U, row, col = edge[l]
            msgs = self.contract(U, b, True)
            glob = b.mean(1, keepdim=True).expand(-1, n, -1)
            e = self.le.weight[l][None, None, :].expand(B, n, -1)
            rowg = row.mean(1, keepdim=True).expand(-1, n, -1)
            # Transpose maps target-layer state to source neurons; columns are local.
            b = self.bup(torch.cat([*msgs, glob, col, rowg, stats[:, l], e], dim=-1))
            bstates[l] = b

        # Invariant DeepSets summary over the 17 complete antipodal basis blocks.
        mu = basis31.mean(1, keepdim=True)
        sd = basis31.std(1, keepdim=True).clamp_min(1e-6)
        z = (basis31 - mu) / sd
        tok = torch.stack([z, z.abs()], dim=-1)  # B,G,n,2
        phi = self.basis_phi(tok)
        bmean = phi.mean(1)
        bmax = phi.max(1).values

        l31 = L - 2
        U31, row31, col31 = edge[l31]
        local31 = torch.cat([row31, col31], dim=-1)
        x31 = torch.cat([fstates[l31], bstates[l31 + 1], stats[:, l31], bmean, bmax, local31], dim=-1)
        out31 = self.head31(x31).squeeze(-1)

        U32, row32, col32 = edge[-1]
        local32 = torch.cat([row32, col32], dim=-1)
        x32 = torch.cat([fstates[-1], stats[:, -1], local32], dim=-1)
        out32 = self.head32(x32).squeeze(-1)
        return out31, out32


def load_data(path: Path) -> Dict[str, torch.Tensor | np.ndarray | dict]:
    meta = json.loads((path / 'meta.json').read_text())
    data: Dict[str, torch.Tensor | np.ndarray | dict] = {'meta': meta}
    for name in ['weights', 'targets_a', 'targets_b', 'kstats', 'basis31', 'particles31']:
        data[name] = np.load(path / f'{name}.npy', mmap_mode='r')
    return data


def replay_final(W: np.ndarray, particles31: np.ndarray, target31: np.ndarray) -> np.ndarray:
    A = exact_mean_translation(particles31, target31)
    out = A @ W[-1].T
    np.maximum(out, 0, out=out)
    return out.mean(axis=0, dtype=np.float64)


def eval_replay(W: np.ndarray, particles: np.ndarray, kmean: np.ndarray, target: np.ndarray,
                pred31: np.ndarray, alpha: float) -> Dict[str, np.ndarray | float]:
    n = len(W)
    base = np.empty(n)
    corr = np.empty(n)
    oracle = np.empty(n)
    pred_vec = np.empty((n, W.shape[-1]), dtype=np.float64)
    oracle_vec = np.empty_like(pred_vec)
    for i in range(n):
        base_pred = kmean[i, -1]
        p = replay_final(W[i], particles[i], kmean[i, -2] + alpha * pred31[i])
        o = replay_final(W[i], particles[i], target[i, -2])
        pred_vec[i] = p
        oracle_vec[i] = o
        base[i] = np.mean((base_pred - target[i, -1]) ** 2)
        corr[i] = np.mean((p - target[i, -1]) ** 2)
        oracle[i] = np.mean((o - target[i, -1]) ** 2)
    return dict(base=base, corr=corr, oracle=oracle, base_mean=float(base.mean()), corr_mean=float(corr.mean()),
                oracle_mean=float(oracle.mean()), gain=float(base.mean() / corr.mean()),
                oracle_gain=float(base.mean() / oracle.mean()), wins=int(np.sum(corr < base)),
                pred_vec=pred_vec, oracle_vec=oracle_vec)


def bootstrap_ratio(base: np.ndarray, cand: np.ndarray, seed: int = 55, reps: int = 10000) -> Tuple[float, list[float]]:
    rng = np.random.default_rng(seed)
    n = len(base)
    vals = np.empty(reps)
    for r in range(reps):
        idx = rng.integers(0, n, n)
        vals[r] = base[idx].mean() / max(cand[idx].mean(), 1e-30)
    return float(base.mean() / cand.mean()), [float(x) for x in np.quantile(vals, [0.025, 0.975])]


def train_model(name: str, model: nn.Module, data: Dict, device: str, epochs: int, batch: int,
                lr: float, out_dir: Path) -> Dict:
    meta = data['meta']
    nt, nc = meta['n_train'], meta['n_calib']
    Wn = data['weights']; Yn = (np.asarray(data['targets_a']) + np.asarray(data['targets_b'])) * 0.5
    Sn = data['kstats']; Bn = data['basis31']
    Kmean = np.asarray(Sn)[..., 0]
    d31 = Yn[:, -2] - Kmean[:, -2]
    d32 = Yn[:, -1] - Kmean[:, -1]
    s31 = float(np.std(d31[:nt])); s32 = float(np.std(d32[:nt]))
    s31 = max(s31, 1e-7); s32 = max(s32, 1e-7)

    train_ds = TensorDataset(torch.from_numpy(np.asarray(Wn[:nt])), torch.from_numpy(np.asarray(Sn[:nt])),
                             torch.from_numpy(np.asarray(Bn[:nt])), torch.from_numpy((d31[:nt] / s31).astype(np.float32)),
                             torch.from_numpy((d32[:nt] / s32).astype(np.float32)))
    loader = DataLoader(train_ds, batch_size=batch, shuffle=True, drop_last=False)
    model.to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=2e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    best = float('inf'); best_state = None; history = []
    wc = torch.from_numpy(np.asarray(Wn[nt:nt + nc])).to(device)
    sc = torch.from_numpy(np.asarray(Sn[nt:nt + nc])).to(device)
    bc = torch.from_numpy(np.asarray(Bn[nt:nt + nc])).to(device)
    y31c = torch.from_numpy((d31[nt:nt + nc] / s31).astype(np.float32)).to(device)
    y32c = torch.from_numpy((d32[nt:nt + nc] / s32).astype(np.float32)).to(device)
    t0 = time.time()
    for ep in range(epochs):
        model.train(); losses = []
        for wb, sb, bb, y31, y32 in loader:
            wb, sb, bb, y31, y32 = wb.to(device), sb.to(device), bb.to(device), y31.to(device), y32.to(device)
            opt.zero_grad(set_to_none=True)
            p31, p32 = model(wb, sb, bb)
            loss31 = ((p31 - y31) ** 2).mean()
            loss32 = ((p32 - y32) ** 2).mean()
            loss = loss31 + 0.15 * loss32
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 2.0)
            opt.step(); losses.append(float(loss.detach().cpu()))
        sched.step()
        model.eval()
        with torch.no_grad():
            p31c, p32c = model(wc, sc, bc)
            cal31 = float(((p31c - y31c) ** 2).mean().cpu())
            cal32 = float(((p32c - y32c) ** 2).mean().cpu())
        rec = dict(epoch=ep + 1, train=float(np.mean(losses)), cal31=cal31, cal32=cal32)
        history.append(rec)
        if cal31 < best:
            best = cal31
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        if (ep + 1) % 5 == 0 or ep == 0:
            print(name, rec, flush=True)
    assert best_state is not None
    model.load_state_dict(best_state)
    torch.save(dict(model=best_state, s31=s31, s32=s32, meta=meta), out_dir / f'{name}.pt')

    # Predict calibration and untouched validation.
    model.eval()
    preds = {}
    for split, sl in [('calib', slice(nt, nt + nc)), ('val', slice(nt + nc, None))]:
        with torch.no_grad():
            ww = torch.from_numpy(np.asarray(Wn[sl])).to(device)
            ss = torch.from_numpy(np.asarray(Sn[sl])).to(device)
            bb = torch.from_numpy(np.asarray(Bn[sl])).to(device)
            p31, p32 = model(ww, ss, bb)
        preds[split] = dict(p31=p31.cpu().numpy() * s31, p32=p32.cpu().numpy() * s32)

    # Freeze translation shrinkage on calibration only. At larger widths, avoid
    # replaying the expensive exact translation for every grid value: the
    # least-squares shrinkage on the penultimate defect is the stable proxy.
    cal_sl = slice(nt, nt + nc)
    if meta['width'] >= 64 or os.environ.get('FAST_REPLAY') == '1':
        pc = preds['calib']['p31'].astype(np.float64)
        yc = d31[cal_sl].astype(np.float64)
        alpha = float(np.clip(np.sum(pc * yc) / max(np.sum(pc * pc), 1e-30), -0.25, 1.5))
        cal_rows = [(alpha, float(np.mean((yc - alpha * pc) ** 2)))]
    else:
        alpha_grid = np.linspace(-0.25, 1.5, 36)
        cal_rows = []
        for alpha0 in alpha_grid:
            ev0 = eval_replay(np.asarray(Wn[cal_sl]), np.asarray(data['particles31'][cal_sl]), Kmean[cal_sl], Yn[cal_sl],
                              preds['calib']['p31'], float(alpha0))
            cal_rows.append((float(alpha0), ev0['corr_mean']))
        alpha = min(cal_rows, key=lambda x: x[1])[0]

    val_sl = slice(nt + nc, None)
    ev = eval_replay(np.asarray(Wn[val_sl]), np.asarray(data['particles31'][val_sl]), Kmean[val_sl], Yn[val_sl],
                     preds['val']['p31'], alpha)
    ratio, ci = bootstrap_ratio(ev['base'], ev['corr'])
    # Layer-31 direct defect gain and final direct-head gain.
    true31 = d31[val_sl]
    true32 = d32[val_sl]
    p31 = preds['val']['p31']; p32 = preds['val']['p32']
    l31_gain = float(np.mean(true31 ** 2) / np.mean((true31 - p31) ** 2))
    direct32_gain = float(np.mean(true32 ** 2) / np.mean((true32 - p32) ** 2))
    pred_corr = float(np.corrcoef(true31.ravel(), p31.ravel())[0, 1])
    result = dict(name=name, params=sum(p.numel() for p in model.parameters()), best_cal31=best,
                  s31=s31, s32=s32, alpha=alpha, alpha_grid=cal_rows, layer31_gain=l31_gain,
                  layer31_corr=pred_corr, direct_final_gain=direct32_gain,
                  replay_gain=ratio, replay_ci95=ci, replay_wins=ev['wins'], n_val=len(ev['base']),
                  baseline_mse=ev['base_mean'], corrected_mse=ev['corr_mean'], oracle_mse=ev['oracle_mean'],
                  oracle_gain=ev['oracle_gain'], worst_ratio=float(np.max(ev['corr'] / ev['base'])),
                  median_ratio=float(np.median(ev['corr'] / ev['base'])), history=history,
                  runtime=time.time() - t0)
    (out_dir / f'{name}_result.json').write_text(json.dumps(result, indent=2))
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, default=Path('/mnt/data/arc_weight_model/bieq_run'))
    ap.add_argument('--train', type=int, default=224)
    ap.add_argument('--calib', type=int, default=32)
    ap.add_argument('--val', type=int, default=64)
    ap.add_argument('--width', type=int, default=32)
    ap.add_argument('--depth', type=int, default=32)
    ap.add_argument('--train-power', type=int, default=13)
    ap.add_argument('--val-power', type=int, default=14)
    ap.add_argument('--epochs', type=int, default=30)
    ap.add_argument('--batch', type=int, default=32)
    ap.add_argument('--seed', type=int, default=20420000)
    ap.add_argument('--generate-only', action='store_true')
    ap.add_argument('--train-only', action='store_true')
    ap.add_argument('--model', choices=['both','forward','bidirectional'], default='both')
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(7); np.random.seed(7); torch.set_num_threads(5)
    if not args.train_only:
        generate_dataset(args.out / 'data', args.train, args.calib, args.val, args.width, args.depth,
                         args.train_power, args.val_power, args.seed)
    if args.generate_only:
        sys.stdout.flush(); sys.stderr.flush()
        os._exit(0)
    data = load_data(args.out / 'data')
    device = 'cpu'
    results = []
    if args.model in ('both','forward'):
        results.append(train_model('forward_target31', ForwardEqNet(args.depth), data, device, args.epochs,
                                   args.batch, 2e-3, args.out))
    if args.model in ('both','bidirectional'):
        results.append(train_model('bidirectional_target31', BiEqNet(args.depth), data, device, args.epochs,
                                   args.batch, 1.5e-3, args.out))
    summary = dict(args=vars(args) | {'out': str(args.out)}, results=results)
    (args.out / 'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
