import sys,json,time
from pathlib import Path
import numpy as np
from lightgbm import LGBMRegressor
sys.path.insert(0,'/mnt/data/arc_weight_model')
from bieq_layer31_experiment import load_data,eval_replay,bootstrap_ratio
root=Path('/mnt/data/arc_weight_model/bieq_w32_big');D=load_data(root/'data');m=D['meta'];nt,nc,nv=m['n_train'],m['n_calib'],m['n_val'];n=m['width'];G=m['n_groups'];gs=2*n
W=np.asarray(D['weights']);T=(np.asarray(D['targets_a'])+np.asarray(D['targets_b']))*.5;S=np.asarray(D['kstats']);K=S[...,0];P=np.asarray(D['particles31']);Y=T[:,-2]-K[:,-2]
def feats(ordered):
 out=np.empty((nt+nc+nv,n,G*5+8+4+256),np.float32)
 for i in range(len(out)):
  a=P[i].reshape(G,gs,n).astype(np.float64);mu=a.mean(1).T;sd=a.std(1).T;zero=(a<=0).mean(1).T;mx=a.max(1).T;pair=np.abs(a[:,:n]-a[:,n:]).mean(1).T
  if not ordered:
   ix=np.argsort(mu,1);mu,sd,zero,mx,pair=[np.take_along_axis(z,ix,1) for z in [mu,sd,zero,mx,pair]]
  C=W[i,-1].T.astype(np.float64);col=np.stack([C.mean(1),C.std(1),np.abs(C).mean(1),(C*C).mean(1),np.maximum(C,0).sum(1),np.minimum(C,0).sum(1),C.max(1),C.min(1)],1)
  gl=np.concatenate([S[i].mean(1).reshape(-1),S[i].std(1).reshape(-1)]);out[i]=np.concatenate([mu,sd,zero,mx,pair,col,S[i,-2],np.repeat(gl[None,:],n,0)],1)
 return out
def run(tag,X,leaves):
 t=time.time();mod=LGBMRegressor(n_estimators=1200,learning_rate=.02,num_leaves=leaves,min_child_samples=80,subsample=.85,colsample_bytree=.75,reg_lambda=4,reg_alpha=.2,random_state=100+leaves,n_jobs=4,verbosity=-1)
 mod.fit(X[:nt].reshape(-1,X.shape[-1]),Y[:nt].reshape(-1));pc=mod.predict(X[nt:nt+nc].reshape(-1,X.shape[-1])).reshape(nc,n);pv=mod.predict(X[nt+nc:].reshape(-1,X.shape[-1])).reshape(nv,n)
 yc=Y[nt:nt+nc];alpha=float(np.clip(np.sum(pc*yc)/max(np.sum(pc*pc),1e-30),-.25,1.5));sl=slice(nt+nc,nt+nc+nv);ev=eval_replay(W[sl],P[sl],K[sl],T[sl],pv,alpha);ratio,ci=bootstrap_ratio(ev['base'],ev['corr'],seed=917)
 y=Y[sl];r=dict(name=tag,alpha=alpha,layer31_gain=float(np.mean(y*y)/np.mean((y-pv)**2)),corr=float(np.corrcoef(y.ravel(),pv.ravel())[0,1]),replay_gain=ratio,replay_ci95=ci,wins=ev['wins'],baseline_mse=ev['base_mean'],corrected_mse=ev['corr_mean'],worst_ratio=float(np.max(ev['corr']/ev['base'])),median_ratio=float(np.median(ev['corr']/ev['base'])),runtime=time.time()-t);print(json.dumps(r),flush=True);return r

import argparse
ap=argparse.ArgumentParser();ap.add_argument('--ordered',action='store_true');ap.add_argument('--leaves',type=int,default=31);a=ap.parse_args()
X=feats(a.ordered);r=run(('ordered' if a.ordered else 'sorted')+f'_l{a.leaves}',X,a.leaves)
outp=root/f"basis_probe_big_{r['name']}.json";outp.write_text(json.dumps({'meta':m,'result':r},indent=2))
