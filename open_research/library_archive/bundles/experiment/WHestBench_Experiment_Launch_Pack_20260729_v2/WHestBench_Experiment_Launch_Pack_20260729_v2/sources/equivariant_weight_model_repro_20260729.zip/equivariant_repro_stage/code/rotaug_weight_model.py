#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,os,sys,time
from pathlib import Path
import numpy as np, torch
from scipy.special import gamma
sys.path.insert(0,'/mnt/data/arc_weight_model')
from bieq_layer31_experiment import load_data,ForwardEqNet,BiEqNet,eval_replay,bootstrap_ratio
sys.path.insert(0,'/mnt/data/arc_weight_model/weightspace_v3/v3_bundle')
from kerdock_error_probe import design
ROOT=Path('/mnt/data/arc_weight_model/bieq_w32_big');OUT=ROOT/'rotaug_model';OUT.mkdir(exist_ok=True);D=load_data(ROOT/'data');m=D['meta'];BASE=512;R=4;N=BASE*R;n=32;L=32;G=17;gs=64
W0=np.asarray(D['weights']);T=(np.asarray(D['targets_a'])+np.asarray(D['targets_b']))*.5;S0=np.asarray(D['kstats']);K0=S0[...,0];P0=np.asarray(D['particles31']);X=design(n).astype(np.float32);X*=np.float32(math.sqrt(2)*gamma((n+1)/2)/(math.sqrt(n)*gamma(n/2)))
def generate(limit):
 wa=np.lib.format.open_memmap(OUT/'weights.npy',mode='r+' if (OUT/'weights.npy').exists() else 'w+',dtype=np.float32,shape=(N,L,n,n));sa=np.lib.format.open_memmap(OUT/'stats.npy',mode='r+' if (OUT/'stats.npy').exists() else 'w+',dtype=np.float32,shape=(N,L,n,4));ba=np.lib.format.open_memmap(OUT/'basis.npy',mode='r+' if (OUT/'basis.npy').exists() else 'w+',dtype=np.float32,shape=(N,G,n));ya=np.lib.format.open_memmap(OUT/'target31.npy',mode='r+' if (OUT/'target31.npy').exists() else 'w+',dtype=np.float32,shape=(N,n))
 done=np.any(np.asarray(sa).reshape(N,-1)!=0,1);start=int(np.flatnonzero(~done)[0]) if np.any(~done) else N;end=min(N,start+limit);tt=time.time()
 for ex in range(start,end):
  i=ex//R;r=ex%R;rng=np.random.default_rng(51000000+i*101+r);q,_=np.linalg.qr(rng.normal(size=(n,n)));q=q.astype(np.float32);W=W0[i].copy();W[0]=W[0]@q.T;wa[ex]=W;h=X.copy();Sl=np.zeros((L,n,4),np.float32)
  for li,A in enumerate(W):
   h=h@A.T;np.maximum(h,0,out=h);x=h.astype(np.float64,copy=False);mu=x.mean(0);c=x-mu;sd=np.sqrt(np.maximum(np.mean(c*c,0),1e-12));Sl[li,:,0]=mu;Sl[li,:,1]=sd
   if li>=L-2:
    z=c/sd;Sl[li,:,2]=np.mean(z**3,0);Sl[li,:,3]=np.mean(z**4,0)-3
   if li==L-2:ba[ex]=h.reshape(G,gs,n).mean(1)
  sa[ex]=Sl;ya[ex]=T[i,-2]-Sl[-2,:,0]
  if (ex+1)%128==0:print('gen',ex+1,N,'elapsed',time.time()-tt,flush=True)
 (OUT/'progress.json').write_text(json.dumps({'done':end,'total':N}));sys.stdout.flush();os._exit(0)

def train(kind,epochs,batch):
 # Load augmented inputs in RAM to avoid random memmap I/O.
 W=torch.from_numpy(np.array(np.load(OUT/'weights.npy',mmap_mode='r'),copy=True));S=torch.from_numpy(np.array(np.load(OUT/'stats.npy',mmap_mode='r'),copy=True));B=torch.from_numpy(np.array(np.load(OUT/'basis.npy',mmap_mode='r'),copy=True));Y=np.array(np.load(OUT/'target31.npy',mmap_mode='r'),copy=True);scale=max(float(Y.std()),1e-7);Yt=torch.from_numpy((Y/scale).astype(np.float32))
 if kind=='forward':model=ForwardEqNet(L)
 else:model=BiEqNet(L,hidden=16,emb=4,mlp=32,basis_hidden=8)
 torch.manual_seed(37);torch.set_num_threads(4);opt=torch.optim.AdamW(model.parameters(),lr=1.5e-3,weight_decay=2e-4);rng=np.random.default_rng(37)
 # Frozen identity calibration.
 nt=m['n_train'];nc=m['n_calib'];ci=np.arange(nt,nt+nc);Wc=torch.from_numpy(np.array(W0[ci],copy=True));Sc=torch.from_numpy(np.array(S0[ci],copy=True));Bc=torch.from_numpy(np.array(D['basis31'][ci],copy=True));Yc=(T[ci,-2]-K0[ci,-2])/scale;best=1e99;state=None;hist=[]
 for ep in range(epochs):
  model.train();perm=rng.permutation(N);ls=[]
  for st in range(0,N,batch):
   ix=torch.from_numpy(perm[st:st+batch]);opt.zero_grad(set_to_none=True);p,_=model(W[ix],S[ix],B[ix]);loss=((p-Yt[ix])**2).mean();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),2);opt.step();ls.append(float(loss))
  model.eval();
  with torch.no_grad():pc,_=model(Wc,Sc,Bc);cal=float(np.mean((pc.numpy()-Yc)**2))
  hist.append({'epoch':ep+1,'train':float(np.mean(ls)),'cal':cal});print(kind,hist[-1],flush=True)
  if cal<best:best=cal;state={k:v.detach().clone() for k,v in model.state_dict().items()}
 model.load_state_dict(state);torch.save({'model':state,'scale':scale,'history':hist},OUT/f'{kind}.pt')
 # Identity validation only once.
 vi=np.arange(nt+nc,nt+nc+m['n_val']);Wv=torch.from_numpy(np.array(W0[vi],copy=True));Sv=torch.from_numpy(np.array(S0[vi],copy=True));Bv=torch.from_numpy(np.array(D['basis31'][vi],copy=True));model.eval()
 with torch.no_grad():pc,_=model(Wc,Sc,Bc);pv,_=model(Wv,Sv,Bv)
 pc=pc.numpy()*scale;pv=pv.numpy()*scale;yc=T[ci,-2]-K0[ci,-2];yv=T[vi,-2]-K0[vi,-2];alpha=float(np.clip(np.sum(pc*yc)/max(np.sum(pc*pc),1e-30),-1,1.5));ev=eval_replay(W0[vi],np.asarray(D['particles31'][vi]),K0[vi],T[vi],pv,alpha);ratio,ci95=bootstrap_ratio(ev['base'],ev['corr'],seed=1771)
 r=dict(kind=kind,train_base_networks=BASE,rotations=R,train_examples=N,params=sum(p.numel() for p in model.parameters()),best_cal=best,alpha=alpha,effective_corr=float(np.corrcoef(yv.ravel(),(alpha*pv).ravel())[0,1]),effective_layer31_gain=float(np.mean(yv*yv)/np.mean((yv-alpha*pv)**2)),replay_gain=ratio,replay_ci95=ci95,wins=ev['wins'],baseline_mse=ev['base_mean'],corrected_mse=ev['corr_mean'],worst_ratio=float(np.max(ev['corr']/ev['base'])),median_ratio=float(np.median(ev['corr']/ev['base'])),history=hist);(OUT/f'{kind}_result.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
ap=argparse.ArgumentParser();ap.add_argument('--generate',action='store_true');ap.add_argument('--limit',type=int,default=512);ap.add_argument('--kind',choices=['forward','bidirectional'],default='forward');ap.add_argument('--epochs',type=int,default=8);ap.add_argument('--batch',type=int,default=128);a=ap.parse_args();generate(a.limit) if a.generate else train(a.kind,a.epochs,a.batch)
