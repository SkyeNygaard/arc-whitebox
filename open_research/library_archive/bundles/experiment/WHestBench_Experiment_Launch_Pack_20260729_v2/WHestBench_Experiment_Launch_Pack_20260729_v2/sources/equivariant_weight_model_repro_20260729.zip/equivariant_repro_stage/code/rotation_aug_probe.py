#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,os,sys,time
from pathlib import Path
import numpy as np
from lightgbm import LGBMRegressor
sys.path.insert(0,'/mnt/data/arc_weight_model')
from bieq_layer31_experiment import load_data,eval_replay,bootstrap_ratio
sys.path.insert(0,'/mnt/data/arc_weight_model/weightspace_v3/v3_bundle')
from kerdock_error_probe import design
from scipy.special import gamma
ROOT=Path('/mnt/data/arc_weight_model/bieq_w32_big'); CACHE=ROOT/'rotaug';CACHE.mkdir(exist_ok=True)
D=load_data(ROOT/'data');m=D['meta'];nt0=512;nc=m['n_calib'];nv=m['n_val'];n=32;L=32;G=17;gs=64;R=4;F=353
W=np.asarray(D['weights']);T=(np.asarray(D['targets_a'])+np.asarray(D['targets_b']))*.5;S=np.asarray(D['kstats']);K=S[...,0];P=np.asarray(D['particles31'])
X=design(n).astype(np.float32);X*=np.float32(math.sqrt(2)*gamma((n+1)/2)/(math.sqrt(n)*gamma(n/2)))

def feature_from_particles(Wi,h31,Sl,ordered):
 a=h31.reshape(G,gs,n).astype(np.float64);mu=a.mean(1).T;sd=a.std(1).T;zero=(a<=0).mean(1).T;mx=a.max(1).T;pair=np.abs(a[:,:n]-a[:,n:]).mean(1).T
 if not ordered:
  ix=np.argsort(mu,1);mu,sd,zero,mx,pair=[np.take_along_axis(z,ix,1) for z in [mu,sd,zero,mx,pair]]
 C=Wi[-1].T.astype(np.float64);col=np.stack([C.mean(1),C.std(1),np.abs(C).mean(1),(C*C).mean(1),np.maximum(C,0).sum(1),np.minimum(C,0).sum(1),C.max(1),C.min(1)],1)
 gl=np.concatenate([Sl.mean(1).reshape(-1),Sl.std(1).reshape(-1)])
 return np.concatenate([mu,sd,zero,mx,pair,col,Sl[-2],np.repeat(gl[None,:],n,0)],1).astype(np.float32)

def identity_features(indices,ordered):
 out=[]
 for i in indices:
  out.append(feature_from_particles(W[i],P[i],S[i],ordered))
 return np.stack(out)

def generate(start,limit):
 total=nt0*R; fo=np.lib.format.open_memmap(CACHE/'ordered.npy',mode='r+' if (CACHE/'ordered.npy').exists() else 'w+',dtype=np.float32,shape=(total,n,F));fs=np.lib.format.open_memmap(CACHE/'sorted.npy',mode='r+' if (CACHE/'sorted.npy').exists() else 'w+',dtype=np.float32,shape=(total,n,F));yy=np.lib.format.open_memmap(CACHE/'target.npy',mode='r+' if (CACHE/'target.npy').exists() else 'w+',dtype=np.float32,shape=(total,n))
 done=np.any(np.asarray(fo).reshape(total,-1)!=0,1); s=int(np.flatnonzero(~done)[0]) if np.any(~done) else total
 end=min(total,s+limit);t=time.time()
 for ex in range(s,end):
  i=ex//R;r=ex%R;rng=np.random.default_rng(51000000+i*101+r);q,_=np.linalg.qr(rng.normal(size=(n,n)));q=q.astype(np.float32)
  Wr=W[i].copy();Wr[0]=Wr[0]@q.T
  h=X.copy();Sl=np.zeros((L,n,4),np.float32)
  for li,A in enumerate(Wr):
   h=h@A.T;np.maximum(h,0,out=h);x=h.astype(np.float64,copy=False);mu=x.mean(0);c=x-mu;sd=np.sqrt(np.maximum(np.mean(c*c,0),1e-12));Sl[li,:,0]=mu;Sl[li,:,1]=sd
   if li>=L-2:
    z=c/sd;Sl[li,:,2]=np.mean(z**3,0);Sl[li,:,3]=np.mean(z**4,0)-3
   if li==L-2:h31=h.copy()
  fo[ex]=feature_from_particles(Wr,h31,Sl,True);fs[ex]=feature_from_particles(Wr,h31,Sl,False);yy[ex]=T[i,-2]-Sl[-2,:,0]
  if (ex+1)%64==0:print('aug',ex+1,'/',total,'elapsed',time.time()-t,flush=True)
 (CACHE/'progress.json').write_text(json.dumps({'done':end,'total':total}))
 sys.stdout.flush();os._exit(0)

def fit(ordered,augmented,leaves):
 train_idx=np.arange(nt0);Xid=identity_features(train_idx,ordered);yid=T[train_idx,-2]-K[train_idx,-2]
 if augmented:
  Xa=np.load(CACHE/('ordered.npy' if ordered else 'sorted.npy'),mmap_mode='r');ya=np.load(CACHE/'target.npy',mmap_mode='r');Xtr=np.asarray(Xa);ytr=np.asarray(ya)
 else:Xtr=Xid;ytr=yid
 calidx=np.arange(m['n_train'],m['n_train']+nc);validx=np.arange(m['n_train']+nc,m['n_train']+nc+nv);Xc=identity_features(calidx,ordered);Xv=identity_features(validx,ordered);yc=T[calidx,-2]-K[calidx,-2];yv=T[validx,-2]-K[validx,-2]
 model=LGBMRegressor(n_estimators=600,learning_rate=.025,num_leaves=leaves,min_child_samples=100,subsample=.85,colsample_bytree=.7,reg_lambda=4,reg_alpha=.2,random_state=731+leaves,n_jobs=4,verbosity=-1)
 t=time.time();model.fit(Xtr.reshape(-1,F),ytr.reshape(-1));pc=model.predict(Xc.reshape(-1,F)).reshape(nc,n);pv=model.predict(Xv.reshape(-1,F)).reshape(nv,n);alpha=float(np.clip(np.sum(pc*yc)/max(np.sum(pc*pc),1e-30),-1.0,1.5));ev=eval_replay(W[validx],P[validx],K[validx],T[validx],pv,alpha);ratio,ci=bootstrap_ratio(ev['base'],ev['corr'],seed=1131)
 r=dict(ordered=ordered,augmented=augmented,leaves=leaves,train_base_networks=nt0,train_examples=int(len(Xtr)),alpha=alpha,effective_corr=float(np.corrcoef(yv.ravel(),(alpha*pv).ravel())[0,1]),effective_layer31_gain=float(np.mean(yv*yv)/np.mean((yv-alpha*pv)**2)),replay_gain=ratio,replay_ci95=ci,wins=ev['wins'],baseline_mse=ev['base_mean'],corrected_mse=ev['corr_mean'],worst_ratio=float(np.max(ev['corr']/ev['base'])),median_ratio=float(np.median(ev['corr']/ev['base'])),runtime=time.time()-t);print(json.dumps(r,indent=2));(ROOT/f"rotaug_{'aug' if augmented else 'identity'}_{'ord' if ordered else 'sort'}_l{leaves}.json").write_text(json.dumps(r,indent=2))

ap=argparse.ArgumentParser();ap.add_argument('--generate',action='store_true');ap.add_argument('--limit',type=int,default=256);ap.add_argument('--ordered',action='store_true');ap.add_argument('--augmented',action='store_true');ap.add_argument('--leaves',type=int,default=31);a=ap.parse_args()
if a.generate:generate(0,a.limit)
else:fit(a.ordered,a.augmented,a.leaves)
