#!/usr/bin/env python3
from __future__ import annotations
import json, time
from pathlib import Path
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
from lightgbm import LGBMRegressor
import sys
sys.path.insert(0,'/mnt/data/arc_weight_model')
from bieq_layer31_experiment import load_data, eval_replay, bootstrap_ratio

ROOT=Path('/mnt/data/arc_weight_model/bieq_run')
D=load_data(ROOT/'data'); m=D['meta']; nt,nc,nv=m['n_train'],m['n_calib'],m['n_val']; n=m['width']; G=m['n_groups']; gs=2*n
W=np.asarray(D['weights']); T=(np.asarray(D['targets_a'])+np.asarray(D['targets_b']))*.5
Kstats=np.asarray(D['kstats']); K=Kstats[...,0]; P=np.asarray(D['particles31'])
y=T[:,-2]-K[:,-2]

# Build per-neuron features from complete Kerdock cloud at layer31.
def build_features(ordered: bool):
    rows=[]
    for i in range(len(W)):
        a=P[i].reshape(G,gs,n).astype(np.float64)
        mu=a.mean(1).T                    # n,G
        sd=a.std(1).T
        zero=(a<=0).mean(1).T
        mx=a.max(1).T
        # Antipodal-pair imbalance: first/second halves of each basis block.
        pair=np.abs(a[:,:n]-a[:,n:]).mean(1).T
        if not ordered:
            # Sort each statistic by basis mean, preserving joint tokens.
            ix=np.argsort(mu,axis=1)
            def take(z): return np.take_along_axis(z,ix,axis=1)
            mu,sd,zero,mx,pair=map(take,(mu,sd,zero,mx,pair))
        local=np.concatenate([mu,sd,zero,mx,pair],1)
        # Per-neuron final-layer column diagnostics.
        C=W[i,-1].T.astype(np.float64) # source neuron x output neuron
        col=np.stack([C.mean(1),C.std(1),np.abs(C).mean(1),(C*C).mean(1),
                      np.maximum(C,0).sum(1),np.minimum(C,0).sum(1),C.max(1),C.min(1)],1)
        # Observable Kerdock trajectory and global network summaries.
        traj=Kstats[i,:, :, :].transpose(1,0,2).reshape(n,-1) # neuron-id trajectory (not fully equivariant across layers; diagnostic only)
        st31=Kstats[i,-2]
        glob=np.array([K[i,-2].mean(),K[i,-2].std(),K[i,-1].mean(),K[i,-1].std(),
                       mu.std(),sd.mean(),zero.mean(),np.linalg.norm(W[i,-1]) / n],np.float64)
        gl=np.repeat(glob[None,:],n,0)
        rows.append(np.concatenate([local,col,st31,gl,traj],1).astype(np.float32))
    return np.stack(rows)

# Also strict features that avoid matching neuron IDs across unrelated layers.
def build_strict(ordered: bool):
    rows=[]
    for i in range(len(W)):
        a=P[i].reshape(G,gs,n).astype(np.float64)
        mu=a.mean(1).T; sd=a.std(1).T; zero=(a<=0).mean(1).T; mx=a.max(1).T
        pair=np.abs(a[:,:n]-a[:,n:]).mean(1).T
        if not ordered:
            ix=np.argsort(mu,axis=1)
            def take(z): return np.take_along_axis(z,ix,axis=1)
            mu,sd,zero,mx,pair=map(take,(mu,sd,zero,mx,pair))
        local=np.concatenate([mu,sd,zero,mx,pair],1)
        C=W[i,-1].T.astype(np.float64)
        col=np.stack([C.mean(1),C.std(1),np.abs(C).mean(1),(C*C).mean(1),
                      np.maximum(C,0).sum(1),np.minimum(C,0).sum(1),C.max(1),C.min(1)],1)
        st31=Kstats[i,-2]
        # Layerwise global invariants only.
        glob_layers=np.concatenate([Kstats[i].mean(1).reshape(-1),Kstats[i].std(1).reshape(-1)])
        gl=np.repeat(glob_layers[None,:],n,0)
        rows.append(np.concatenate([local,col,st31,gl],1).astype(np.float32))
    return np.stack(rows)


def fit_eval(name,X,model):
    t=time.time(); Xtr=X[:nt].reshape(-1,X.shape[-1]); ytr=y[:nt].reshape(-1)
    Xca=X[nt:nt+nc].reshape(-1,X.shape[-1]); yca=y[nt:nt+nc].reshape(-1)
    Xv=X[nt+nc:].reshape(-1,X.shape[-1]); yv=y[nt+nc:].reshape(-1)
    model.fit(Xtr,ytr)
    pca=model.predict(Xca).reshape(nc,n).astype(np.float32)
    pv=model.predict(Xv).reshape(nv,n).astype(np.float32)
    # calibration shrinkage by replay
    ag=np.linspace(-.25,1.5,36); cal=[]
    for alpha in ag:
        e=eval_replay(W[nt:nt+nc],P[nt:nt+nc],K[nt:nt+nc],T[nt:nt+nc],pca,float(alpha))
        cal.append((float(alpha),e['corr_mean']))
    alpha=min(cal,key=lambda z:z[1])[0]
    ev=eval_replay(W[nt+nc:],P[nt+nc:],K[nt+nc:],T[nt+nc:],pv,alpha)
    ratio,ci=bootstrap_ratio(ev['base'],ev['corr'],seed=199)
    res=dict(name=name,features=X.shape[-1],alpha=alpha,layer31_gain=float(np.mean(yv*yv)/np.mean((yv-pv.ravel())**2)),
             corr=float(np.corrcoef(yv,pv.ravel())[0,1]),replay_gain=ratio,replay_ci95=ci,wins=ev['wins'],
             baseline_mse=ev['base_mean'],corrected_mse=ev['corr_mean'],worst_ratio=float(np.max(ev['corr']/ev['base'])),
             median_ratio=float(np.median(ev['corr']/ev['base'])),runtime=time.time()-t)
    print(json.dumps(res),flush=True); return res

results=[]
for strict in [True,False]:
  for ordered in [False,True]:
    X=build_strict(ordered) if strict else build_features(ordered)
    tag=('strict' if strict else 'diagnostic')+('_ordered' if ordered else '_sorted')
    # Ridge baseline
    sc=StandardScaler(); Xs=sc.fit_transform(X[:nt].reshape(-1,X.shape[-1]));
    # wrapper simple manual to avoid pipeline memory surprises
    class RidgeWrap:
      def __init__(self,sc): self.sc=sc; self.r=Ridge(alpha=100.0)
      def fit(self,x,y): self.r.fit(self.sc.transform(x),y); return self
      def predict(self,x): return self.r.predict(self.sc.transform(x))
    results.append(fit_eval('ridge_'+tag,X,RidgeWrap(sc)))
    # LightGBM high-capacity observable-signal probe.
    lgb=LGBMRegressor(n_estimators=500,learning_rate=.035,num_leaves=31,max_depth=-1,
        min_child_samples=40,subsample=.85,colsample_bytree=.7,reg_lambda=2.0,reg_alpha=.1,
        random_state=17,n_jobs=5,verbosity=-1)
    results.append(fit_eval('lgb_'+tag,X,lgb))

out={'meta':m,'results':results}
(ROOT/'basis_probe_results.json').write_text(json.dumps(out,indent=2))
