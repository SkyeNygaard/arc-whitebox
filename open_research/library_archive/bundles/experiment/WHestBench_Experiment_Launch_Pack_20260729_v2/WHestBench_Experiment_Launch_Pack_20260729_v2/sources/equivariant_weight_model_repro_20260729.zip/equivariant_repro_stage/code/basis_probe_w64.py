#!/usr/bin/env python3
import sys,json,time
from pathlib import Path
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from lightgbm import LGBMRegressor
sys.path.insert(0,'/mnt/data/arc_weight_model')
from bieq_layer31_experiment import load_data,eval_replay,bootstrap_ratio
root=Path('/mnt/data/arc_weight_model/bieq_w64_screen');D=load_data(root/'data');m=D['meta'];nt,nc,nv=m['n_train'],m['n_calib'],m['n_val'];n=m['width'];G=m['n_groups'];gs=2*n
W=np.asarray(D['weights']);T=(np.asarray(D['targets_a'])+np.asarray(D['targets_b']))*.5;S=np.asarray(D['kstats']);K=S[...,0];P=np.asarray(D['particles31']);Y=T[:,-2]-K[:,-2]

def feats(ordered=True):
 out=[]
 for i in range(nt+nc+nv):
  a=P[i].reshape(G,gs,n).astype(np.float64)
  mu=a.mean(1).T;sd=a.std(1).T;zero=(a<=0).mean(1).T;mx=a.max(1).T;pair=np.abs(a[:,:n]-a[:,n:]).mean(1).T
  if not ordered:
   ix=np.argsort(mu,1)
   mu,sd,zero,mx,pair=[np.take_along_axis(z,ix,1) for z in [mu,sd,zero,mx,pair]]
  local=np.concatenate([mu,sd,zero,mx,pair],1)
  C=W[i,-1].T.astype(np.float64)
  col=np.stack([C.mean(1),C.std(1),np.abs(C).mean(1),(C*C).mean(1),np.maximum(C,0).sum(1),np.minimum(C,0).sum(1),C.max(1),C.min(1)],1)
  gl0=np.concatenate([S[i].mean(1).reshape(-1),S[i].std(1).reshape(-1)])
  gl=np.repeat(gl0[None,:],n,0)
  out.append(np.concatenate([local,col,S[i,-2],gl],1).astype(np.float32))
 return np.stack(out)

def evaluate(name,X,model):
 t=time.time();model.fit(X[:nt].reshape(-1,X.shape[-1]),Y[:nt].reshape(-1))
 pc=model.predict(X[nt:nt+nc].reshape(-1,X.shape[-1])).reshape(nc,n)
 pv=model.predict(X[nt+nc:].reshape(-1,X.shape[-1])).reshape(nv,n)
 yc=Y[nt:nt+nc];alpha=float(np.clip(np.sum(pc*yc)/max(np.sum(pc*pc),1e-30),-.25,1.5))
 sl=slice(nt+nc,nt+nc+nv);ev=eval_replay(W[sl],P[sl],K[sl],T[sl],pv,alpha);ratio,ci=bootstrap_ratio(ev['base'],ev['corr'],seed=701)
 y=Y[sl]
 r=dict(name=name,features=X.shape[-1],alpha=alpha,layer31_gain=float(np.mean(y*y)/np.mean((y-pv)**2)),corr=float(np.corrcoef(y.ravel(),pv.ravel())[0,1]),replay_gain=ratio,replay_ci95=ci,wins=ev['wins'],baseline_mse=ev['base_mean'],corrected_mse=ev['corr_mean'],worst_ratio=float(np.max(ev['corr']/ev['base'])),median_ratio=float(np.median(ev['corr']/ev['base'])),runtime=time.time()-t)
 print(json.dumps(r),flush=True);return r
res=[]
for ordered in [False,True]:
 X=feats(ordered);tag='ordered' if ordered else 'sorted'
 # Ridge
 scaler=StandardScaler().fit(X[:nt].reshape(-1,X.shape[-1]))
 class RW:
  def __init__(self):self.r=Ridge(alpha=100)
  def fit(self,x,y):self.r.fit(scaler.transform(x),y);return self
  def predict(self,x):return self.r.predict(scaler.transform(x))
 res.append(evaluate('ridge_'+tag,X,RW()))
 for leaves in [15,31,63]:
  model=LGBMRegressor(n_estimators=800,learning_rate=.025,num_leaves=leaves,min_child_samples=60,subsample=.85,colsample_bytree=.75,reg_lambda=3,reg_alpha=.2,random_state=17+leaves,n_jobs=4,verbosity=-1)
  res.append(evaluate(f'lgb{leaves}_'+tag,X,model))
(root/'basis_probe_w64_results.json').write_text(json.dumps({'meta':m,'results':res},indent=2))
